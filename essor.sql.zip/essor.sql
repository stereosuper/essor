-- phpMyAdmin SQL Dump
-- version 4.2.5
-- http://www.phpmyadmin.net
--
-- Client :  localhost:3306
-- Généré le :  Mer 02 Août 2017 à 14:41
-- Version du serveur :  5.5.38
-- Version de PHP :  5.5.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données :  `essor`
--

-- --------------------------------------------------------

--
-- Structure de la table `essor_commentmeta`
--

CREATE TABLE `essor_commentmeta` (
`meta_id` bigint(20) unsigned NOT NULL,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `essor_comments`
--

CREATE TABLE `essor_comments` (
`comment_ID` bigint(20) unsigned NOT NULL,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `essor_email_log`
--

CREATE TABLE `essor_email_log` (
`id` mediumint(9) NOT NULL,
  `to_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subject` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `headers` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `attachments` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `sent_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `essor_ewwwio_images`
--

CREATE TABLE `essor_ewwwio_images` (
`id` int(14) unsigned NOT NULL,
  `attachment_id` bigint(20) unsigned DEFAULT NULL,
  `gallery` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `resize` varchar(75) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `path` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `converted` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `results` varchar(75) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image_size` int(10) unsigned DEFAULT NULL,
  `orig_size` int(10) unsigned DEFAULT NULL,
  `backup` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `level` int(5) unsigned DEFAULT NULL,
  `pending` tinyint(1) NOT NULL DEFAULT '0',
  `updates` int(5) unsigned DEFAULT NULL,
  `updated` timestamp NOT NULL DEFAULT '1970-12-31 23:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `trace` blob
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=19 ;

--
-- Contenu de la table `essor_ewwwio_images`
--

INSERT INTO `essor_ewwwio_images` (`id`, `attachment_id`, `gallery`, `resize`, `path`, `converted`, `results`, `image_size`, `orig_size`, `backup`, `level`, `pending`, `updates`, `updated`, `trace`) VALUES
(1, 129, 'media', 'full', '/Users/elisabeth/Travail/Stereo/essor/dest/wp-content/uploads/2017/07/img.png', '', 'Réduit de 2,0% (7,2 KB)', 351140, 358485, '', NULL, 0, 1, '2017-07-25 08:07:07', NULL),
(2, 129, 'media', 'thumbnail', '/Users/elisabeth/Travail/Stereo/essor/dest/wp-content/uploads/2017/07/img-150x150.png', '', 'Réduit de 14,4% (6,3 KB)', 38189, 44618, '', NULL, 0, 1, '2017-07-25 08:07:07', NULL),
(3, 129, 'media', 'medium', '/Users/elisabeth/Travail/Stereo/essor/dest/wp-content/uploads/2017/07/img-300x182.png', '', 'Réduit de 12,7% (13,4 KB)', 94298, 107973, '', NULL, 0, 1, '2017-07-25 08:07:08', NULL),
(4, 129, 'media', 'tiny-lazy', '/Users/elisabeth/Travail/Stereo/essor/dest/wp-content/uploads/2017/07/img-30x18.png', '', 'Réduit de 11,9% (178,0 B)', 1324, 1502, '', NULL, 0, 1, '2017-07-25 08:07:08', NULL),
(5, 130, 'media', 'full', '/Users/elisabeth/Travail/Stereo/essor/dest/wp-content/uploads/2017/07/img2.png', '', 'Réduit de 0,8% (5,4 KB)', 657110, 662630, '', NULL, 0, 1, '2017-07-25 08:07:57', NULL),
(6, 130, 'media', 'thumbnail', '/Users/elisabeth/Travail/Stereo/essor/dest/wp-content/uploads/2017/07/img2-150x150.png', '', 'Réduit de 13,1% (4,8 KB)', 32495, 37389, '', NULL, 0, 1, '2017-07-25 08:07:57', NULL),
(7, 130, 'media', 'medium', '/Users/elisabeth/Travail/Stereo/essor/dest/wp-content/uploads/2017/07/img2-300x91.png', '', 'Réduit de 12,5% (6,7 KB)', 48343, 55254, '', NULL, 0, 1, '2017-07-25 08:07:58', NULL),
(8, 130, 'media', 'medium_large', '/Users/elisabeth/Travail/Stereo/essor/dest/wp-content/uploads/2017/07/img2-768x233.png', '', 'Réduit de 13,4% (40,1 KB)', 266390, 307496, '', NULL, 0, 1, '2017-07-25 08:08:00', NULL),
(9, 130, 'media', 'large', '/Users/elisabeth/Travail/Stereo/essor/dest/wp-content/uploads/2017/07/img2-1024x311.png', '', 'Réduit de 13,7% (69,3 KB)', 448124, 519107, '', NULL, 0, 1, '2017-07-25 08:08:07', NULL),
(10, 130, 'media', 'tiny-lazy', '/Users/elisabeth/Travail/Stereo/essor/dest/wp-content/uploads/2017/07/img2-30x9.png', '', 'Réduit de 11,5% (97,0 B)', 746, 843, '', NULL, 0, 1, '2017-07-25 08:08:07', NULL),
(11, 137, 'media', 'full', '/Users/elisabeth/Travail/Stereo/essor/dest/wp-content/uploads/2017/07/implantations.png', '', 'Réduit de 35,9% (1,6 KB)', 2895, 4517, '', NULL, 0, 1, '2017-07-26 08:12:34', NULL),
(12, 137, 'media', 'tiny-lazy', '/Users/elisabeth/Travail/Stereo/essor/dest/wp-content/uploads/2017/07/implantations-30x30.png', '', 'Aucun enregistrement', 1044, 1044, '', NULL, 0, 1, '2017-07-26 08:12:34', NULL),
(13, 138, 'media', 'full', '/Users/elisabeth/Travail/Stereo/essor/dest/wp-content/uploads/2017/07/visuel.jpg', '', 'Réduit de 2,0% (8,3 KB)', 406821, 415309, '', NULL, 0, 1, '2017-07-26 13:30:44', NULL),
(14, 138, 'media', 'thumbnail', '/Users/elisabeth/Travail/Stereo/essor/dest/wp-content/uploads/2017/07/visuel-150x150.jpg', '', 'Réduit de 4,8% (402,0 B)', 8030, 8432, '', NULL, 0, 1, '2017-07-26 13:30:44', NULL),
(15, 138, 'media', 'medium', '/Users/elisabeth/Travail/Stereo/essor/dest/wp-content/uploads/2017/07/visuel-300x102.jpg', '', 'Réduit de 4,4% (444,0 B)', 9586, 10030, '', NULL, 0, 1, '2017-07-26 13:30:44', NULL),
(16, 138, 'media', 'medium_large', '/Users/elisabeth/Travail/Stereo/essor/dest/wp-content/uploads/2017/07/visuel-768x261.jpg', '', 'Réduit de 1,5% (726,0 B)', 48335, 49061, '', NULL, 0, 1, '2017-07-26 13:30:44', NULL),
(17, 138, 'media', 'large', '/Users/elisabeth/Travail/Stereo/essor/dest/wp-content/uploads/2017/07/visuel-1024x349.jpg', '', 'Réduit de 1,3% (1&nbsp;023,0 B)', 77765, 78788, '', NULL, 0, 1, '2017-07-26 13:30:44', NULL),
(18, 138, 'media', 'tiny-lazy', '/Users/elisabeth/Travail/Stereo/essor/dest/wp-content/uploads/2017/07/visuel-30x10.jpg', '', 'Réduit de 43,1% (381,0 B)', 502, 883, '', NULL, 0, 1, '2017-07-26 13:30:45', NULL);

-- --------------------------------------------------------

--
-- Structure de la table `essor_links`
--

CREATE TABLE `essor_links` (
`link_id` bigint(20) unsigned NOT NULL,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `essor_options`
--

CREATE TABLE `essor_options` (
`option_id` bigint(20) unsigned NOT NULL,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'yes'
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=740 ;

--
-- Contenu de la table `essor_options`
--

INSERT INTO `essor_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://localhost', 'yes'),
(2, 'home', 'http://localhost', 'yes'),
(3, 'blogname', 'Essor', 'yes'),
(4, 'blogdescription', '', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', 'elisabeth@stereosuper.fr', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '1', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'closed', 'yes'),
(20, 'default_ping_status', 'closed', 'yes'),
(21, 'default_pingback_flag', '', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'j F Y', 'yes'),
(24, 'time_format', 'G \\h i \\m\\i\\n', 'yes'),
(25, 'links_updated_date_format', 'j F Y G \\h i \\m\\i\\n', 'yes'),
(26, 'comment_moderation', '', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '/%postname%/', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:8:{i:0;s:34:"advanced-custom-fields-pro/acf.php";i:1;s:33:"automatic-nbsp/automatic-nbsp.php";i:2;s:29:"bj-lazy-load/bj-lazy-load.php";i:4;s:23:"email-log/email-log.php";i:5;s:45:"ewww-image-optimizer/ewww-image-optimizer.php";i:6;s:23:"secupress/secupress.php";i:7;s:24:"wordpress-seo/wp-seo.php";i:8;s:63:"wp-seo-structured-data-schema/wp-seo-structured-data-schema.php";}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'comment_max_links', '2', 'yes'),
(37, 'gmt_offset', '', 'yes'),
(38, 'default_email_category', '1', 'yes'),
(39, 'recently_edited', '', 'no'),
(40, 'template', 'essor', 'yes'),
(41, 'stylesheet', 'essor', 'yes'),
(42, 'comment_whitelist', '1', 'yes'),
(43, 'blacklist_keys', '', 'no'),
(44, 'comment_registration', '1', 'yes'),
(45, 'html_type', 'text/html', 'yes'),
(46, 'use_trackback', '0', 'yes'),
(47, 'default_role', 'subscriber', 'yes'),
(48, 'db_version', '38590', 'yes'),
(49, 'uploads_use_yearmonth_folders', '1', 'yes'),
(50, 'upload_path', '', 'yes'),
(51, 'blog_public', '0', 'yes'),
(52, 'default_link_category', '2', 'yes'),
(53, 'show_on_front', 'page', 'yes'),
(54, 'tag_base', '', 'yes'),
(55, 'show_avatars', '1', 'yes'),
(56, 'avatar_rating', 'G', 'yes'),
(57, 'upload_url_path', '', 'yes'),
(58, 'thumbnail_size_w', '150', 'yes'),
(59, 'thumbnail_size_h', '150', 'yes'),
(60, 'thumbnail_crop', '1', 'yes'),
(61, 'medium_size_w', '300', 'yes'),
(62, 'medium_size_h', '300', 'yes'),
(63, 'avatar_default', 'identicon', 'yes'),
(64, 'large_size_w', '1024', 'yes'),
(65, 'large_size_h', '1024', 'yes'),
(66, 'image_default_link_type', 'none', 'yes'),
(67, 'image_default_size', '', 'yes'),
(68, 'image_default_align', '', 'yes'),
(69, 'close_comments_for_old_posts', '', 'yes'),
(70, 'close_comments_days_old', '14', 'yes'),
(71, 'thread_comments', '', 'yes'),
(72, 'thread_comments_depth', '5', 'yes'),
(73, 'page_comments', '', 'yes'),
(74, 'comments_per_page', '50', 'yes'),
(75, 'default_comments_page', 'newest', 'yes'),
(76, 'comment_order', 'asc', 'yes'),
(77, 'sticky_posts', 'a:0:{}', 'yes'),
(78, 'widget_categories', 'a:2:{i:2;a:4:{s:5:"title";s:0:"";s:5:"count";i:0;s:12:"hierarchical";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(79, 'widget_text', 'a:0:{}', 'yes'),
(80, 'widget_rss', 'a:0:{}', 'yes'),
(81, 'uninstall_plugins', 'a:3:{s:45:"ewww-image-optimizer/ewww-image-optimizer.php";s:30:"ewww_image_optimizer_uninstall";s:39:"bj-lazy-load/inc/class-bjll-options.php";s:14:"__return_false";s:27:"redirection/redirection.php";a:2:{i:0;s:17:"Redirection_Admin";i:1;s:16:"plugin_uninstall";}}', 'no'),
(82, 'timezone_string', 'Europe/Paris', 'yes'),
(83, 'page_for_posts', '0', 'yes'),
(84, 'page_on_front', '2', 'yes'),
(85, 'default_post_format', '0', 'yes'),
(86, 'link_manager_enabled', '0', 'yes'),
(87, 'finished_splitting_shared_terms', '1', 'yes'),
(88, 'site_icon', '0', 'yes'),
(89, 'medium_large_size_w', '768', 'yes'),
(90, 'medium_large_size_h', '0', 'yes'),
(91, 'initial_db_version', '38590', 'yes'),
(92, 'essor_user_roles', 'a:5:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:62:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;s:15:"wpseo_bulk_edit";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:35:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:15:"wpseo_bulk_edit";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}}', 'yes'),
(93, 'fresh_site', '0', 'yes'),
(94, 'WPLANG', 'fr_FR', 'yes'),
(95, 'widget_search', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes'),
(96, 'widget_recent-posts', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes'),
(97, 'widget_recent-comments', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes'),
(98, 'widget_archives', 'a:2:{i:2;a:3:{s:5:"title";s:0:"";s:5:"count";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(99, 'widget_meta', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes'),
(100, 'sidebars_widgets', 'a:3:{s:19:"wp_inactive_widgets";a:0:{}s:7:"sidebar";a:0:{}s:13:"array_version";i:3;}', 'yes'),
(101, 'widget_pages', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(102, 'widget_calendar', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(103, 'widget_media_audio', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(104, 'widget_media_image', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(105, 'widget_media_video', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(106, 'widget_tag_cloud', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(107, 'widget_nav_menu', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(108, 'cron', 'a:6:{i:1501688935;a:3:{s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1501688980;a:1:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1501691499;a:1:{s:19:"wpseo-reindex-links";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1501691500;a:1:{s:27:"secupress_cleanup_leftovers";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1501752513;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}s:7:"version";i:2;}', 'yes'),
(116, '_site_transient_timeout_browser_51a3f46bfabae39cd5aee62c6276c1dc', '1501170580', 'no'),
(117, '_site_transient_browser_51a3f46bfabae39cd5aee62c6276c1dc', 'a:9:{s:8:"platform";s:9:"Macintosh";s:4:"name";s:6:"Chrome";s:7:"version";s:13:"59.0.3071.115";s:10:"update_url";s:28:"http://www.google.com/chrome";s:7:"img_src";s:49:"http://s.wordpress.org/images/browsers/chrome.png";s:11:"img_src_ssl";s:48:"https://wordpress.org/images/browsers/chrome.png";s:15:"current_version";s:2:"18";s:7:"upgrade";b:0;s:8:"insecure";b:0;}', 'no'),
(119, '_transient_timeout_feed_66a70e9599b658d5cc038e8074597e7c', '1500608982', 'no');
INSERT INTO `essor_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(120, '_transient_feed_66a70e9599b658d5cc038e8074597e7c', 'a:4:{s:5:"child";a:1:{s:0:"";a:1:{s:3:"rss";a:1:{i:0;a:6:{s:4:"data";s:3:"\n\n\n";s:7:"attribs";a:1:{s:0:"";a:1:{s:7:"version";s:3:"2.0";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:1:{s:7:"channel";a:1:{i:0;a:6:{s:4:"data";s:49:"\n	\n	\n	\n	\n	\n	\n	\n	\n	\n	\n		\n		\n		\n		\n		\n		\n		\n		\n		\n	";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:6:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:4:"WPFR";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:16:"https://wpfr.net";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:31:"Site officiel de la communauté";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:13:"lastBuildDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 20 Jul 2017 15:19:53 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"language";a:1:{i:0;a:5:{s:4:"data";s:5:"fr-FR";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"item";a:10:{i:0;a:6:{s:4:"data";s:45:"\n		\n		\n		\n		\n		\n				\n		\n		\n		\n\n		\n		\n		\n		\n		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:74:"Les résultats du grand sondage de la communauté francophone de WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:67:"http://feedproxy.google.com/~r/WordpressFrancophone/~3/_z7qQytCHB8/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:89:"https://wpfr.net/resultats-grand-sondage-de-communaute-francophone-de-wordpress/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 14 Jul 2017 12:52:28 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:4:{i:0;a:5:{s:4:"data";s:7:"Brèves";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:21:"WordPress Francophone";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:11:"communauté";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:3;a:5:{s:4:"data";s:7:"sondage";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:27:"https://wpfr.net/?p=1647338";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1513:"Fin mai, un grand sondage était lancé par Maxime Bernard-Jacquet au nom de la communauté francophone de WordPress afin de mieux identifier comment elle se composait ! Aujourd&#8217;hui les résultats sont disponibles. La première statistique intéressante est la participation, puisque ce sont 1000 personnes qui ont répondues à ce questionnaire. Ceci permet donc d&#8217;avoir des<div class="btn btn-default read-more text-uppercase">Lire la suite <span class="meta-nav"><i class="fa fa-caret-right"></i></span></div><div class="feedflare">\n<a href="http://feeds.feedburner.com/~ff/WordpressFrancophone?a=_z7qQytCHB8:88mzRUJSvF0:yIl2AUoC8zA"><img src="http://feeds.feedburner.com/~ff/WordpressFrancophone?d=yIl2AUoC8zA" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/WordpressFrancophone?a=_z7qQytCHB8:88mzRUJSvF0:V_sGLiPBpWU"><img src="http://feeds.feedburner.com/~ff/WordpressFrancophone?i=_z7qQytCHB8:88mzRUJSvF0:V_sGLiPBpWU" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/WordpressFrancophone?a=_z7qQytCHB8:88mzRUJSvF0:qj6IDK7rITs"><img src="http://feeds.feedburner.com/~ff/WordpressFrancophone?d=qj6IDK7rITs" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/WordpressFrancophone?a=_z7qQytCHB8:88mzRUJSvF0:gIN9vFwOqvQ"><img src="http://feeds.feedburner.com/~ff/WordpressFrancophone?i=_z7qQytCHB8:88mzRUJSvF0:gIN9vFwOqvQ" border="0"></img></a>\n</div><img src="http://feeds.feedburner.com/~r/WordpressFrancophone/~4/_z7qQytCHB8" height="1" width="1" alt=""/>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:19:"Benoît Catherineau";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:85:"https://wpfr.net/resultats-grand-sondage-de-communaute-francophone-de-wordpress/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"4";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:42:"http://rssnamespace.org/feedburner/ext/1.0";a:1:{s:8:"origLink";a:1:{i:0;a:5:{s:4:"data";s:80:"https://wpfr.net/resultats-grand-sondage-de-communaute-francophone-de-wordpress/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:1;a:6:{s:4:"data";s:39:"\n		\n		\n		\n		\n		\n				\n		\n\n		\n		\n		\n		\n		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:37:"Cap des 200 adhérents WPFR franchi !";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:67:"http://feedproxy.google.com/~r/WordpressFrancophone/~3/dZ9emWhTWPc/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:57:"https://wpfr.net/cap-200-adherents-wpfr-franchi/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 13 Jun 2017 15:16:58 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:16:"Association WPFR";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:4:"Blog";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:27:"https://wpfr.net/?p=1642124";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1476:"C&#8217;est officiel, l&#8217;association WordPress Francophone compte 200 membres à jour de cotisation ! Ouvertes depuis septembre 2016, les adhésions en ligne remportent un vif succès et nous sommes heureux de voir que la communauté WordPress se porte bien. On se donne rendez-vous à Paris pour le WordCamp Europe du 16 et 17 juin prochain. Le<div class="btn btn-default read-more text-uppercase">Lire la suite <span class="meta-nav"><i class="fa fa-caret-right"></i></span></div><div class="feedflare">\n<a href="http://feeds.feedburner.com/~ff/WordpressFrancophone?a=dZ9emWhTWPc:XRx8AZKI2zs:yIl2AUoC8zA"><img src="http://feeds.feedburner.com/~ff/WordpressFrancophone?d=yIl2AUoC8zA" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/WordpressFrancophone?a=dZ9emWhTWPc:XRx8AZKI2zs:V_sGLiPBpWU"><img src="http://feeds.feedburner.com/~ff/WordpressFrancophone?i=dZ9emWhTWPc:XRx8AZKI2zs:V_sGLiPBpWU" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/WordpressFrancophone?a=dZ9emWhTWPc:XRx8AZKI2zs:qj6IDK7rITs"><img src="http://feeds.feedburner.com/~ff/WordpressFrancophone?d=qj6IDK7rITs" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/WordpressFrancophone?a=dZ9emWhTWPc:XRx8AZKI2zs:gIN9vFwOqvQ"><img src="http://feeds.feedburner.com/~ff/WordpressFrancophone?i=dZ9emWhTWPc:XRx8AZKI2zs:gIN9vFwOqvQ" border="0"></img></a>\n</div><img src="http://feeds.feedburner.com/~r/WordpressFrancophone/~4/dZ9emWhTWPc" height="1" width="1" alt=""/>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:15:"Aurélien Denis";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:53:"https://wpfr.net/cap-200-adherents-wpfr-franchi/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"5";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:42:"http://rssnamespace.org/feedburner/ext/1.0";a:1:{s:8:"origLink";a:1:{i:0;a:5:{s:4:"data";s:48:"https://wpfr.net/cap-200-adherents-wpfr-franchi/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:2;a:6:{s:4:"data";s:39:"\n		\n		\n		\n		\n		\n				\n		\n\n		\n		\n		\n		\n		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:53:"Un grand sondage pour mieux connaître la communauté";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:67:"http://feedproxy.google.com/~r/WordpressFrancophone/~3/ArHvRJvd55Y/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:67:"https://wpfr.net/grand-sondage-mieux-connaitre-communaute/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 23 May 2017 14:15:50 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:21:"WordPress Francophone";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:11:"communauté";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:27:"https://wpfr.net/?p=1638548";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1516:"Maxime et Alexandre, les « chefs cuistot » de la communauté viennent de lancer un sondage à destination de la communauté francophone de WordPress. L&#8217;objectif est de mieux connaitre celles et ceux qui la composent. Alors que vous soyez débutant ou confirmé, simple utilisateur, bidouilleur passionné ou professionnel venez répondre à ce questionnaire qui permettra de mieux<div class="btn btn-default read-more text-uppercase">Lire la suite <span class="meta-nav"><i class="fa fa-caret-right"></i></span></div><div class="feedflare">\n<a href="http://feeds.feedburner.com/~ff/WordpressFrancophone?a=ArHvRJvd55Y:rW_1swugq14:yIl2AUoC8zA"><img src="http://feeds.feedburner.com/~ff/WordpressFrancophone?d=yIl2AUoC8zA" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/WordpressFrancophone?a=ArHvRJvd55Y:rW_1swugq14:V_sGLiPBpWU"><img src="http://feeds.feedburner.com/~ff/WordpressFrancophone?i=ArHvRJvd55Y:rW_1swugq14:V_sGLiPBpWU" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/WordpressFrancophone?a=ArHvRJvd55Y:rW_1swugq14:qj6IDK7rITs"><img src="http://feeds.feedburner.com/~ff/WordpressFrancophone?d=qj6IDK7rITs" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/WordpressFrancophone?a=ArHvRJvd55Y:rW_1swugq14:gIN9vFwOqvQ"><img src="http://feeds.feedburner.com/~ff/WordpressFrancophone?i=ArHvRJvd55Y:rW_1swugq14:gIN9vFwOqvQ" border="0"></img></a>\n</div><img src="http://feeds.feedburner.com/~r/WordpressFrancophone/~4/ArHvRJvd55Y" height="1" width="1" alt=""/>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:19:"Benoît Catherineau";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:63:"https://wpfr.net/grand-sondage-mieux-connaitre-communaute/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"2";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:42:"http://rssnamespace.org/feedburner/ext/1.0";a:1:{s:8:"origLink";a:1:{i:0;a:5:{s:4:"data";s:58:"https://wpfr.net/grand-sondage-mieux-connaitre-communaute/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:3;a:6:{s:4:"data";s:42:"\n		\n		\n		\n		\n		\n				\n		\n		\n\n		\n		\n		\n		\n		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:52:"Compte rendu de la réunion du bureau du 9 mars 2017";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:67:"http://feedproxy.google.com/~r/WordpressFrancophone/~3/scUWeRFptEQ/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:66:"https://wpfr.net/compte-rendu-reunion-bureau-9-mars-2017/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 03 Apr 2017 09:02:53 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:3:{i:0;a:5:{s:4:"data";s:16:"Association WPFR";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:21:"WordPress Francophone";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:8:"Réunion";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:27:"https://wpfr.net/?p=1629790";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1529:"Présent : Willy Bahuaud, Xavier, Borderie, Benoît Catherineau et Aurélien Denis L’élection du nouveau bureau a été clôturée le 4 mars 2017. Le résultat donne vainqueur les 3 candidats suivants : Benoît Catherineau, Xavier Borderie, Aurélien Denis. Cette réunion a pour objet l’installation du nouveau bureau de WPFR. L’ordre du jour Répartition des postes de Président, Secrétaire<div class="btn btn-default read-more text-uppercase">Lire la suite <span class="meta-nav"><i class="fa fa-caret-right"></i></span></div><div class="feedflare">\n<a href="http://feeds.feedburner.com/~ff/WordpressFrancophone?a=scUWeRFptEQ:5gEow5Kjbq4:yIl2AUoC8zA"><img src="http://feeds.feedburner.com/~ff/WordpressFrancophone?d=yIl2AUoC8zA" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/WordpressFrancophone?a=scUWeRFptEQ:5gEow5Kjbq4:V_sGLiPBpWU"><img src="http://feeds.feedburner.com/~ff/WordpressFrancophone?i=scUWeRFptEQ:5gEow5Kjbq4:V_sGLiPBpWU" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/WordpressFrancophone?a=scUWeRFptEQ:5gEow5Kjbq4:qj6IDK7rITs"><img src="http://feeds.feedburner.com/~ff/WordpressFrancophone?d=qj6IDK7rITs" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/WordpressFrancophone?a=scUWeRFptEQ:5gEow5Kjbq4:gIN9vFwOqvQ"><img src="http://feeds.feedburner.com/~ff/WordpressFrancophone?i=scUWeRFptEQ:5gEow5Kjbq4:gIN9vFwOqvQ" border="0"></img></a>\n</div><img src="http://feeds.feedburner.com/~r/WordpressFrancophone/~4/scUWeRFptEQ" height="1" width="1" alt=""/>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:19:"Benoît Catherineau";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:62:"https://wpfr.net/compte-rendu-reunion-bureau-9-mars-2017/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"9";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:42:"http://rssnamespace.org/feedburner/ext/1.0";a:1:{s:8:"origLink";a:1:{i:0;a:5:{s:4:"data";s:57:"https://wpfr.net/compte-rendu-reunion-bureau-9-mars-2017/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:4;a:6:{s:4:"data";s:39:"\n		\n		\n		\n		\n		\n				\n		\n\n		\n		\n		\n		\n		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:40:"Résultats des élections du bureau 2017";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:67:"http://feedproxy.google.com/~r/WordpressFrancophone/~3/_rNOgYbgrxk/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:58:"https://wpfr.net/resultats-elections-bureau-2017/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 13 Mar 2017 14:35:19 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:16:"Association WPFR";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:4:"Blog";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:27:"https://wpfr.net/?p=1625743";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1487:"Suite à la votation électronique qui s&#8217;est déroulée du 24 février au 3 mars 2017, nous vous communiquons les résultats pour l&#8217;élection du bureau 2017. Vous avez été 54% des adhérents à participer au vote, soit 87 suffrages exprimés. 5 candidatures étaient présentées pour 3 postes à pourvoir. Chaque candidat a reçu une majorité de<div class="btn btn-default read-more text-uppercase">Lire la suite <span class="meta-nav"><i class="fa fa-caret-right"></i></span></div><div class="feedflare">\n<a href="http://feeds.feedburner.com/~ff/WordpressFrancophone?a=_rNOgYbgrxk:qyaNilbMKjw:yIl2AUoC8zA"><img src="http://feeds.feedburner.com/~ff/WordpressFrancophone?d=yIl2AUoC8zA" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/WordpressFrancophone?a=_rNOgYbgrxk:qyaNilbMKjw:V_sGLiPBpWU"><img src="http://feeds.feedburner.com/~ff/WordpressFrancophone?i=_rNOgYbgrxk:qyaNilbMKjw:V_sGLiPBpWU" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/WordpressFrancophone?a=_rNOgYbgrxk:qyaNilbMKjw:qj6IDK7rITs"><img src="http://feeds.feedburner.com/~ff/WordpressFrancophone?d=qj6IDK7rITs" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/WordpressFrancophone?a=_rNOgYbgrxk:qyaNilbMKjw:gIN9vFwOqvQ"><img src="http://feeds.feedburner.com/~ff/WordpressFrancophone?i=_rNOgYbgrxk:qyaNilbMKjw:gIN9vFwOqvQ" border="0"></img></a>\n</div><img src="http://feeds.feedburner.com/~r/WordpressFrancophone/~4/_rNOgYbgrxk" height="1" width="1" alt=""/>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:15:"Aurélien Denis";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:54:"https://wpfr.net/resultats-elections-bureau-2017/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:2:"11";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:42:"http://rssnamespace.org/feedburner/ext/1.0";a:1:{s:8:"origLink";a:1:{i:0;a:5:{s:4:"data";s:49:"https://wpfr.net/resultats-elections-bureau-2017/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:5;a:6:{s:4:"data";s:39:"\n		\n		\n		\n		\n		\n				\n		\n\n		\n		\n		\n		\n		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:34:"Liste des candidats au bureau 2017";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:67:"http://feedproxy.google.com/~r/WordpressFrancophone/~3/LwQXzbNVETE/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:54:"https://wpfr.net/liste-candidats-bureau-2017/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 14 Feb 2017 22:59:53 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:16:"Association WPFR";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:4:"Blog";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:27:"https://wpfr.net/?p=1620757";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1499:"Comme annoncé précédemment, les élections pour le renouvellement du bureau auront lieu du 24 février au 3 mars 2017 par voie électronique. Nous vous communiquons dès à présent la liste des candidats validée par l&#8217;actuel bureau, classés par ordre alphabétique. Les candidats Xavier Borderie Présentation Je suis un ancien de la communauté WordPress et de<div class="btn btn-default read-more text-uppercase">Lire la suite <span class="meta-nav"><i class="fa fa-caret-right"></i></span></div><div class="feedflare">\n<a href="http://feeds.feedburner.com/~ff/WordpressFrancophone?a=LwQXzbNVETE:otIkWq3vwSU:yIl2AUoC8zA"><img src="http://feeds.feedburner.com/~ff/WordpressFrancophone?d=yIl2AUoC8zA" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/WordpressFrancophone?a=LwQXzbNVETE:otIkWq3vwSU:V_sGLiPBpWU"><img src="http://feeds.feedburner.com/~ff/WordpressFrancophone?i=LwQXzbNVETE:otIkWq3vwSU:V_sGLiPBpWU" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/WordpressFrancophone?a=LwQXzbNVETE:otIkWq3vwSU:qj6IDK7rITs"><img src="http://feeds.feedburner.com/~ff/WordpressFrancophone?d=qj6IDK7rITs" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/WordpressFrancophone?a=LwQXzbNVETE:otIkWq3vwSU:gIN9vFwOqvQ"><img src="http://feeds.feedburner.com/~ff/WordpressFrancophone?i=LwQXzbNVETE:otIkWq3vwSU:gIN9vFwOqvQ" border="0"></img></a>\n</div><img src="http://feeds.feedburner.com/~r/WordpressFrancophone/~4/LwQXzbNVETE" height="1" width="1" alt=""/>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:15:"Aurélien Denis";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:50:"https://wpfr.net/liste-candidats-bureau-2017/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:2:"11";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:42:"http://rssnamespace.org/feedburner/ext/1.0";a:1:{s:8:"origLink";a:1:{i:0;a:5:{s:4:"data";s:45:"https://wpfr.net/liste-candidats-bureau-2017/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:6;a:6:{s:4:"data";s:36:"\n		\n		\n		\n		\n		\n				\n\n		\n		\n		\n		\n		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:28:"L’élection du bureau WPFR";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:67:"http://feedproxy.google.com/~r/WordpressFrancophone/~3/3TCggFy-pd8/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:47:"https://wpfr.net/election-bureau-wpfr/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 26 Jan 2017 19:09:16 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:16:"Association WPFR";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:27:"https://wpfr.net/?p=1616665";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1503:"Oyez, oyez ! Comme annoncé lors de l’assemblée générale du 8 décembre 2016, l&#8217;heure des élections a sonné. Le bureau actuellement en place voit son mandat terminé, de nouvelles élections doivent donc avoir lieu afin de le renouveler  Ces élections sont prévues pour le 24 février 2017 et nous invitons par cet article les adhérents souhaitant candidater<div class="btn btn-default read-more text-uppercase">Lire la suite <span class="meta-nav"><i class="fa fa-caret-right"></i></span></div><div class="feedflare">\n<a href="http://feeds.feedburner.com/~ff/WordpressFrancophone?a=3TCggFy-pd8:m3WOr5Sr_vI:yIl2AUoC8zA"><img src="http://feeds.feedburner.com/~ff/WordpressFrancophone?d=yIl2AUoC8zA" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/WordpressFrancophone?a=3TCggFy-pd8:m3WOr5Sr_vI:V_sGLiPBpWU"><img src="http://feeds.feedburner.com/~ff/WordpressFrancophone?i=3TCggFy-pd8:m3WOr5Sr_vI:V_sGLiPBpWU" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/WordpressFrancophone?a=3TCggFy-pd8:m3WOr5Sr_vI:qj6IDK7rITs"><img src="http://feeds.feedburner.com/~ff/WordpressFrancophone?d=qj6IDK7rITs" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/WordpressFrancophone?a=3TCggFy-pd8:m3WOr5Sr_vI:gIN9vFwOqvQ"><img src="http://feeds.feedburner.com/~ff/WordpressFrancophone?i=3TCggFy-pd8:m3WOr5Sr_vI:gIN9vFwOqvQ" border="0"></img></a>\n</div><img src="http://feeds.feedburner.com/~r/WordpressFrancophone/~4/3TCggFy-pd8" height="1" width="1" alt=""/>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Willy Bahuaud";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:43:"https://wpfr.net/election-bureau-wpfr/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"4";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:42:"http://rssnamespace.org/feedburner/ext/1.0";a:1:{s:8:"origLink";a:1:{i:0;a:5:{s:4:"data";s:38:"https://wpfr.net/election-bureau-wpfr/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:7;a:6:{s:4:"data";s:39:"\n		\n		\n		\n		\n		\n				\n		\n\n		\n		\n		\n		\n		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:46:"Compte rendu de l’Assemblée Générale 2016";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:67:"http://feedproxy.google.com/~r/WordpressFrancophone/~3/gB76y2pH0fE/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:63:"https://wpfr.net/compte-rendu-assemblee-generale-2016/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 07 Jan 2017 14:37:32 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:16:"Association WPFR";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:21:"Assemblée générale";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:27:"https://wpfr.net/?p=1610794";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1486:"~ Assemblée Générale du 8 décembre 2016 à 20 H 40 ~ Pour la première fois, l&#8217;assemblée générale de l&#8217;association WPFR a été réalisée en ligne. Ainsi, tous les membres avaient été convoqués afin d&#8217;y assister et d&#8217;y participer. La séance a été ouverte par Aurélien Denis, Président, à 20 H 40. Après avoir remercier<div class="btn btn-default read-more text-uppercase">Lire la suite <span class="meta-nav"><i class="fa fa-caret-right"></i></span></div><div class="feedflare">\n<a href="http://feeds.feedburner.com/~ff/WordpressFrancophone?a=gB76y2pH0fE:9qjsTMvWu3Q:yIl2AUoC8zA"><img src="http://feeds.feedburner.com/~ff/WordpressFrancophone?d=yIl2AUoC8zA" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/WordpressFrancophone?a=gB76y2pH0fE:9qjsTMvWu3Q:V_sGLiPBpWU"><img src="http://feeds.feedburner.com/~ff/WordpressFrancophone?i=gB76y2pH0fE:9qjsTMvWu3Q:V_sGLiPBpWU" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/WordpressFrancophone?a=gB76y2pH0fE:9qjsTMvWu3Q:qj6IDK7rITs"><img src="http://feeds.feedburner.com/~ff/WordpressFrancophone?d=qj6IDK7rITs" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/WordpressFrancophone?a=gB76y2pH0fE:9qjsTMvWu3Q:gIN9vFwOqvQ"><img src="http://feeds.feedburner.com/~ff/WordpressFrancophone?i=gB76y2pH0fE:9qjsTMvWu3Q:gIN9vFwOqvQ" border="0"></img></a>\n</div><img src="http://feeds.feedburner.com/~r/WordpressFrancophone/~4/gB76y2pH0fE" height="1" width="1" alt=""/>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:19:"Benoît Catherineau";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:59:"https://wpfr.net/compte-rendu-assemblee-generale-2016/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"3";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:42:"http://rssnamespace.org/feedburner/ext/1.0";a:1:{s:8:"origLink";a:1:{i:0;a:5:{s:4:"data";s:54:"https://wpfr.net/compte-rendu-assemblee-generale-2016/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:8;a:6:{s:4:"data";s:39:"\n		\n		\n		\n		\n		\n				\n		\n\n		\n		\n		\n		\n		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:41:"WPFR partenaire du WordCamp Bordeaux 2017";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:67:"http://feedproxy.google.com/~r/WordpressFrancophone/~3/2P7jo3IVeaQ/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:65:"https://wpfr.net/wpfr-partenaire-wordcamp-bordeaux-2017/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 09 Nov 2016 15:18:41 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:4:"Blog";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"WordCamp";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:27:"https://wpfr.net/?p=1602776";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1531:"L&#8217;équipe WPFR est fière de vous annoncer la mise en place d&#8217;un partenariat avec l&#8217;équipe organisatrice du WordCamp Bordeaux 2017. L&#8217;événement aura lieu le 18 mars 2017 dans la capitale girondine avec 300 participants attendus. Le WordCamp Bordeaux est attendu depuis de nombreuses années maintenant. L&#8217;idée avait été émise par les communautés locales (WPMX, meetup<div class="btn btn-default read-more text-uppercase">Lire la suite <span class="meta-nav"><i class="fa fa-caret-right"></i></span></div><div class="feedflare">\n<a href="http://feeds.feedburner.com/~ff/WordpressFrancophone?a=2P7jo3IVeaQ:eywHXTJv858:yIl2AUoC8zA"><img src="http://feeds.feedburner.com/~ff/WordpressFrancophone?d=yIl2AUoC8zA" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/WordpressFrancophone?a=2P7jo3IVeaQ:eywHXTJv858:V_sGLiPBpWU"><img src="http://feeds.feedburner.com/~ff/WordpressFrancophone?i=2P7jo3IVeaQ:eywHXTJv858:V_sGLiPBpWU" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/WordpressFrancophone?a=2P7jo3IVeaQ:eywHXTJv858:qj6IDK7rITs"><img src="http://feeds.feedburner.com/~ff/WordpressFrancophone?d=qj6IDK7rITs" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/WordpressFrancophone?a=2P7jo3IVeaQ:eywHXTJv858:gIN9vFwOqvQ"><img src="http://feeds.feedburner.com/~ff/WordpressFrancophone?i=2P7jo3IVeaQ:eywHXTJv858:gIN9vFwOqvQ" border="0"></img></a>\n</div><img src="http://feeds.feedburner.com/~r/WordpressFrancophone/~4/2P7jo3IVeaQ" height="1" width="1" alt=""/>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:15:"Aurélien Denis";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:61:"https://wpfr.net/wpfr-partenaire-wordcamp-bordeaux-2017/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:42:"http://rssnamespace.org/feedburner/ext/1.0";a:1:{s:8:"origLink";a:1:{i:0;a:5:{s:4:"data";s:56:"https://wpfr.net/wpfr-partenaire-wordcamp-bordeaux-2017/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:9;a:6:{s:4:"data";s:39:"\n		\n		\n		\n		\n		\n				\n		\n\n		\n		\n		\n		\n		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:42:"Un nouveau site pour WordPress Francophone";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:67:"http://feedproxy.google.com/~r/WordpressFrancophone/~3/5e8SDCecxmc/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:44:"https://wpfr.net/nouveau-site-wpfr/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 15 Sep 2016 07:59:12 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:16:"Association WPFR";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:4:"Blog";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:27:"https://wpfr.net/?p=1566674";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1538:"Après plus de quatre mois de chantier, nous sommes fiers de vous présenter le nouveau site WPFR ! Nous l’avions annoncé en mai, le site de l’association était en cours de refonte, l’ancien étant dépassé tant en termes d’aspect que de fonctionnalités. Une quinzaine de bénévoles ont répondu à notre appel pour travailler avec nous sur ce projet. Cette entreprise a aujourd’hui porté<div class="btn btn-default read-more text-uppercase">Lire la suite <span class="meta-nav"><i class="fa fa-caret-right"></i></span></div><div class="feedflare">\n<a href="http://feeds.feedburner.com/~ff/WordpressFrancophone?a=5e8SDCecxmc:fbo_cDZLcxU:yIl2AUoC8zA"><img src="http://feeds.feedburner.com/~ff/WordpressFrancophone?d=yIl2AUoC8zA" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/WordpressFrancophone?a=5e8SDCecxmc:fbo_cDZLcxU:V_sGLiPBpWU"><img src="http://feeds.feedburner.com/~ff/WordpressFrancophone?i=5e8SDCecxmc:fbo_cDZLcxU:V_sGLiPBpWU" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/WordpressFrancophone?a=5e8SDCecxmc:fbo_cDZLcxU:qj6IDK7rITs"><img src="http://feeds.feedburner.com/~ff/WordpressFrancophone?d=qj6IDK7rITs" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/WordpressFrancophone?a=5e8SDCecxmc:fbo_cDZLcxU:gIN9vFwOqvQ"><img src="http://feeds.feedburner.com/~ff/WordpressFrancophone?i=5e8SDCecxmc:fbo_cDZLcxU:gIN9vFwOqvQ" border="0"></img></a>\n</div><img src="http://feeds.feedburner.com/~r/WordpressFrancophone/~4/5e8SDCecxmc" height="1" width="1" alt=""/>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Willy Bahuaud";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:40:"https://wpfr.net/nouveau-site-wpfr/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:2:"29";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:42:"http://rssnamespace.org/feedburner/ext/1.0";a:1:{s:8:"origLink";a:1:{i:0;a:5:{s:4:"data";s:35:"https://wpfr.net/nouveau-site-wpfr/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}s:44:"http://purl.org/rss/1.0/modules/syndication/";a:2:{s:12:"updatePeriod";a:1:{i:0;a:5:{s:4:"data";s:6:"hourly";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:15:"updateFrequency";a:1:{i:0;a:5:{s:4:"data";s:1:"1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:27:"http://www.w3.org/2005/Atom";a:1:{s:4:"link";a:2:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:3:{s:3:"rel";s:4:"self";s:4:"type";s:19:"application/rss+xml";s:4:"href";s:48:"http://feeds.feedburner.com/WordpressFrancophone";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:2:{s:3:"rel";s:3:"hub";s:4:"href";s:32:"http://pubsubhubbub.appspot.com/";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:42:"http://rssnamespace.org/feedburner/ext/1.0";a:4:{s:4:"info";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:1:{s:3:"uri";s:20:"wordpressfrancophone";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:14:"emailServiceId";a:1:{i:0;a:5:{s:4:"data";s:20:"WordpressFrancophone";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:18:"feedburnerHostname";a:1:{i:0;a:5:{s:4:"data";s:29:"https://feedburner.google.com";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:9:"feedFlare";a:9:{i:0;a:5:{s:4:"data";s:24:"Subscribe with NewsGator";s:7:"attribs";a:1:{s:0:"";a:2:{s:4:"href";s:112:"http://www.newsgator.com/ngs/subscriber/subext.aspx?url=http%3A%2F%2Ffeeds.feedburner.com%2FWordpressFrancophone";s:3:"src";s:42:"http://www.newsgator.com/images/ngsub1.gif";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:24:"Subscribe with Bloglines";s:7:"attribs";a:1:{s:0:"";a:2:{s:4:"href";s:77:"http://www.bloglines.com/sub/http://feeds.feedburner.com/WordpressFrancophone";s:3:"src";s:48:"http://www.bloglines.com/images/sub_modern11.gif";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:23:"Subscribe with Netvibes";s:7:"attribs";a:1:{s:0:"";a:2:{s:4:"href";s:98:"http://www.netvibes.com/subscribe.php?url=http%3A%2F%2Ffeeds.feedburner.com%2FWordpressFrancophone";s:3:"src";s:39:"//www.netvibes.com/img/add2netvibes.gif";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:3;a:5:{s:4:"data";s:21:"Subscribe with Google";s:7:"attribs";a:1:{s:0:"";a:2:{s:4:"href";s:93:"http://fusion.google.com/add?feedurl=http%3A%2F%2Ffeeds.feedburner.com%2FWordpressFrancophone";s:3:"src";s:51:"http://buttons.googlesyndication.com/fusion/add.gif";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:4;a:5:{s:4:"data";s:25:"Subscribe with Pageflakes";s:7:"attribs";a:1:{s:0:"";a:2:{s:4:"href";s:101:"http://www.pageflakes.com/subscribe.aspx?url=http%3A%2F%2Ffeeds.feedburner.com%2FWordpressFrancophone";s:3:"src";s:87:"http://www.pageflakes.com/ImageFile.ashx?instanceId=Static_4&fileName=ATP_blu_91x17.gif";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:5;a:5:{s:4:"data";s:21:"Subscribe with Plusmo";s:7:"attribs";a:1:{s:0:"";a:2:{s:4:"href";s:86:"http://www.plusmo.com/add?url=http%3A%2F%2Ffeeds.feedburner.com%2FWordpressFrancophone";s:3:"src";s:43:"http://plusmo.com/res/graphics/fbplusmo.gif";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:6;a:5:{s:4:"data";s:23:"Subscribe with Live.com";s:7:"attribs";a:1:{s:0:"";a:2:{s:4:"href";s:81:"http://www.live.com/?add=http%3A%2F%2Ffeeds.feedburner.com%2FWordpressFrancophone";s:3:"src";s:141:"http://tkfiles.storage.msn.com/x1piYkpqHC_35nIp1gLE68-wvzLZO8iXl_JMledmJQXP-XTBOLfmQv4zhj4MhcWEJh_GtoBIiAl1Mjh-ndp9k47If7hTaFno0mxW9_i3p_5qQw";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:7;a:5:{s:4:"data";s:25:"Subscribe with Mon Yahoo!";s:7:"attribs";a:1:{s:0:"";a:2:{s:4:"href";s:99:"https://add.my.yahoo.com/content?lg=fr&url=http%3A%2F%2Ffeeds.feedburner.com%2FWordpressFrancophone";s:3:"src";s:60:"http://us.i1.yimg.com/us.yimg.com/i/us/my/bn/intatm_fr_1.gif";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:8;a:5:{s:4:"data";s:25:"Subscribe with Excite MIX";s:7:"attribs";a:1:{s:0:"";a:2:{s:4:"href";s:89:"http://mix.excite.eu/add?feedurl=http%3A%2F%2Ffeeds.feedburner.com%2FWordpressFrancophone";s:3:"src";s:42:"http://image.excite.co.uk/mix/addtomix.gif";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:52:"http://backend.userland.com/creativeCommonsRssModule";a:1:{s:7:"license";a:1:{i:0;a:5:{s:4:"data";s:49:"http://creativecommons.org/licenses/by-nc-sa/3.0/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}}}}}}s:4:"type";i:128;s:7:"headers";O:42:"Requests_Utility_CaseInsensitiveDictionary":1:{s:7:"\0*\0data";a:10:{s:12:"content-type";s:23:"text/xml; charset=UTF-8";s:4:"etag";s:27:"hbYb5dscSUNhZavAqR2kTP1OoAM";s:13:"last-modified";s:29:"Thu, 20 Jul 2017 15:20:02 GMT";s:16:"content-encoding";s:4:"gzip";s:4:"date";s:29:"Thu, 20 Jul 2017 15:49:42 GMT";s:7:"expires";s:29:"Thu, 20 Jul 2017 15:49:42 GMT";s:13:"cache-control";s:18:"private, max-age=0";s:22:"x-content-type-options";s:7:"nosniff";s:16:"x-xss-protection";s:13:"1; mode=block";s:6:"server";s:3:"GSE";}}s:5:"build";s:14:"20130911020210";}', 'no'),
(121, '_transient_timeout_feed_mod_66a70e9599b658d5cc038e8074597e7c', '1500608982', 'no'),
(122, '_transient_feed_mod_66a70e9599b658d5cc038e8074597e7c', '1500565782', 'no'),
(123, '_transient_timeout_feed_76f8d9281c01f21e505004d0986f50c6', '1500608982', 'no');
INSERT INTO `essor_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(124, '_transient_feed_76f8d9281c01f21e505004d0986f50c6', 'a:4:{s:5:"child";a:1:{s:0:"";a:1:{s:3:"rss";a:1:{i:0;a:6:{s:4:"data";s:5:"\n		\n	";s:7:"attribs";a:1:{s:0:"";a:1:{s:7:"version";s:3:"2.0";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:1:{s:7:"channel";a:1:{i:0;a:6:{s:4:"data";s:79:"\n		\n		\n		\n		\n		\n		\n					\n						\n						\n						\n						\n						\n						\n						\n					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:4:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:30:"Planète WordPress Francophone";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:17:"https://wpfr.net/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:49:"Toute l’actualité de WordPress en français !";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"language";a:1:{i:0;a:5:{s:4:"data";s:5:"fr-FR";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"item";a:8:{i:0;a:6:{s:4:"data";s:84:"\n		        \n		        \n		        \n		        \n		        \n		        \n		        \n		    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:4:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:56:"Comment créer un site pour photographe avec WordPress ?";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:51:"http://feedproxy.google.com/~r/wpfr/~3/lIgCrYfDu0g/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:138:"https://wpformation.com/comment-creer-site-photographe-wordpress/?utm_medium=feed&utm_source=feedpress.me&utm_campaign=Feed%3A+wpformation";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 14 Jul 2017 07:30:12 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:562:"\n		        Je vais vous faire une confidence. J''ai toujours aimé la photographie. Et, bien que je ne sois pas devenue l''une d''entre eux, il m''est arrivé de réaliser de nombreux sites WordPress pour des photographes. WordPress aime aussi la photographie et les photographes. Voilà pourquoi je vous propose aujourd''hui une série de conseils et de thèmes [&#8230;]\n\n\nComment créer un site pour photographe avec WordPress ? est un article de WP FormationFormation WordPress &amp; WooCommerce - Pour ne rien manquer : Abonnez-vous à la newsletter !\n		        ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WP Formation";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:1343:"<p><img width="1129" height="425" src="https://cdn.wpformation.com/wp-content/uploads/2017/07/photographe-WordPress.jpg" class="attachment-Large size-Large wp-post-image" alt="photographe wordpress" style="margin-left: 0px;margin-right: auto;margin-top:10px;margin-bottom:10px;max-width: 640px;max-height: 400px" />Je vais vous faire une confidence. J''ai toujours aimé la photographie. Et, bien que je ne sois pas devenue l''une d''entre eux, il m''est arrivé de réaliser de nombreux sites WordPress pour des photographes. WordPress aime aussi la photographie et les photographes. Voilà pourquoi je vous propose aujourd''hui une série de conseils et de thèmes [&#8230;]</p>\n<p></p>\n<hr>\n<a rel="nofollow" href="https://wpformation.com/comment-creer-site-photographe-wordpress/">Comment créer un site pour photographe avec WordPress ?</a> est un article de <a title="Formation WordPress Ecommerce" href="https://wpformation.com">WP Formation</a><br /><a href="https://wpformation.com/formation-wordpress/">Formation WordPress</a> &amp; <a href="https://wpformation.com/formation-woocommerce-e-commerce/">WooCommerce</a> - Pour ne rien manquer : <a href="https://wpformation.com/abonnement-newsletter-wpf/">Abonnez-vous à la newsletter</a> !</p>\n<hr><img src="http://feeds.feedburner.com/~r/wpfr/~4/lIgCrYfDu0g" height="1" width="1" alt=""/>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:42:"http://rssnamespace.org/feedburner/ext/1.0";a:1:{s:8:"origLink";a:1:{i:0;a:5:{s:4:"data";s:138:"https://wpformation.com/comment-creer-site-photographe-wordpress/?utm_medium=feed&utm_source=feedpress.me&utm_campaign=Feed%3A+wpformation";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:1;a:6:{s:4:"data";s:84:"\n		        \n		        \n		        \n		        \n		        \n		        \n		        \n		    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:4:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:69:"Infographie : utilisation de WordPress par la communauté Francophone";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:51:"http://feedproxy.google.com/~r/wpfr/~3/BvAqn_0n_ic/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:91:"http://www.geekpress.fr/infographie-utilisation-de-wordpress-par-la-communaute-francophone/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 13 Jul 2017 06:00:11 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:547:"\n		        Après quelques semaines de sondage, voici enfin les résultats ! Pas moins de 1000 personnes ont répondu à l&#8217;enquête, ce qui m&#8217;a permis de dresser une belle infographie pleine de données intéressantes ! L&#8217;article présente tout d&#8217;abord l&#8217;infographie puis une analyse un peu plus poussée des chiffres en deuxième partie. Aller directement à l&#8217;analyse 1. [&#8230;]\nCet article Infographie : utilisation de WordPress par la communauté Francophone est apparu en premier sur GeekPress.		        ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:9:"Geekpress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:805:"<p>Après quelques semaines de sondage, voici enfin les résultats ! Pas moins de 1000 personnes ont répondu à l&#8217;enquête, ce qui m&#8217;a permis de dresser une belle infographie pleine de données intéressantes ! L&#8217;article présente tout d&#8217;abord l&#8217;infographie puis une analyse un peu plus poussée des chiffres en deuxième partie. Aller directement à l&#8217;analyse 1. [&#8230;]</p>\n<p>Cet article <a rel="nofollow" href="http://www.geekpress.fr/infographie-utilisation-de-wordpress-par-la-communaute-francophone/">Infographie : utilisation de WordPress par la communauté Francophone</a> est apparu en premier sur <a rel="nofollow" href="http://www.geekpress.fr">GeekPress</a>.</p><img src="http://feeds.feedburner.com/~r/wpfr/~4/BvAqn_0n_ic" height="1" width="1" alt=""/>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:42:"http://rssnamespace.org/feedburner/ext/1.0";a:1:{s:8:"origLink";a:1:{i:0;a:5:{s:4:"data";s:91:"http://www.geekpress.fr/infographie-utilisation-de-wordpress-par-la-communaute-francophone/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:2;a:6:{s:4:"data";s:84:"\n		        \n		        \n		        \n		        \n		        \n		        \n		        \n		    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:4:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:50:"SecuPress change de main : chance ou catastrophe ?";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:51:"http://feedproxy.google.com/~r/wpfr/~3/mW7n7NuPrXw/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:90:"https://www.wpnormandie.fr/vue-ailleur-web/secupress-change-de-main-chance-ou-catastrophe/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 12 Jul 2017 13:46:00 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:340:"\n		        C’est sur le blog officiel de WP Media (cf. lien en fin d’article) que l’on apprend que le plugin de sécurité SecuPress change de main. En effet WP Media a décidé de ne plus commercialiser le plugin et de confier l’avenir de celui-ci à son auteur historique : Julio Potier (Boite à Web). Dans le [&#8230;]		        ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:410:"C’est sur le blog officiel de WP Media (cf. lien en fin d’article) que l’on apprend que le plugin de sécurité SecuPress change de main. En effet WP Media a décidé de ne plus commercialiser le plugin et de confier l’avenir de celui-ci à son auteur historique : Julio Potier (Boite à Web). Dans le [&#8230;]<img src="http://feeds.feedburner.com/~r/wpfr/~4/mW7n7NuPrXw" height="1" width="1" alt=""/>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:42:"http://rssnamespace.org/feedburner/ext/1.0";a:1:{s:8:"origLink";a:1:{i:0;a:5:{s:4:"data";s:90:"https://www.wpnormandie.fr/vue-ailleur-web/secupress-change-de-main-chance-ou-catastrophe/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:3;a:6:{s:4:"data";s:84:"\n		        \n		        \n		        \n		        \n		        \n		        \n		        \n		    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:4:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:51:"Installer WordPress en local avec Local by Flywheel";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:51:"http://feedproxy.google.com/~r/wpfr/~3/LwKc5XsSdC8/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:57:"https://wpchannel.com/installer-wordpress-local-flywheel/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 11 Jul 2017 18:37:41 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:401:"\n		        Développer un site WordPress en local avant de le mettre en production est une méthode de travail largement répandue. Néanmoins, les outils mis à disposition des développeurs que sont MAMP sous MacOS ou WAMP sous Windows ne sont pas toujours simple d&#8217;utilisation. C&#8217;était sans compter l&#8217;apparition de Local by Flywheel, un nouvel outil qui gagne [&#8230;]		        ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:10:"WP Channel";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:674:"<img width="449" height="300" src="https://wpchannel.com/images/2016/11/wp-code-449x300.jpg" class="webfeedsFeaturedVisual wp-post-image" alt="" style="margin: auto;margin-bottom: 5px;max-width: 100%" />Développer un site WordPress en local avant de le mettre en production est une méthode de travail largement répandue. Néanmoins, les outils mis à disposition des développeurs que sont MAMP sous MacOS ou WAMP sous Windows ne sont pas toujours simple d&#8217;utilisation. C&#8217;était sans compter l&#8217;apparition de Local by Flywheel, un nouvel outil qui gagne [&#8230;]<img src="http://feeds.feedburner.com/~r/wpfr/~4/LwKc5XsSdC8" height="1" width="1" alt=""/>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:42:"http://rssnamespace.org/feedburner/ext/1.0";a:1:{s:8:"origLink";a:1:{i:0;a:5:{s:4:"data";s:57:"https://wpchannel.com/installer-wordpress-local-flywheel/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:4;a:6:{s:4:"data";s:84:"\n		        \n		        \n		        \n		        \n		        \n		        \n		        \n		    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:4:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:68:"Comment ajouter l’adresse dans la barre de menu supérieur de Divi";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:51:"http://feedproxy.google.com/~r/wpfr/~3/Yt-aaue9oYc/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:49:"https://wpmarmite.com/snippet/adresse-barre-divi/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 11 Jul 2017 09:51:15 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:415:"\n		        \nSi vous utilisez le thème Divi ( ou plutôt un thème enfant de Divi 😉 ), vous avez surement remarqué que les options de celui-ci ne permettent que d&rsquo;ajouter son...\nComment ajouter l&rsquo;adresse dans la barre de menu supérieur de Divi est un article de WP Marmite, le blog qui vous aide à tirer le meilleur de WordPress.\nAbonnez-vous à la newsletter pour recevoir les suivants.		        ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:10:"WP Marmite";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:867:"<p><img width="640" height="220" src="https://media-6d6e.kxcdn.com/wp-content/uploads/2017/06/divi-snippet.jpg" class="attachment-full size-full wp-post-image" alt="divi snippet" /></p>\n<p>Si vous utilisez le thème Divi ( ou plutôt un thème enfant de Divi 😉 ), vous avez surement remarqué que les options de celui-ci ne permettent que d&rsquo;ajouter son...</p>\n<p><a rel="nofollow" href="https://wpmarmite.com/snippet/adresse-barre-divi/">Comment ajouter l&rsquo;adresse dans la barre de menu supérieur de Divi</a> est un article de <a rel="nofollow" href="https://wpmarmite.com">WP Marmite</a>, le blog qui vous aide à tirer le meilleur de WordPress.<br />\n<a href="https://wpmarmite.com/newsletter">Abonnez-vous à la newsletter</a> pour recevoir les suivants.</p><img src="http://feeds.feedburner.com/~r/wpfr/~4/Yt-aaue9oYc" height="1" width="1" alt=""/>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:42:"http://rssnamespace.org/feedburner/ext/1.0";a:1:{s:8:"origLink";a:1:{i:0;a:5:{s:4:"data";s:49:"https://wpmarmite.com/snippet/adresse-barre-divi/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:5;a:6:{s:4:"data";s:84:"\n		        \n		        \n		        \n		        \n		        \n		        \n		        \n		    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:4:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:44:"15 plugins de eCommerce pour votre WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:51:"http://feedproxy.google.com/~r/wpfr/~3/D1szmkPT5lI/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:131:"https://wpformation.com/15-plugins-de-ecommerce-wordpress/?utm_medium=feed&utm_source=feedpress.me&utm_campaign=Feed%3A+wpformation";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 10 Jul 2017 07:00:00 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:595:"\n		        WordPress existe depuis un petit moment déjà ! D''une simple plateforme de blogging, il est devenu un CMS à part entière qui possède de puissantes fonctions en e-commerce. Avec les extensions adéquates, vous pouvez faire de WordPress un e-commerce aux multiples fonctionnalités. Chacun des plugins mentionnés ci-après a ses propres forces et faiblesses, certains correspondront bien [&#8230;]\n\n\n15 plugins de eCommerce pour votre WordPress est un article de WP FormationFormation WordPress &amp; WooCommerce - Pour ne rien manquer : Abonnez-vous à la newsletter !\n		        ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WP Formation";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:1387:"<p><img width="1200" height="675" src="https://cdn.wpformation.com/wp-content/uploads/2016/10/15-plugins-ecommerce-wordpress.jpg" class="attachment-Large size-Large wp-post-image" alt="15-plugins-ecommerce-wordpress" style="margin-left: 0px;margin-right: auto;margin-top:10px;margin-bottom:10px;max-width: 640px;max-height: 400px" />WordPress existe depuis un petit moment déjà ! D''une simple plateforme de blogging, il est devenu un CMS à part entière qui possède de puissantes fonctions en e-commerce. Avec les extensions adéquates, vous pouvez faire de WordPress un e-commerce aux multiples fonctionnalités. Chacun des plugins mentionnés ci-après a ses propres forces et faiblesses, certains correspondront bien [&#8230;]</p>\n<p></p>\n<hr>\n<a rel="nofollow" href="https://wpformation.com/15-plugins-de-ecommerce-wordpress/">15 plugins de eCommerce pour votre WordPress</a> est un article de <a title="Formation WordPress Ecommerce" href="https://wpformation.com">WP Formation</a><br /><a href="https://wpformation.com/formation-wordpress/">Formation WordPress</a> &amp; <a href="https://wpformation.com/formation-woocommerce-e-commerce/">WooCommerce</a> - Pour ne rien manquer : <a href="https://wpformation.com/abonnement-newsletter-wpf/">Abonnez-vous à la newsletter</a> !</p>\n<hr><img src="http://feeds.feedburner.com/~r/wpfr/~4/D1szmkPT5lI" height="1" width="1" alt=""/>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:42:"http://rssnamespace.org/feedburner/ext/1.0";a:1:{s:8:"origLink";a:1:{i:0;a:5:{s:4:"data";s:131:"https://wpformation.com/15-plugins-de-ecommerce-wordpress/?utm_medium=feed&utm_source=feedpress.me&utm_campaign=Feed%3A+wpformation";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:6;a:6:{s:4:"data";s:84:"\n		        \n		        \n		        \n		        \n		        \n		        \n		        \n		    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:4:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:39:"L’onglet « texte » avec Gutenberg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:84:"http://feedproxy.google.com/~r/wpfr/~3/IyT0OAMG-tU/onglet-texte-gutenberg-10064.html";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:54:"https://boiteaweb.fr/onglet-texte-gutenberg-10064.html";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 08 Jul 2017 22:56:13 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:382:"\n		        Gutenberg par-ci, Gutenberg par-là. Tout le monde parle de ce nouvel éditeur prévu pour WordPress 5.0 et c&#8217;est tant mieux ! Une des premières choses que j&#8217;ai regardées quand je l&#8217;ai testé c&#8217;est l&#8217;onglet de texte, car je me suis de suite demandé « ok mais ça sort quoi en front alors ? ». WHAT??? Ok, j&#8217;ai&#160;…		        ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:452:"Gutenberg par-ci, Gutenberg par-là. Tout le monde parle de ce nouvel éditeur prévu pour WordPress 5.0 et c&#8217;est tant mieux ! Une des premières choses que j&#8217;ai regardées quand je l&#8217;ai testé c&#8217;est l&#8217;onglet de texte, car je me suis de suite demandé « ok mais ça sort quoi en front alors ? ». WHAT??? Ok, j&#8217;ai&#160;…<img src="http://feeds.feedburner.com/~r/wpfr/~4/IyT0OAMG-tU" height="1" width="1" alt=""/>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:42:"http://rssnamespace.org/feedburner/ext/1.0";a:1:{s:8:"origLink";a:1:{i:0;a:5:{s:4:"data";s:54:"https://boiteaweb.fr/onglet-texte-gutenberg-10064.html";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:7;a:6:{s:4:"data";s:84:"\n		        \n		        \n		        \n		        \n		        \n		        \n		        \n		    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:4:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:29:"Your WordCamp Europe Memories";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:51:"http://feedproxy.google.com/~r/wpfr/~3/fBwnCkCZycQ/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:74:"https://2017.europe.wordcamp.org/2017/07/07/your-wordcamp-europe-memories/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 07 Jul 2017 08:58:38 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:400:"\n		        Thank you to those of you who shared your memories from WordCamp Europe 2017 to your blogs! We&#8217;ve collected a list of your articles, photo collections, and podcasts below. 🙂 Articles Benoit Gütz, Savvii, WordCamp Europe 2017 Takeaways. Jean Galea, WP Mayor, WordCamp Europe 2017 – An Awesome Event. Alex Preukschat, PixelRockstar, Paris full of Wapuu Love [&#8230;]		        ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:15:"WordCamp Europe";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:11208:"<p><img class="aligncenter wp-image-8408 size-full" src="https://i1.wp.com/2017.europe.wordcamp.org/files/2017/07/memories.jpg?resize=640%2C366" alt="" />Thank you to those of you who shared your memories from WordCamp Europe 2017 to your blogs! We&#8217;ve collected a list of your articles, photo collections, and podcasts below. <img src="https://s.w.org/images/core/emoji/2.3/72x72/1f642.png" alt="🙂" class="wp-smiley" style="height: 1em;max-height: 1em" /><span id="more-8391"></span></p>\n<h2>Articles</h2>\n<ul>\n<li>Benoit Gütz, Savvii, <a href="https://www.savvii.eu/blog/wordcamp-europe-2017-takeaways/">WordCamp Europe 2017 Takeaways</a>.</li>\n<li>Jean Galea, WP Mayor, <a href="https://www.wpmayor.com/wordcamp-europe-2017-awesome-event/">WordCamp Europe 2017 – An Awesome Event</a>.</li>\n<li>Alex Preukschat, PixelRockstar, <a href="https://www.pixelrockstar.com/paris-wapuu-love-wordcamp-europe-2017/">Paris full of Wapuu Love – WordCamp Europe 2017</a>.</li>\n<li>Sarah Gooding, WP Tavern, <a href="https://wptavern.com/wordcamp-europe-2017-draws-1900-attendees-from-79-countries">WordCamp Europe 2017 Draws 1900 Attendees from 79 Countries</a>.</li>\n<li>Adrien Pantanella, Pop Startup, <a href="http://popstartup.fr/en/wordcamp-europe-2017/">Back on two days in the heart of WordPress</a>.</li>\n<li>Rich Hill, <a href="http://richhill.blog/thoughts-on-wordcamp-europe-paris-2017/">Thoughts on WordCamp Europe, Paris 2017</a>.</li>\n<li>M Asif Rahman, weDevs, <a href="https://wedevs.com/90400/wordcamp-europe-2017-experience/">Our WordCamp Europe 2017 Experience: Is It Worth Sponsoring?</a></li>\n<li>Dwayne McDaniel, <a href="https://www.mcdwayne.com/2017/06/20/wceu-paris/">WCEU: Paris is hot in the summer and you have to walk a lot. Who knew?</a></li>\n<li>Jenny Beaumont, <a href="http://www.jennybeaumont.com/youve-gotta-be-nuts/">You&#8217;ve Gotta Be Nuts</a>.</li>\n<li>Andrei Lupu, <a href="https://andrei-lupu.com/wordcamp/my-journey-at-wordcamp-europe-2017/">My Journey At WordCamp Europe 2017</a>.</li>\n<li>Lucijan Blagonic, Polar North, <a href="http://polarnorth.org/blog/wordcamp-europe-2017/">WordCamp Europe 2017</a>.</li>\n<li>Andrea Volpini, WordLift, <a href="https://wordlift.io/blog/en/5-reasons-to-attend-the-next-wordcamp/">5 Reasons to attend the next WordCamp – A lesson learned at WCEU 2017</a>.</li>\n<li>Ben Pines, Elementor, <a href="https://elementor.com/wceu-2017/">Our Experience &amp; Takeaways From WordCamp Europe 2017</a>.</li>\n<li>Swan Legacy, <a href="https://swanlegacywebdesign.com/2017/06/19/wceu-paris-2017-my-5-minutes-opinion/">#WCEU Paris 2017: My 5-Minute Opinion</a>.</li>\n<li>Aaron Campbell, GoDaddy, <a href="https://www.godaddy.com/garage/industry/tech-svcs/wordpress/wceu-looking-back-on-wordcamp-europe-2017/">#WCEU: Looking back on WordCamp Europe 2017</a>.</li>\n<li>ThemeIsle, <a href="https://themeisle.com/blog/wordcamp-europe-wceu-2017-reflections/">WordCamp Europe #WCEU 2017 – What People Are Saying + Our Reflections and Lessons Learned</a>.</li>\n<li>Pragmatic, <a href="https://pragmatic.agency/wordcamp-europe-2017/">Our takeaways from WordCamp Europe 2017</a>.</li>\n<li>Robin Singh, Performance Foundry, <a href="https://performancefoundry.com/business/wordcamp-paris-2017/">Experiences from WordCamp, Paris 2017</a>.</li>\n<li>Edmund Turbin, WP Engine, <a href="https://wpengine.com/blog/wordcamp-europe-2017-recap/">Thoughts and Highlights from WordCamp Europe 2017</a>.</li>\n<li>Marie Dodson, Torque, <a href="https://torquemag.io/2017/06/wordcamp-europe-2017-wordpress-speaks-all-languages/">WordCamp Europe 2017: WordPress Speaks All Languages</a>.</li>\n<li>Nick Schäferhoff, <a href="https://torquemag.io/2017/06/wordcamp-europe-2017/">A Detailed Report From WordCamp Europe 2017 in Paris</a>.</li>\n<li>Null Shop, <a href="http://null.shop/wordcamp-europe-wceu-2017-what-people-are-saying-our-reflections-and-lessons-learned/">WordCamp Europe #WCEU 2017 – What People Are Saying + Our Reflections and Lessons Learned</a>.</li>\n<li>Cozmoslabs, <a href="https://www.cozmoslabs.com/93534-wordcamp-europe-2017-cozmosteaminparis">Summary of WordCamp Europe 2017 – #CozmosTeamInParis</a>.</li>\n<li>Rhys Wynne, Winwar Media, <a href="https://www.winwar.co.uk/2017/06/three-thoughts-wordcamp-europe-2017/">Three Thoughts From WordCamp Europe 2017</a>.</li>\n<li>Adam Warner, SiteLock, <a href="https://wpdistrict.sitelock.com/blog/wordcamp-europe-2017-recap/">WordCamp Europe 2017 Recap</a>.</li>\n<li>Oana Filip, PixelGrade, <a href="https://pixelgrade.com/blog/culture/wordcamp-paris-2017/">Insights from Our Crew on WordCamp Paris 2017</a>.</li>\n<li>Rian Rietveld, Make WordPress Accessible, <a href="https://make.wordpress.org/accessibility/2017/06/27/takeaways-from-paris/">Takeaways from Paris</a>.</li>\n<li>Kevin Muldoon, <a href="http://www.kevinmuldoon.com/wordcamp-europe-2017/">My Experience at WordCamp Europe 2017 in Paris #WCEU</a></li>\n<li>Kobe Ben Itamar, Freemius, <a href="https://freemius.com/blog/wordcamp-europe-2017/">WordCamp Europe 2017 – The WordPress Product People’s Perspective</a>.</li>\n<li>Andrew Dixon, mso Digital Agency, <a href="https://www.mso.net/news/wordcamp-europe-2017">WordCamp Europe 2017</a>.</li>\n<li>Isabelle Garcia, <a href="http://www.aicragellebasi.social/souvenirs-from-the-wordcamp-europe-2017-video-team/">Souvenirs from the WordCamp Europe 2017 Video Team</a>.</li>\n<li>James, LlamaPress, <a href="https://llamapress.com/wordcamp-europe-2017-experience/?">WordCamp Europe 2017 – My Experience</a>.</li>\n<li>Petya Raykovska, <a href="http://petya.in/going-global-i18n-talks-at-wordcamp-europe-2017-wceu/">Going global – i18n talks at WordCamp Europe 2017 | #WCEU</a>.</li>\n<li>Inpsyde, <a href="https://inpsyde.com/en/wapuu-wceu-2017-wordcamp-europe-paris-review/">Wapuu at WCEU 2017 – WordCamp Europe Paris Review</a>.</li>\n<li>Karin Christen, We are required, <a href="https://required.com/wordcamp-europe-paris/">WordCamp Europe in Paris</a>.</li>\n<li>Caspar, GlückPress, <a href="https://glueckpress.com/8399/wordcamp-refugee/">WordCamp Refugee</a>.</li>\n<li>Thorsten Frommen, <a href="https://tfrommen.de/wordcamp-europe-2017-recap/">WordCamp Europe 2017: Recap</a>.</li>\n<li>Marcel Bootsman, <a href="https://marcelbootsman.nl/my-experiences-at-wordcamp-europe-2017-paris/">My experiences at WordCamp Europe 2017 in Paris</a>.</li>\n<li>WP Munich, <a href="http://www.wp-munich.com/events/gutenberg-wordpress-performance-accessibility-wceu/">Gutenberg, WordPress Performance and Accessibility – WordCamp Europe 2017</a>.</li>\n<li>WP Munich, <a href="http://www.wp-munich.com/events/what-is-wordcamp/">What is WordCamp Europe and why should you go?</a>.</li>\n<li>Worona, <a href="https://blog.worona.org/our-takeaways-from-wordcamp-europe-2017/">Our Takeaways from WordCamp Europe 2017</a></li>\n<li>[SV] Magnus Nilsson, NewSeed, <a href="http://newseed.se/2017/07/03/wordcamp-europe-2017-i-paris/">WordCamp Europe 2017 i Paris</a>.</li>\n<li>[ES] Antonio Villegas, Nelio, <a href="https://neliosoftware.com/es/blog/resumen-wordcamp-europe-2017/">Resumen de la WordCamp Europe 2017</a>.</li>\n<li>[NL] Wendyienator, <a href="http://wendyienator.com/2017-06-23/">WordCamp Eurpoe 2017, een terugblik</a>.</li>\n<li>[NL] Eagerly, <a href="https://www.eagerly.nl/lessen-wordcamp-europe-2017-parijs/">De lessen van WordCamp Europe 2017 Parijs</a>.</li>\n<li>[NL] Jeroen Rotty, <a href="https://jerrix.blog/persoonlijk/terug-thuis-na-wordcamp-europe-2017/">Terug thuis na WordCamp Europe 2017</a></li>\n<li>[NL] Wouter van der Zee, <a href="http://woutervanderzee.nl/artikelen/3-dingen-geleerd-wordcamp-europe-2107/">3 dingen die ik heb geleerd op WordCamp Europe 2017</a></li>\n<li>[FR] Adrien Pantanella, Pop Startup, <a href="http://popstartup.fr/wordcamp-europe-2017/">Retour sur deux jours au coeur de WordPress</a>.</li>\n<li>[FR] Anybodesign, <a href="https://anybodesign.com/wordcamp-europe-2017-nice-souvenirs/">Nice Souvenirs From The WordCamp Europe</a>.</li>\n<li>[FR] Marie-Hélène Lebée, <a href="https://mhlebee.com/ce-que-jai-appris-au-wordcamp-europe/">Ce que j’ai appris au WordCamp Europe 2017</a>.</li>\n<li>[FR] Mathieu Chartier, Internet-Formation, <a href="https://blog.internet-formation.fr/2017/06/retour-sur-le-wordcamp-europe-a-paris-wceu/">Retour sur le Wordcamp Europe à Paris ! #WCEU</a>.</li>\n<li>[FR] Mathieu Viet, <a href="https://imathi.eu/2017/06/20/la-cinquieme-edition-du-wordcamp-europe-sest-deroulee-a-paris/">La cinquième édition du WordCamp Europe s’est déroulée à Paris</a>.</li>\n<li>[DE] Torben Simon, RAIDBOXES, <a href="https://raidboxes.de/blog/raidboxes-wordpress-news-25/">So revolutioniert Gutenberg WordPress &amp; das WCEU 2017 im Rückblick</a>.</li>\n<li>[DE] Bernhard Kau, <a href="https://kau-boys.de/3378/wordpress/wordcamp-europe-2017-learn-connect-contribute">WordCamp Europe 2017 – Lernen. Verbinden. Mitwirken</a>.</li>\n<li>[DE] Inpsyde, <a href="https://inpsyde.com/blog/wapuu-wceu-2017-wordcamp-europe-paris-review/">Wapuu beim WCEU 2017 – WordCamp Europe Paris Review</a>.</li>\n<li>[DE] Hans-Helge, Webschale, <a href="https://webschale.de/2017/qa-mit-matt-mullenweg/">Q&amp;A mit Matt Mullenweg</a>.</li>\n<li>[DE] Marc Nilius, WP Wartung, <a href="https://www.wp-wartung24.de/wordcamp-europe-2017-in-paris-ein-rueckblick/">WordCamp Europe 2017 in Paris – Ein Rückblick</a>.</li>\n<li>[DE] Haptiq Studio, <a href="https://haptiq.studio/wordcamp-europe-2017-in-paris/">WordCamp Europe 2017 in Paris</a></li>\n</ul>\n<h2>Photos</h2>\n<ul>\n<li>Florian Ziegler, <a href="https://florianziegler.com/wordcamp-europe-2017/">WordCamp Europe 2017</a>.</li>\n<li>Clicky Steve, <a href="https://allmyfriendsarejpegs.com/2017/06/23/wordcamp-eu-2017-paris/">WordCamp EU 2017, Paris</a>.</li>\n<li>Mark Smallman, <a href="https://www.flickr.com/photos/143717954@N08/albums/72157685223487056">WordCamp Europe 2017</a>.</li>\n<li>Marie Dodson, WP Engine, <a href="https://wpengine.com/blog/wordcamp-europe-2017-in-photos/">WordCamp Europe 2017 in Photos</a>.</li>\n<li>David Bisset, <a href="http://davidbisset.com/wordcamp-europe-2017-animated-gifs-day-one/">WordCamp Europe 2017 Animated GIFs (Day One)</a>.</li>\n<li>David Bisset, <a href="http://davidbisset.com/wordcamp-europe-2017-animated-gifs-day-two/">WordCamp Europe 2017 Animated GIFs (Day Two)</a>.</li>\n<li>Omkar Bhagat, <a href="https://omkar.blog/2017/06/20/wordcamp-europe-2017-paris-france/">WordCamp Europe 2017 – Paris, France</a>.</li>\n<li>Andrey Savchenko, <a href="https://www.flickr.com/photos/rarst/sets/72157682333149374">2017 WordCamp Europe</a>.</li>\n</ul>\n<h2>Podcasts</h2>\n<ul>\n<li>Jeff Chandler, WP Tavern, <a href="https://wptavern.com/wpweekly-episode-278-recap-of-wordcamp-europe-2017">WPWeekly Episode 278 – Recap of WordCamp Europe 2017</a>.</li>\n<li>[DE] wpSofa, <a href="https://wp-sofa.de/podcasts/one-mike-in-paris-wordcamp-eu-recap-wceu-folge-42/">One Mike in Paris &#8211; WordCamp EU #WCEU (Episode 42)</a>.</li>\n</ul>\n<hr />\n<p><strong>Did we miss any? If so, please share a link in the comments!</strong></p><img src="http://feeds.feedburner.com/~r/wpfr/~4/fBwnCkCZycQ" height="1" width="1" alt=""/>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:42:"http://rssnamespace.org/feedburner/ext/1.0";a:1:{s:8:"origLink";a:1:{i:0;a:5:{s:4:"data";s:74:"https://2017.europe.wordcamp.org/2017/07/07/your-wordcamp-europe-memories/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}s:52:"http://backend.userland.com/creativeCommonsRssModule";a:1:{s:7:"license";a:1:{i:0;a:5:{s:4:"data";s:49:"http://creativecommons.org/licenses/by-nc-sa/3.0/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:27:"http://www.w3.org/2005/Atom";a:1:{s:4:"link";a:2:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:3:{s:3:"rel";s:4:"self";s:4:"type";s:19:"application/rss+xml";s:4:"href";s:32:"http://feeds.feedburner.com/wpfr";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:2:{s:3:"rel";s:3:"hub";s:4:"href";s:32:"http://pubsubhubbub.appspot.com/";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:42:"http://rssnamespace.org/feedburner/ext/1.0";a:1:{s:4:"info";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:1:{s:3:"uri";s:4:"wpfr";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}}}}}}s:4:"type";i:128;s:7:"headers";O:42:"Requests_Utility_CaseInsensitiveDictionary":1:{s:7:"\0*\0data";a:11:{s:12:"content-type";s:23:"text/xml; charset=UTF-8";s:4:"etag";s:27:"6/IR+vtwx2704eWRFs7s9oPmoJE";s:13:"last-modified";s:29:"Thu, 20 Jul 2017 15:37:07 GMT";s:16:"content-encoding";s:4:"gzip";s:4:"date";s:29:"Thu, 20 Jul 2017 15:49:42 GMT";s:7:"expires";s:29:"Thu, 20 Jul 2017 15:49:42 GMT";s:13:"cache-control";s:18:"private, max-age=0";s:22:"x-content-type-options";s:7:"nosniff";s:16:"x-xss-protection";s:13:"1; mode=block";s:6:"server";s:3:"GSE";s:7:"alt-svc";s:43:"quic=":443"; ma=2592000; v="39,38,37,36,35"";}}s:5:"build";s:14:"20130911020210";}', 'no'),
(125, '_transient_timeout_feed_mod_76f8d9281c01f21e505004d0986f50c6', '1500608982', 'no'),
(126, '_transient_feed_mod_76f8d9281c01f21e505004d0986f50c6', '1500565782', 'no'),
(131, 'can_compress_scripts', '1', 'no'),
(133, '_transient_timeout_plugin_slugs', '1501695678', 'no'),
(134, '_transient_plugin_slugs', 'a:10:{i:0;s:34:"advanced-custom-fields-pro/acf.php";i:1;s:33:"automatic-nbsp/automatic-nbsp.php";i:2;s:29:"bj-lazy-load/bj-lazy-load.php";i:3;s:25:"cbxwpslack/cbxwpslack.php";i:4;s:23:"email-log/email-log.php";i:5;s:45:"ewww-image-optimizer/ewww-image-optimizer.php";i:6;s:27:"redirection/redirection.php";i:7;s:23:"secupress/secupress.php";i:8;s:63:"wp-seo-structured-data-schema/wp-seo-structured-data-schema.php";i:9;s:24:"wordpress-seo/wp-seo.php";}', 'no'),
(135, 'recently_activated', 'a:2:{s:25:"cbxwpslack/cbxwpslack.php";i:1501609277;s:15:"slack/slack.php";i:1501583730;}', 'yes'),
(136, 'theme_mods_twentyseventeen', 'a:1:{s:16:"sidebars_widgets";a:2:{s:4:"time";i:1500565822;s:4:"data";a:4:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:9:"sidebar-2";a:0:{}s:9:"sidebar-3";a:0:{}}}}', 'yes'),
(137, 'current_theme', 'Essor', 'yes'),
(138, 'theme_mods_super', 'a:3:{i:0;b:0;s:18:"custom_css_post_id";i:-1;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1500566961;s:4:"data";a:2:{s:19:"wp_inactive_widgets";a:0:{}s:7:"sidebar";a:0:{}}}}', 'yes'),
(139, 'theme_switched', '', 'yes'),
(150, 'theme_mods_essor', 'a:3:{i:0;b:0;s:18:"custom_css_post_id";i:-1;s:18:"nav_menu_locations";a:2:{s:7:"primary";i:2;s:9:"secondary";i:3;}}', 'yes'),
(155, 'dgwt_automatic_nbsp', 'a:6:{s:18:"before_punctuation";s:1:"1";s:7:"content";s:1:"1";s:5:"words";s:0:"";s:5:"title";s:1:"1";s:7:"excerpt";s:1:"1";s:3:"acf";s:1:"1";}', 'yes'),
(156, 'dgwt_nbsp_version', '1.5.3', 'yes'),
(157, 'email-log-db', '0.1', 'yes'),
(159, 'wpseo', 'a:25:{s:14:"blocking_files";a:0:{}s:15:"ms_defaults_set";b:0;s:7:"version";s:3:"5.1";s:12:"company_logo";s:0:"";s:12:"company_name";s:5:"Essor";s:17:"company_or_person";s:7:"company";s:20:"disableadvanced_meta";b:0;s:19:"onpage_indexability";b:1;s:12:"googleverify";s:0:"";s:8:"msverify";s:0:"";s:11:"person_name";s:0:"";s:12:"website_name";s:0:"";s:22:"alternate_website_name";s:0:"";s:12:"yandexverify";s:0:"";s:9:"site_type";s:0:"";s:20:"has_multiple_authors";b:0;s:16:"environment_type";s:0:"";s:23:"content_analysis_active";b:1;s:23:"keyword_analysis_active";b:1;s:20:"enable_setting_pages";b:1;s:21:"enable_admin_bar_menu";b:1;s:26:"enable_cornerstone_content";b:0;s:24:"enable_text_link_counter";b:1;s:22:"show_onboarding_notice";b:1;s:18:"first_activated_on";i:1500399934;}', 'yes'),
(160, 'wpseo_permalinks', 'a:9:{s:15:"cleanpermalinks";b:0;s:24:"cleanpermalink-extravars";s:0:"";s:29:"cleanpermalink-googlecampaign";b:0;s:31:"cleanpermalink-googlesitesearch";b:0;s:15:"cleanreplytocom";b:0;s:10:"cleanslugs";b:1;s:18:"redirectattachment";b:0;s:17:"stripcategorybase";b:0;s:13:"trailingslash";b:0;}', 'yes'),
(161, 'wpseo_titles', 'a:53:{s:10:"title_test";i:0;s:17:"forcerewritetitle";b:0;s:9:"separator";s:7:"sc-bull";s:15:"usemetakeywords";b:0;s:16:"title-home-wpseo";s:42:"%%sitename%% %%page%% %%sep%% %%sitedesc%%";s:18:"title-author-wpseo";s:41:"%%name%%, Author at %%sitename%% %%page%%";s:19:"title-archive-wpseo";s:38:"%%date%% %%page%% %%sep%% %%sitename%%";s:18:"title-search-wpseo";s:63:"You searched for %%searchphrase%% %%page%% %%sep%% %%sitename%%";s:15:"title-404-wpseo";s:35:"Page not found %%sep%% %%sitename%%";s:19:"metadesc-home-wpseo";s:0:"";s:21:"metadesc-author-wpseo";s:0:"";s:22:"metadesc-archive-wpseo";s:0:"";s:18:"metakey-home-wpseo";s:0:"";s:20:"metakey-author-wpseo";s:0:"";s:22:"noindex-subpages-wpseo";b:0;s:20:"noindex-author-wpseo";b:0;s:21:"noindex-archive-wpseo";b:1;s:14:"disable-author";b:1;s:12:"disable-date";b:1;s:19:"disable-post_format";b:1;s:10:"title-post";s:39:"%%title%% %%page%% %%sep%% %%sitename%%";s:13:"metadesc-post";s:0:"";s:12:"metakey-post";s:0:"";s:12:"noindex-post";b:0;s:13:"showdate-post";b:1;s:16:"hideeditbox-post";b:0;s:10:"title-page";s:39:"%%title%% %%page%% %%sep%% %%sitename%%";s:13:"metadesc-page";s:0:"";s:12:"metakey-page";s:0:"";s:12:"noindex-page";b:0;s:13:"showdate-page";b:0;s:16:"hideeditbox-page";b:0;s:16:"title-attachment";s:39:"%%title%% %%page%% %%sep%% %%sitename%%";s:19:"metadesc-attachment";s:0:"";s:18:"metakey-attachment";s:0:"";s:18:"noindex-attachment";b:0;s:19:"showdate-attachment";b:0;s:22:"hideeditbox-attachment";b:0;s:18:"title-tax-category";s:53:"%%term_title%% Archives %%page%% %%sep%% %%sitename%%";s:21:"metadesc-tax-category";s:0:"";s:20:"metakey-tax-category";s:0:"";s:24:"hideeditbox-tax-category";b:0;s:20:"noindex-tax-category";b:0;s:18:"title-tax-post_tag";s:53:"%%term_title%% Archives %%page%% %%sep%% %%sitename%%";s:21:"metadesc-tax-post_tag";s:0:"";s:20:"metakey-tax-post_tag";s:0:"";s:24:"hideeditbox-tax-post_tag";b:0;s:20:"noindex-tax-post_tag";b:0;s:21:"title-tax-post_format";s:53:"%%term_title%% Archives %%page%% %%sep%% %%sitename%%";s:24:"metadesc-tax-post_format";s:0:"";s:23:"metakey-tax-post_format";s:0:"";s:27:"hideeditbox-tax-post_format";b:0;s:23:"noindex-tax-post_format";b:1;}', 'yes'),
(162, 'wpseo_social', 'a:20:{s:9:"fb_admins";a:0:{}s:12:"fbconnectkey";s:32:"4c131a899da323988171400efd7e8106";s:13:"facebook_site";s:0:"";s:13:"instagram_url";s:0:"";s:12:"linkedin_url";s:0:"";s:11:"myspace_url";s:0:"";s:16:"og_default_image";s:0:"";s:18:"og_frontpage_title";s:0:"";s:17:"og_frontpage_desc";s:0:"";s:18:"og_frontpage_image";s:0:"";s:9:"opengraph";b:1;s:13:"pinterest_url";s:0:"";s:15:"pinterestverify";s:0:"";s:14:"plus-publisher";s:0:"";s:7:"twitter";b:1;s:12:"twitter_site";s:0:"";s:17:"twitter_card_type";s:7:"summary";s:11:"youtube_url";s:0:"";s:15:"google_plus_url";s:0:"";s:10:"fbadminapp";s:0:"";}', 'yes'),
(163, 'wpseo_rss', 'a:2:{s:9:"rssbefore";s:0:"";s:8:"rssafter";s:53:"The post %%POSTLINK%% appeared first on %%BLOGLINK%%.";}', 'yes'),
(164, 'wpseo_internallinks', 'a:10:{s:20:"breadcrumbs-404crumb";s:25:"Error 404: Page not found";s:23:"breadcrumbs-blog-remove";b:0;s:20:"breadcrumbs-boldlast";b:0;s:25:"breadcrumbs-archiveprefix";s:12:"Archives for";s:18:"breadcrumbs-enable";b:0;s:16:"breadcrumbs-home";s:4:"Home";s:18:"breadcrumbs-prefix";s:0:"";s:24:"breadcrumbs-searchprefix";s:16:"You searched for";s:15:"breadcrumbs-sep";s:7:"&raquo;";s:23:"post_types-post-maintax";i:0;}', 'yes'),
(165, 'wpseo_xml', 'a:16:{s:22:"disable_author_sitemap";b:0;s:22:"disable_author_noposts";b:0;s:16:"enablexmlsitemap";b:1;s:16:"entries-per-page";i:1000;s:14:"excluded-posts";s:0:"";s:38:"user_role-administrator-not_in_sitemap";b:0;s:31:"user_role-editor-not_in_sitemap";b:0;s:31:"user_role-author-not_in_sitemap";b:0;s:36:"user_role-contributor-not_in_sitemap";b:0;s:35:"user_role-subscriber-not_in_sitemap";b:0;s:30:"post_types-post-not_in_sitemap";b:0;s:30:"post_types-page-not_in_sitemap";b:0;s:36:"post_types-attachment-not_in_sitemap";b:1;s:34:"taxonomies-category-not_in_sitemap";b:0;s:34:"taxonomies-post_tag-not_in_sitemap";b:1;s:37:"taxonomies-post_format-not_in_sitemap";b:0;}', 'yes'),
(166, 'wpseo_flush_rewrite', '1', 'yes'),
(170, 'ewww_image_optimizer_bulk_attachments', '', 'no'),
(171, 'ewww_image_optimizer_flag_attachments', '', 'no'),
(172, 'ewww_image_optimizer_ngg_attachments', '', 'no'),
(173, 'ewww_image_optimizer_disable_pngout', '1', 'no'),
(174, 'ewww_image_optimizer_optipng_level', '3', 'no'),
(175, 'ewww_image_optimizer_pngout_level', '1', 'no'),
(176, 'ewww_image_optimizer_jpegtran_copy', '1', 'no'),
(177, 'ewww_image_optimizer_jpg_level', '10', 'no'),
(178, 'ewww_image_optimizer_png_level', '10', 'no'),
(179, 'ewww_image_optimizer_gif_level', '10', 'no'),
(180, 'ewww_image_optimizer_pdf_level', '0', 'no'),
(181, 'ewww_image_optimizer_version', '351.0', 'yes'),
(182, 'secupress_active_submodule_ask-old-password', 'users-login', 'no'),
(184, 'secupress_users-login_settings', 'a:11:{s:32:"login-protection_number_attempts";s:2:"20";s:25:"login-protection_time_ban";s:1:"5";s:21:"move-login_slug-login";s:11:"essor-login";s:22:"move-login_slug-logout";s:6:"logout";s:24:"move-login_slug-register";s:8:"register";s:28:"move-login_slug-lostpassword";s:12:"lostpassword";s:25:"move-login_slug-resetpass";s:9:"resetpass";s:23:"move-login_login-access";s:9:"redir_404";s:25:"move-login_login-redirect";s:9:"redir_404";s:9:"sanitized";i:1;s:33:"login-protection_nonlogintimeslot";a:4:{s:9:"from_hour";i:0;s:11:"from_minute";i:0;s:7:"to_hour";i:0;s:9:"to_minute";i:0;}}', 'no');
INSERT INTO `essor_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(185, 'secupress_firewall_settings', 'a:7:{s:28:"bbq-headers_user-agents-list";s:3407:"ADSARobot, ah-ha, aktuelles, almaden, amzn_assoc, Anarchie, ASPSeek, ASSORT, ATHENS, Atomz, attach, autoemailspider, BackWeb, Bandit, BatchFTP, bdfetch, big.brother, BlackWidow, bmclient, Boston Project, Bot mailto:craftbot@yahoo.com, BravoBrian SpiderEngine MarcoPolo, Buddy, Bullseye, bumblebee, capture, CherryPicker, ChinaClaw, CICC, clipping, Collector, Copier, Crescent, Crescent Internet ToolPak, Custo, cyberalert, DA$, Deweb, diagem, Digger, Digimarc, DIIbot, DISCo, DISCoFinder, DISCo Pump, Download Demon, Downloader, Download Wonder, Drip, DSurf15a, DTS.Agent, EasyDL, eCatch, ecollector, efp@gmx.net, EirGrabber, EmailCollector, Email Extractor, EmailSiphon, EmailWolf, Express WebPictures, ExtractorPro, EyeNetIE, fastlwspider, FavOrg, Favorites Sweeper, FEZhead, FileHound, FlashGet WebWasher, FlickBot, fluffy, FrontPage, GalaxyBot, Generic, Getleft, GetRight, GetSmart, GetWeb!, GetWebPage, gigabaz, Girafabot, Go!Zilla, Go-Ahead-Got-It, GornKer, gotit, Grabber, GrabNet, Grafula, Green Research, grub-client, Harvest, hhjhj@yahoo, hloader, HMView, HomePageSearch, httpdown, http generic, HTTrack, httrack, ia_archiver, IBM_Planetwide, imagefetch, Image Stripper, Image Sucker, IncyWincy, Indy*Library, Indy Library, informant, Ingelin, InterGET, InternetLinkagent, Internet Ninja, InternetSeer.com, Iria, Irvine, JBH*agent, JetCar, JOC, JOC Web Spider, JustView, KWebGet, Lachesis, larbin, LeechFTP, LexiBot, lftp, libwww, likse, Link*Sleuth, LINKS ARoMATIZED, LinkWalker, LWP, lwp-trivial, Mac Finder, Mag-Net, Magnet, Mass Downloader, MCspider, Memo, Microsoft.URL, MIDown tool, Mirror, Missigua Locator, Mister PiX, MMMtoCrawl/UrlDispatcherLLL, Mozilla*MSIECrawler, Mozilla.*Indy, Mozilla.*NEWT, MSFrontPage, MS FrontPage*, MSIECrawler, MSProxy, multithreaddb, nationaldirectory, Navroad, NearSite, NetAnts, NetCarta, NetMechanic, netprospector, NetResearchServer, NetSpider, Net Vampire, NetZIP, NetZip Downloader, NetZippy, NEWT, NICErsPRO, Ninja, NPBot, Octopus, Offline Explorer, Offline Navigator, OpaL, Openfind, OpenTextSiteCrawler, PackRat, PageGrabber, Papa Foto, pavuk, pcBrowser, PersonaPilot, PingALink, Pockey, psbot, PSurf, puf, Pump, PushSite, QRVA, RealDownload, Reaper, Recorder, ReGet, replacer, RepoMonkey, Robozilla, Rover, RPT-HTTPClient, Rsync, Scooter, SearchExpress, searchhippo, searchterms.it, Second Street Research, Seeker, Shai, Siphon, sitecheck, sitecheck.internetseer.com, SiteSnagger, SlySearch, SmartDownload, snagger, Snake, SpaceBison, Spegla, SpiderBot, sproose, SqWorm, Stripper, Sucker, SuperBot, SuperHTTP, Surfbot, SurfWalker, Szukacz, tAkeOut, tarspider, Teleport Pro, Templeton, TrueRobot, TV33_Mercator, UIowaCrawler, URLSpiderPro, URL_Spider_Pro, UtilMind, Vacuum, vagabondo, vayala, visibilitygap, VoidEYE, vspider, w3mir, web.by.mail, WebAuto, WebBandit, Webclipping, webcollage, webcollector, WebCopier, webcraft@bea, Web Data Extractor, webdevil, Web Downloader, webdownloader, Webdup, WebEMailExtrac, WebFetch, WebGo IS, WebHook, Web Image Collector, Webinator, WebLeacher, WEBMASTERS, WebMiner, WebMirror, webmole, WebReaper, WebSauger, Website, Website eXtractor, Website Quester, WebSnake, Webster, WebStripper, Web Sucker, websucker, webvac, webwalk, webweasel, WebWhacker, WebZIP, Wget, Whacker, whizbang, WhosTalking, Widow, WISEbot, WUMPUS, Wweb, WWWOFFLE, x-Tractor, Xenu, XGET, Zeus, Zeus.*Webster, ^Mozilla$, ^Xaldon WebSpider";s:33:"bbq-url-content_bad-contents-list";s:291:"%%30%30, %00, ../, .ini, 127.0.0.1, AND%201=, AND+1=, AND 1=, base64_decode, base64_encode, etc/passwd, eval(, GLOBALS[, information_schema, input_file, javascript:, REQUEST[, UNION%20ALL%20SELECT, UNION%20SELECT, UNION+ALL+SELECT, UNION+SELECT, UNION ALL SELECT, UNION SELECT, wp-config.php";s:9:"sanitized";i:1;s:25:"bruteforce_request_number";i:9;s:19:"bruteforce_time_ban";i:5;s:22:"geoip-system_countries";a:0:{}s:17:"geoip-system_type";s:2:"-1";}', 'no'),
(186, 'secupress_settings', 'a:3:{s:7:"version";s:3:"1.3";s:8:"hash_key";s:64:"YDDGPMNKMXGVPF5APUB3VJA7SEKOBPSHOWGXHFKS4HCPK6FIOD3EGZEBY5TUBDKD";s:12:"install_time";i:1500568302;}', 'no'),
(188, 'ewww_image_optimizer_tracking_notice', '1', 'yes'),
(189, 'ewww_image_optimizer_background_optimization', '1', 'yes'),
(198, 'ewww_image_optimizer_enable_help_notice', '1', 'yes'),
(199, 'ewww_image_optimizer_jpg_background', '', 'yes'),
(200, 'ewww_image_optimizer_jpg_quality', '', 'yes'),
(201, 'ewww_image_optimizer_backup_files', '', 'no'),
(202, 'ewww_image_optimizer_cloud_key', '', 'yes'),
(203, 'ewww_image_optimizer_aux_paths', '', 'yes'),
(204, 'ewww_image_optimizer_exclude_paths', '', 'yes'),
(205, 'ewww_image_optimizer_delay', '0', 'yes'),
(206, 'ewww_image_optimizer_maxmediawidth', '3000', 'yes'),
(207, 'ewww_image_optimizer_maxmediaheight', '5000', 'yes'),
(208, 'ewww_image_optimizer_maxotherwidth', '0', 'yes'),
(209, 'ewww_image_optimizer_maxotherheight', '0', 'yes'),
(210, 'ewww_image_optimizer_disable_resizes', '', 'yes'),
(211, 'ewww_image_optimizer_disable_resizes_opt', '', 'yes'),
(212, 'ewww_image_optimizer_skip_size', '0', 'yes'),
(213, 'ewww_image_optimizer_skip_png_size', '0', 'yes'),
(214, 'ewww_image_optimizer_parallel_optimization', '1', 'yes'),
(215, 'ewww_image_optimizer_webp_paths', '', 'yes'),
(216, 'ewww_image_optimizer_allow_tracking', '', 'yes'),
(219, 'ewww_image_optimizer_delete_originals', '1', 'yes'),
(220, 'ewww_image_optimizer_gif_to_png', '1', 'yes'),
(223, '_transient_timeout_yoast_i18n_wordpress-seo_fr_FR', '1500654880', 'no'),
(224, '_transient_yoast_i18n_wordpress-seo_fr_FR', 'O:8:"stdClass":12:{s:2:"id";s:6:"396146";s:4:"name";s:6:"French";s:4:"slug";s:7:"default";s:10:"project_id";s:4:"3158";s:6:"locale";s:2:"fr";s:13:"current_count";i:1081;s:18:"untranslated_count";i:24;s:13:"waiting_count";i:15;s:11:"fuzzy_count";i:4;s:18:"percent_translated";i:97;s:9:"wp_locale";s:5:"fr_FR";s:13:"last_modified";s:19:"2017-06-26 08:55:55";}', 'no'),
(227, 'wpseo_sitemap_cache_validator_global', '5CGUu', 'no'),
(244, '_site_transient_timeout_secupress_php_versions', '1501173518', 'no'),
(245, '_site_transient_secupress_php_versions', 'a:2:{i:0;s:6:"5.6.31";i:1;s:6:"5.5.38";}', 'no'),
(246, 'secupress_scan_admin_user', 'a:2:{s:4:"msgs";a:1:{i:0;a:1:{i:0;s:14:"<em>admin</em>";}}s:6:"status";s:4:"good";}', 'no'),
(247, 'secupress_scan_subscription', 'a:2:{s:4:"msgs";a:1:{i:0;a:0:{}}s:6:"status";s:4:"good";}', 'no'),
(248, 'secupress_fix_passwords_strength', 'a:1:{s:4:"msgs";a:1:{i:301;a:0:{}}}', 'no'),
(249, 'secupress_scan_bad_usernames', 'a:2:{s:4:"msgs";a:1:{i:0;a:0:{}}s:6:"status";s:4:"good";}', 'no'),
(250, 'secupress_scan_passwords_strength', 'a:3:{s:4:"msgs";a:1:{i:201;a:1:{i:0;s:38:"Votre mot de passe de base de données";}}s:6:"status";s:3:"bad";s:7:"fix_msg";a:1:{i:301;a:0:{}}}', 'no'),
(251, 'secupress_fix_easy_login', 'a:1:{s:4:"msgs";a:1:{i:201;a:0:{}}}', 'no'),
(252, 'secupress_scan_easy_login', 'a:3:{s:4:"msgs";a:1:{i:200;a:0:{}}s:6:"status";s:3:"bad";s:7:"fix_msg";a:1:{i:201;a:0:{}}}', 'no'),
(253, 'secupress_scan_login_errors_disclose', 'a:2:{s:4:"msgs";a:1:{i:0;a:0:{}}s:6:"status";s:4:"good";}', 'no'),
(254, 'secupress_fix_non_login_time_slot', 'a:1:{s:4:"msgs";a:1:{i:201;a:0:{}}}', 'no'),
(255, 'secupress_scan_non_login_time_slot', 'a:3:{s:4:"msgs";a:1:{i:200;a:0:{}}s:6:"status";s:3:"bad";s:7:"fix_msg";a:1:{i:201;a:0:{}}}', 'no'),
(256, 'secupress_scan_themes_update', 'a:2:{s:4:"msgs";a:1:{i:0;a:0:{}}s:6:"status";s:4:"good";}', 'no'),
(257, 'secupress_scan_plugins_update', 'a:2:{s:4:"msgs";a:1:{i:0;a:0:{}}s:6:"status";s:4:"good";}', 'no'),
(258, 'secupress_scan_bad_vuln_plugins', 'a:2:{s:4:"msgs";a:1:{i:0;a:0:{}}s:6:"status";s:4:"good";}', 'no'),
(259, 'secupress_scan_inactive_plugins_themes', 'a:2:{s:4:"msgs";a:1:{i:0;a:0:{}}s:6:"status";s:4:"good";}', 'no'),
(260, '_site_transient_timeout_secupress_removed_plugins', '1500590323', 'no'),
(261, '_site_transient_secupress_removed_plugins', 'a:0:{}', 'no'),
(262, '_site_transient_timeout_secupress_notupdated_plugins', '1500590323', 'no'),
(263, '_site_transient_secupress_notupdated_plugins', 'a:0:{}', 'no'),
(264, 'secupress_scan_bad_old_plugins', 'a:2:{s:4:"msgs";a:1:{i:0;a:0:{}}s:6:"status";s:4:"good";}', 'no'),
(265, 'secupress_scan_auto_update', 'a:2:{s:4:"msgs";a:1:{i:0;a:0:{}}s:6:"status";s:4:"good";}', 'no'),
(266, 'secupress_scan_bad_config_files', 'a:2:{s:4:"msgs";a:1:{i:0;a:0:{}}s:6:"status";s:4:"good";}', 'no'),
(267, 'secupress_scan_wp_config', 'a:2:{s:4:"msgs";a:1:{i:0;a:0:{}}s:6:"status";s:4:"good";}', 'no'),
(268, 'secupress_scan_bad_old_files', 'a:2:{s:4:"msgs";a:1:{i:0;a:0:{}}s:6:"status";s:4:"good";}', 'no'),
(269, 'secupress_scan_db_prefix', 'a:2:{s:4:"msgs";a:1:{i:0;a:0:{}}s:6:"status";s:4:"good";}', 'no'),
(270, 'secupress_scan_core_update', 'a:2:{s:4:"msgs";a:1:{i:0;a:0:{}}s:6:"status";s:4:"good";}', 'no'),
(271, 'secupress_scan_salt_keys', 'a:2:{s:4:"msgs";a:1:{i:0;a:0:{}}s:6:"status";s:4:"good";}', 'no'),
(272, 'secupress_scan_readme_discloses', 'a:2:{s:4:"msgs";a:1:{i:0;a:0:{}}s:6:"status";s:4:"good";}', 'no'),
(273, 'secupress_scan_chmods', 'a:2:{s:4:"msgs";a:1:{i:0;a:0:{}}s:6:"status";s:4:"good";}', 'no'),
(274, 'secupress_scan_directory_listing', 'a:2:{s:4:"msgs";a:1:{i:0;a:0:{}}s:6:"status";s:4:"good";}', 'no'),
(275, 'rewrite_rules', 'a:137:{s:19:"sitemap_index\\.xml$";s:19:"index.php?sitemap=1";s:31:"([^/]+?)-sitemap([0-9]+)?\\.xml$";s:51:"index.php?sitemap=$matches[1]&sitemap_n=$matches[2]";s:24:"([a-z]+)?-?sitemap\\.xsl$";s:25:"index.php?xsl=$matches[1]";s:47:"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:42:"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:23:"category/(.+?)/embed/?$";s:46:"index.php?category_name=$matches[1]&embed=true";s:35:"category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:17:"category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:44:"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:39:"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:20:"tag/([^/]+)/embed/?$";s:36:"index.php?tag=$matches[1]&embed=true";s:32:"tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:14:"tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:45:"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:40:"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:21:"type/([^/]+)/embed/?$";s:44:"index.php?post_format=$matches[1]&embed=true";s:33:"type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:15:"type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:37:"reference/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:47:"reference/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:67:"reference/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:62:"reference/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:62:"reference/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:43:"reference/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:26:"reference/([^/]+)/embed/?$";s:42:"index.php?reference=$matches[1]&embed=true";s:30:"reference/([^/]+)/trackback/?$";s:36:"index.php?reference=$matches[1]&tb=1";s:38:"reference/([^/]+)/page/?([0-9]{1,})/?$";s:49:"index.php?reference=$matches[1]&paged=$matches[2]";s:45:"reference/([^/]+)/comment-page-([0-9]{1,})/?$";s:49:"index.php?reference=$matches[1]&cpage=$matches[2]";s:34:"reference/([^/]+)(?:/([0-9]+))?/?$";s:48:"index.php?reference=$matches[1]&page=$matches[2]";s:26:"reference/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:36:"reference/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:56:"reference/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:51:"reference/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:51:"reference/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:32:"reference/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:33:"offre/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:43:"offre/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:63:"offre/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:58:"offre/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:58:"offre/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:39:"offre/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:22:"offre/([^/]+)/embed/?$";s:38:"index.php?offre=$matches[1]&embed=true";s:26:"offre/([^/]+)/trackback/?$";s:32:"index.php?offre=$matches[1]&tb=1";s:34:"offre/([^/]+)/page/?([0-9]{1,})/?$";s:45:"index.php?offre=$matches[1]&paged=$matches[2]";s:41:"offre/([^/]+)/comment-page-([0-9]{1,})/?$";s:45:"index.php?offre=$matches[1]&cpage=$matches[2]";s:30:"offre/([^/]+)(?:/([0-9]+))?/?$";s:44:"index.php?offre=$matches[1]&page=$matches[2]";s:22:"offre/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:32:"offre/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:52:"offre/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:47:"offre/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:47:"offre/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:28:"offre/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:34:"metier/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:44:"metier/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:64:"metier/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:59:"metier/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:59:"metier/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:40:"metier/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:23:"metier/([^/]+)/embed/?$";s:39:"index.php?metier=$matches[1]&embed=true";s:27:"metier/([^/]+)/trackback/?$";s:33:"index.php?metier=$matches[1]&tb=1";s:35:"metier/([^/]+)/page/?([0-9]{1,})/?$";s:46:"index.php?metier=$matches[1]&paged=$matches[2]";s:42:"metier/([^/]+)/comment-page-([0-9]{1,})/?$";s:46:"index.php?metier=$matches[1]&cpage=$matches[2]";s:31:"metier/([^/]+)(?:/([0-9]+))?/?$";s:45:"index.php?metier=$matches[1]&page=$matches[2]";s:23:"metier/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:33:"metier/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:53:"metier/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:48:"metier/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:48:"metier/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:29:"metier/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:12:"robots\\.txt$";s:18:"index.php?robots=1";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:8:"embed/?$";s:21:"index.php?&embed=true";s:20:"page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:27:"comment-page-([0-9]{1,})/?$";s:38:"index.php?&page_id=2&cpage=$matches[1]";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:17:"comments/embed/?$";s:21:"index.php?&embed=true";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:20:"search/(.+)/embed/?$";s:34:"index.php?s=$matches[1]&embed=true";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:14:"search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:47:"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:42:"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:23:"author/([^/]+)/embed/?$";s:44:"index.php?author_name=$matches[1]&embed=true";s:35:"author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:17:"author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:69:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:45:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$";s:74:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:39:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:56:"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:51:"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:32:"([0-9]{4})/([0-9]{1,2})/embed/?$";s:58:"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true";s:44:"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:26:"([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:43:"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:38:"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:19:"([0-9]{4})/embed/?$";s:37:"index.php?year=$matches[1]&embed=true";s:31:"([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:13:"([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:".?.+?/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"(.?.+?)/embed/?$";s:41:"index.php?pagename=$matches[1]&embed=true";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:24:"(.?.+?)(?:/([0-9]+))?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";s:27:"[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:"[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:"[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:"[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"([^/]+)/embed/?$";s:37:"index.php?name=$matches[1]&embed=true";s:20:"([^/]+)/trackback/?$";s:31:"index.php?name=$matches[1]&tb=1";s:40:"([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:35:"([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:28:"([^/]+)/page/?([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&paged=$matches[2]";s:35:"([^/]+)/comment-page-([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&cpage=$matches[2]";s:24:"([^/]+)(?:/([0-9]+))?/?$";s:43:"index.php?name=$matches[1]&page=$matches[2]";s:16:"[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:26:"[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:46:"[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:22:"[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";}', 'yes'),
(276, 'secupress_scan_php_disclosure', 'a:2:{s:4:"msgs";a:1:{i:0;a:0:{}}s:6:"status";s:4:"good";}', 'no'),
(277, 'secupress_scan_bad_file_extensions', 'a:2:{s:4:"msgs";a:1:{i:201;a:0:{}}s:6:"status";s:3:"bad";}', 'no'),
(278, 'secupress_scan_directoryindex', 'a:2:{s:4:"msgs";a:1:{i:0;a:0:{}}s:6:"status";s:4:"good";}', 'no'),
(279, 'secupress_scan_shellshock', 'a:2:{s:4:"msgs";a:1:{i:0;a:0:{}}s:6:"status";s:4:"good";}', 'no'),
(280, 'secupress_scan_discloses', 'a:2:{s:4:"msgs";a:1:{i:0;a:0:{}}s:6:"status";s:4:"good";}', 'no'),
(281, 'secupress_fix_anti_front_brute_force', 'a:1:{s:4:"msgs";a:1:{i:201;a:0:{}}}', 'no'),
(282, 'secupress_scan_anti_front_brute_force', 'a:3:{s:4:"msgs";a:1:{i:200;a:0:{}}s:6:"status";s:3:"bad";s:7:"fix_msg";a:1:{i:201;a:0:{}}}', 'no'),
(283, 'secupress_scan_bad_user_agent', 'a:2:{s:4:"msgs";a:1:{i:0;a:0:{}}s:6:"status";s:4:"good";}', 'no'),
(284, 'secupress_scan_sqli', 'a:2:{s:4:"msgs";a:1:{i:0;a:0:{}}s:6:"status";s:4:"good";}', 'no'),
(285, 'secupress_scan_block_long_url', 'a:2:{s:4:"msgs";a:1:{i:0;a:0:{}}s:6:"status";s:4:"good";}', 'no'),
(286, 'secupress_fix_phpversion', 'a:1:{s:4:"msgs";a:1:{i:300;a:0:{}}}', 'no'),
(287, 'secupress_scan_phpversion', 'a:3:{s:4:"msgs";a:1:{i:200;a:0:{}}s:6:"status";s:3:"bad";s:7:"fix_msg";a:1:{i:300;a:0:{}}}', 'no'),
(288, 'secupress_scan_anti_scanner', 'a:2:{s:4:"msgs";a:1:{i:0;a:0:{}}s:6:"status";s:4:"good";}', 'no'),
(289, 'secupress_scan_bad_request_methods', 'a:2:{s:4:"msgs";a:1:{i:0;a:0:{}}s:6:"status";s:4:"good";}', 'no'),
(290, 'secupress_scan_bad_url_access', 'a:2:{s:4:"msgs";a:1:{i:0;a:0:{}}s:6:"status";s:4:"good";}', 'no'),
(291, 'secupress_scanners_times', 'a:2:{i:0;a:3:{s:7:"percent";d:49;s:5:"grade";s:1:"E";s:4:"time";i:1500568735;}i:1;a:3:{s:7:"percent";d:83;s:5:"grade";s:1:"B";s:4:"time";i:1500569313;}}', 'no'),
(292, 'secupress_step1_report', 'a:2:{s:5:"grade";s:1:"B";s:6:"report";a:35:{s:10:"admin_user";a:2:{s:4:"msgs";a:1:{i:0;a:1:{i:0;s:14:"<em>admin</em>";}}s:6:"status";s:4:"good";}s:10:"easy_login";a:3:{s:4:"msgs";a:1:{i:200;a:0:{}}s:6:"status";s:3:"bad";s:7:"fix_msg";a:1:{i:201;a:0:{}}}s:12:"subscription";a:2:{s:4:"msgs";a:1:{i:0;a:0:{}}s:6:"status";s:4:"good";}s:18:"passwords_strength";a:3:{s:4:"msgs";a:1:{i:201;a:1:{i:0;s:38:"Votre mot de passe de base de données";}}s:6:"status";s:3:"bad";s:7:"fix_msg";a:1:{i:301;a:0:{}}}s:13:"bad_usernames";a:2:{s:4:"msgs";a:1:{i:0;a:0:{}}s:6:"status";s:4:"good";}s:21:"login_errors_disclose";a:2:{s:4:"msgs";a:1:{i:0;a:0:{}}s:6:"status";s:4:"good";}s:19:"non_login_time_slot";a:3:{s:4:"msgs";a:1:{i:200;a:0:{}}s:6:"status";s:3:"bad";s:7:"fix_msg";a:1:{i:201;a:0:{}}}s:14:"plugins_update";a:2:{s:4:"msgs";a:1:{i:0;a:0:{}}s:6:"status";s:4:"good";}s:13:"themes_update";a:2:{s:4:"msgs";a:1:{i:0;a:0:{}}s:6:"status";s:4:"good";}s:15:"bad_old_plugins";a:2:{s:4:"msgs";a:1:{i:0;a:0:{}}s:6:"status";s:4:"good";}s:16:"bad_vuln_plugins";a:2:{s:4:"msgs";a:1:{i:0;a:0:{}}s:6:"status";s:4:"good";}s:23:"inactive_plugins_themes";a:2:{s:4:"msgs";a:1:{i:0;a:0:{}}s:6:"status";s:4:"good";}s:11:"core_update";a:2:{s:4:"msgs";a:1:{i:0;a:0:{}}s:6:"status";s:4:"good";}s:11:"auto_update";a:2:{s:4:"msgs";a:1:{i:0;a:0:{}}s:6:"status";s:4:"good";}s:13:"bad_old_files";a:2:{s:4:"msgs";a:1:{i:0;a:0:{}}s:6:"status";s:4:"good";}s:16:"bad_config_files";a:2:{s:4:"msgs";a:1:{i:0;a:0:{}}s:6:"status";s:4:"good";}s:9:"wp_config";a:2:{s:4:"msgs";a:1:{i:0;a:0:{}}s:6:"status";s:4:"good";}s:9:"db_prefix";a:2:{s:4:"msgs";a:1:{i:0;a:0:{}}s:6:"status";s:4:"good";}s:9:"salt_keys";a:2:{s:4:"msgs";a:1:{i:0;a:0:{}}s:6:"status";s:4:"good";}s:9:"discloses";a:2:{s:4:"msgs";a:1:{i:0;a:0:{}}s:6:"status";s:4:"good";}s:16:"readme_discloses";a:2:{s:4:"msgs";a:1:{i:0;a:0:{}}s:6:"status";s:4:"good";}s:14:"php_disclosure";a:2:{s:4:"msgs";a:1:{i:0;a:0:{}}s:6:"status";s:4:"good";}s:6:"chmods";a:2:{s:4:"msgs";a:1:{i:0;a:0:{}}s:6:"status";s:4:"good";}s:17:"directory_listing";a:2:{s:4:"msgs";a:1:{i:0;a:0:{}}s:6:"status";s:4:"good";}s:19:"bad_file_extensions";a:2:{s:4:"msgs";a:1:{i:201;a:0:{}}s:6:"status";s:3:"bad";}s:14:"directoryindex";a:2:{s:4:"msgs";a:1:{i:0;a:0:{}}s:6:"status";s:4:"good";}s:10:"shellshock";a:2:{s:4:"msgs";a:1:{i:0;a:0:{}}s:6:"status";s:4:"good";}s:14:"bad_user_agent";a:2:{s:4:"msgs";a:1:{i:0;a:0:{}}s:6:"status";s:4:"good";}s:4:"sqli";a:2:{s:4:"msgs";a:1:{i:0;a:0:{}}s:6:"status";s:4:"good";}s:12:"anti_scanner";a:2:{s:4:"msgs";a:1:{i:0;a:0:{}}s:6:"status";s:4:"good";}s:22:"anti_front_brute_force";a:3:{s:4:"msgs";a:1:{i:200;a:0:{}}s:6:"status";s:3:"bad";s:7:"fix_msg";a:1:{i:201;a:0:{}}}s:19:"bad_request_methods";a:2:{s:4:"msgs";a:1:{i:0;a:0:{}}s:6:"status";s:4:"good";}s:14:"block_long_url";a:2:{s:4:"msgs";a:1:{i:0;a:0:{}}s:6:"status";s:4:"good";}s:14:"bad_url_access";a:2:{s:4:"msgs";a:1:{i:0;a:0:{}}s:6:"status";s:4:"good";}s:10:"phpversion";a:3:{s:4:"msgs";a:1:{i:200;a:0:{}}s:6:"status";s:3:"bad";s:7:"fix_msg";a:1:{i:300;a:0:{}}}}}', 'yes'),
(293, 'secupress_active_submodule_directory-listing', 'sensitive-data', 'no'),
(298, 'secupress_active_submodule_wp-config-constant-file-edit', 'wordpress-core', 'no'),
(300, 'secupress_active_submodule_wp-config-constant-unfiltered-html', 'wordpress-core', 'no'),
(301, 'secupress_active_submodule_readmes', 'discloses', 'no'),
(308, 'secupress_active_submodule_wp-version', 'discloses', 'no'),
(310, 'secupress_active_submodule_no-x-powered-by', 'discloses', 'no'),
(312, 'secupress_active_submodule_directory-index', 'file-system', 'no'),
(315, 'secupress_active_submodule_bad-url-length', 'firewall', 'no'),
(318, 'secupress_active_submodule_user-agents-header', 'firewall', 'no'),
(321, 'secupress_active_submodule_bad-sqli-scan', 'firewall', 'no'),
(322, 'secupress_active_submodule_request-methods-header', 'firewall', 'no'),
(327, 'secupress_active_submodule_bad-url-access', 'sensitive-data', 'no'),
(334, 'secupress_active_submodule_limitloginattempts', 'users-login', 'no'),
(339, 'secupress_active_submodule_login-captcha', 'users-login', 'no'),
(344, 'secupress_active_submodule_blacklist-logins', 'users-login', 'no'),
(349, 'secupress_active_submodule_move-login', 'users-login', 'no'),
(354, 'secupress_active_submodule_uploads', 'plugins-themes', 'no'),
(356, 'secupress_plugins-themes_settings', 'a:0:{}', 'yes'),
(360, 'secupress_active_submodule_plugin-installation', 'plugins-themes', 'no'),
(365, 'secupress_active_submodule_theme-installation', 'plugins-themes', 'no'),
(370, 'secupress_active_submodule_minor-updates', 'wordpress-core', 'no'),
(373, 'secupress_active_submodule_major-updates', 'wordpress-core', 'no'),
(375, 'secupress_wordpress-core_settings', 'a:1:{s:9:"sanitized";i:1;}', 'yes'),
(378, 'secupress_active_submodule_xmlrpc', 'sensitive-data', 'no'),
(381, 'secupress_active_submodule_restapi', 'sensitive-data', 'no'),
(382, 'secupress_sensitive-data_settings', 'a:2:{s:19:"wp-endpoints_xmlrpc";a:1:{i:0;s:9:"block-all";}s:9:"sanitized";i:1;}', 'yes'),
(386, 'secupress_active_submodule_blackhole', 'sensitive-data', 'no'),
(389, 'secupress_active_submodule_php-easter-egg', 'sensitive-data', 'no'),
(393, 'secupress_active_submodule_bad-url-contents', 'firewall', 'no'),
(395, '_site_transient_secupress_active_submodules', 'a:7:{s:9:"discloses";a:3:{i:0;s:15:"no-x-powered-by";i:1;s:7:"readmes";i:2;s:10:"wp-version";}s:11:"file-system";a:1:{i:0;s:15:"directory-index";}s:8:"firewall";a:5:{i:0;s:13:"bad-sqli-scan";i:1;s:16:"bad-url-contents";i:2;s:14:"bad-url-length";i:3;s:22:"request-methods-header";i:4;s:18:"user-agents-header";}s:14:"plugins-themes";a:3:{i:0;s:19:"plugin-installation";i:1;s:18:"theme-installation";i:2;s:7:"uploads";}s:14:"sensitive-data";a:6:{i:0;s:14:"bad-url-access";i:1;s:9:"blackhole";i:2;s:17:"directory-listing";i:3;s:14:"php-easter-egg";i:4;s:7:"restapi";i:5;s:6:"xmlrpc";}s:11:"users-login";a:5:{i:0;s:16:"ask-old-password";i:1;s:16:"blacklist-logins";i:2;s:18:"limitloginattempts";i:3;s:13:"login-captcha";i:4;s:10:"move-login";}s:14:"wordpress-core";a:4:{i:0;s:13:"major-updates";i:1;s:13:"minor-updates";i:2;s:28:"wp-config-constant-file-edit";i:3;s:34:"wp-config-constant-unfiltered-html";}}', 'no'),
(409, 'wpseo_sitemap_1_cache_validator', '49suW', 'no'),
(410, 'wpseo_sitemap_page_cache_validator', '533Fc', 'no'),
(422, 'nav_menu_options', 'a:2:{i:0;b:0;s:8:"auto_add";a:0:{}}', 'yes'),
(423, 'acf_version', '5.5.14', 'yes'),
(424, 'category_children', 'a:0:{}', 'yes'),
(425, 'options_contactLink', '25', 'no'),
(426, '_options_contactLink', 'field_5971d1943ca06', 'no'),
(452, 'wpseo_sitemap_39_cache_validator', '532jF', 'no'),
(453, 'wpseo_sitemap_40_cache_validator', '532jJ', 'no'),
(454, 'wpseo_sitemap_41_cache_validator', '532jN', 'no'),
(455, 'wpseo_sitemap_42_cache_validator', '532jQ', 'no'),
(472, 'secupress_captcha_keys', 'a:0:{}', 'no'),
(481, '_site_transient_timeout_available_translations', '1500898734', 'no');
INSERT INTO `essor_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(482, '_site_transient_available_translations', 'a:108:{s:2:"af";a:8:{s:8:"language";s:2:"af";s:7:"version";s:3:"4.8";s:7:"updated";s:19:"2017-06-23 21:35:47";s:12:"english_name";s:9:"Afrikaans";s:11:"native_name";s:9:"Afrikaans";s:7:"package";s:59:"https://downloads.wordpress.org/translation/core/4.8/af.zip";s:3:"iso";a:2:{i:1;s:2:"af";i:2;s:3:"afr";}s:7:"strings";a:1:{s:8:"continue";s:10:"Gaan voort";}}s:2:"ar";a:8:{s:8:"language";s:2:"ar";s:7:"version";s:3:"4.8";s:7:"updated";s:19:"2017-07-09 03:55:46";s:12:"english_name";s:6:"Arabic";s:11:"native_name";s:14:"العربية";s:7:"package";s:59:"https://downloads.wordpress.org/translation/core/4.8/ar.zip";s:3:"iso";a:2:{i:1;s:2:"ar";i:2;s:3:"ara";}s:7:"strings";a:1:{s:8:"continue";s:16:"المتابعة";}}s:3:"ary";a:8:{s:8:"language";s:3:"ary";s:7:"version";s:5:"4.7.5";s:7:"updated";s:19:"2017-01-26 15:42:35";s:12:"english_name";s:15:"Moroccan Arabic";s:11:"native_name";s:31:"العربية المغربية";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.7.5/ary.zip";s:3:"iso";a:2:{i:1;s:2:"ar";i:3;s:3:"ary";}s:7:"strings";a:1:{s:8:"continue";s:16:"المتابعة";}}s:2:"as";a:8:{s:8:"language";s:2:"as";s:7:"version";s:5:"4.7.2";s:7:"updated";s:19:"2016-11-22 18:59:07";s:12:"english_name";s:8:"Assamese";s:11:"native_name";s:21:"অসমীয়া";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/4.7.2/as.zip";s:3:"iso";a:3:{i:1;s:2:"as";i:2;s:3:"asm";i:3;s:3:"asm";}s:7:"strings";a:1:{s:8:"continue";s:0:"";}}s:2:"az";a:8:{s:8:"language";s:2:"az";s:7:"version";s:5:"4.7.2";s:7:"updated";s:19:"2016-11-06 00:09:27";s:12:"english_name";s:11:"Azerbaijani";s:11:"native_name";s:16:"Azərbaycan dili";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/4.7.2/az.zip";s:3:"iso";a:2:{i:1;s:2:"az";i:2;s:3:"aze";}s:7:"strings";a:1:{s:8:"continue";s:5:"Davam";}}s:3:"azb";a:8:{s:8:"language";s:3:"azb";s:7:"version";s:5:"4.7.2";s:7:"updated";s:19:"2016-09-12 20:34:31";s:12:"english_name";s:17:"South Azerbaijani";s:11:"native_name";s:29:"گؤنئی آذربایجان";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.7.2/azb.zip";s:3:"iso";a:2:{i:1;s:2:"az";i:3;s:3:"azb";}s:7:"strings";a:1:{s:8:"continue";s:8:"Continue";}}s:3:"bel";a:8:{s:8:"language";s:3:"bel";s:7:"version";s:3:"4.8";s:7:"updated";s:19:"2017-06-17 20:31:44";s:12:"english_name";s:10:"Belarusian";s:11:"native_name";s:29:"Беларуская мова";s:7:"package";s:60:"https://downloads.wordpress.org/translation/core/4.8/bel.zip";s:3:"iso";a:2:{i:1;s:2:"be";i:2;s:3:"bel";}s:7:"strings";a:1:{s:8:"continue";s:20:"Працягнуць";}}s:5:"bg_BG";a:8:{s:8:"language";s:5:"bg_BG";s:7:"version";s:3:"4.8";s:7:"updated";s:19:"2017-06-18 19:16:01";s:12:"english_name";s:9:"Bulgarian";s:11:"native_name";s:18:"Български";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.8/bg_BG.zip";s:3:"iso";a:2:{i:1;s:2:"bg";i:2;s:3:"bul";}s:7:"strings";a:1:{s:8:"continue";s:12:"Напред";}}s:5:"bn_BD";a:8:{s:8:"language";s:5:"bn_BD";s:7:"version";s:5:"4.7.2";s:7:"updated";s:19:"2017-01-04 16:58:43";s:12:"english_name";s:7:"Bengali";s:11:"native_name";s:15:"বাংলা";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.7.2/bn_BD.zip";s:3:"iso";a:1:{i:1;s:2:"bn";}s:7:"strings";a:1:{s:8:"continue";s:23:"এগিয়ে চল.";}}s:2:"bo";a:8:{s:8:"language";s:2:"bo";s:7:"version";s:5:"4.7.2";s:7:"updated";s:19:"2016-09-05 09:44:12";s:12:"english_name";s:7:"Tibetan";s:11:"native_name";s:21:"བོད་ཡིག";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/4.7.2/bo.zip";s:3:"iso";a:2:{i:1;s:2:"bo";i:2;s:3:"tib";}s:7:"strings";a:1:{s:8:"continue";s:24:"མུ་མཐུད།";}}s:5:"bs_BA";a:8:{s:8:"language";s:5:"bs_BA";s:7:"version";s:5:"4.7.2";s:7:"updated";s:19:"2016-09-04 20:20:28";s:12:"english_name";s:7:"Bosnian";s:11:"native_name";s:8:"Bosanski";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.7.2/bs_BA.zip";s:3:"iso";a:2:{i:1;s:2:"bs";i:2;s:3:"bos";}s:7:"strings";a:1:{s:8:"continue";s:7:"Nastavi";}}s:2:"ca";a:8:{s:8:"language";s:2:"ca";s:7:"version";s:3:"4.8";s:7:"updated";s:19:"2017-06-16 11:47:56";s:12:"english_name";s:7:"Catalan";s:11:"native_name";s:7:"Català";s:7:"package";s:59:"https://downloads.wordpress.org/translation/core/4.8/ca.zip";s:3:"iso";a:2:{i:1;s:2:"ca";i:2;s:3:"cat";}s:7:"strings";a:1:{s:8:"continue";s:8:"Continua";}}s:3:"ceb";a:8:{s:8:"language";s:3:"ceb";s:7:"version";s:5:"4.7.2";s:7:"updated";s:19:"2016-03-02 17:25:51";s:12:"english_name";s:7:"Cebuano";s:11:"native_name";s:7:"Cebuano";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.7.2/ceb.zip";s:3:"iso";a:2:{i:2;s:3:"ceb";i:3;s:3:"ceb";}s:7:"strings";a:1:{s:8:"continue";s:7:"Padayun";}}s:5:"cs_CZ";a:8:{s:8:"language";s:5:"cs_CZ";s:7:"version";s:5:"4.7.2";s:7:"updated";s:19:"2017-01-12 08:46:26";s:12:"english_name";s:5:"Czech";s:11:"native_name";s:12:"Čeština‎";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.7.2/cs_CZ.zip";s:3:"iso";a:2:{i:1;s:2:"cs";i:2;s:3:"ces";}s:7:"strings";a:1:{s:8:"continue";s:11:"Pokračovat";}}s:2:"cy";a:8:{s:8:"language";s:2:"cy";s:7:"version";s:3:"4.8";s:7:"updated";s:19:"2017-06-14 13:21:24";s:12:"english_name";s:5:"Welsh";s:11:"native_name";s:7:"Cymraeg";s:7:"package";s:59:"https://downloads.wordpress.org/translation/core/4.8/cy.zip";s:3:"iso";a:2:{i:1;s:2:"cy";i:2;s:3:"cym";}s:7:"strings";a:1:{s:8:"continue";s:6:"Parhau";}}s:5:"da_DK";a:8:{s:8:"language";s:5:"da_DK";s:7:"version";s:3:"4.8";s:7:"updated";s:19:"2017-06-14 23:24:44";s:12:"english_name";s:6:"Danish";s:11:"native_name";s:5:"Dansk";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.8/da_DK.zip";s:3:"iso";a:2:{i:1;s:2:"da";i:2;s:3:"dan";}s:7:"strings";a:1:{s:8:"continue";s:8:"Fortsæt";}}s:5:"de_CH";a:8:{s:8:"language";s:5:"de_CH";s:7:"version";s:3:"4.8";s:7:"updated";s:19:"2017-06-15 21:25:12";s:12:"english_name";s:20:"German (Switzerland)";s:11:"native_name";s:17:"Deutsch (Schweiz)";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.8/de_CH.zip";s:3:"iso";a:1:{i:1;s:2:"de";}s:7:"strings";a:1:{s:8:"continue";s:6:"Weiter";}}s:14:"de_CH_informal";a:8:{s:8:"language";s:14:"de_CH_informal";s:7:"version";s:3:"4.8";s:7:"updated";s:19:"2017-06-15 08:50:23";s:12:"english_name";s:30:"German (Switzerland, Informal)";s:11:"native_name";s:21:"Deutsch (Schweiz, Du)";s:7:"package";s:71:"https://downloads.wordpress.org/translation/core/4.8/de_CH_informal.zip";s:3:"iso";a:1:{i:1;s:2:"de";}s:7:"strings";a:1:{s:8:"continue";s:6:"Weiter";}}s:5:"de_DE";a:8:{s:8:"language";s:5:"de_DE";s:7:"version";s:3:"4.8";s:7:"updated";s:19:"2017-07-08 16:08:42";s:12:"english_name";s:6:"German";s:11:"native_name";s:7:"Deutsch";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.8/de_DE.zip";s:3:"iso";a:1:{i:1;s:2:"de";}s:7:"strings";a:1:{s:8:"continue";s:6:"Weiter";}}s:12:"de_DE_formal";a:8:{s:8:"language";s:12:"de_DE_formal";s:7:"version";s:3:"4.8";s:7:"updated";s:19:"2017-07-15 19:58:49";s:12:"english_name";s:15:"German (Formal)";s:11:"native_name";s:13:"Deutsch (Sie)";s:7:"package";s:69:"https://downloads.wordpress.org/translation/core/4.8/de_DE_formal.zip";s:3:"iso";a:1:{i:1;s:2:"de";}s:7:"strings";a:1:{s:8:"continue";s:6:"Weiter";}}s:3:"dzo";a:8:{s:8:"language";s:3:"dzo";s:7:"version";s:5:"4.7.2";s:7:"updated";s:19:"2016-06-29 08:59:03";s:12:"english_name";s:8:"Dzongkha";s:11:"native_name";s:18:"རྫོང་ཁ";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.7.2/dzo.zip";s:3:"iso";a:2:{i:1;s:2:"dz";i:2;s:3:"dzo";}s:7:"strings";a:1:{s:8:"continue";s:0:"";}}s:2:"el";a:8:{s:8:"language";s:2:"el";s:7:"version";s:3:"4.8";s:7:"updated";s:19:"2017-06-21 18:05:57";s:12:"english_name";s:5:"Greek";s:11:"native_name";s:16:"Ελληνικά";s:7:"package";s:59:"https://downloads.wordpress.org/translation/core/4.8/el.zip";s:3:"iso";a:2:{i:1;s:2:"el";i:2;s:3:"ell";}s:7:"strings";a:1:{s:8:"continue";s:16:"Συνέχεια";}}s:5:"en_NZ";a:8:{s:8:"language";s:5:"en_NZ";s:7:"version";s:3:"4.8";s:7:"updated";s:19:"2017-06-17 08:09:19";s:12:"english_name";s:21:"English (New Zealand)";s:11:"native_name";s:21:"English (New Zealand)";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.8/en_NZ.zip";s:3:"iso";a:3:{i:1;s:2:"en";i:2;s:3:"eng";i:3;s:3:"eng";}s:7:"strings";a:1:{s:8:"continue";s:8:"Continue";}}s:5:"en_CA";a:8:{s:8:"language";s:5:"en_CA";s:7:"version";s:3:"4.8";s:7:"updated";s:19:"2017-06-23 16:48:27";s:12:"english_name";s:16:"English (Canada)";s:11:"native_name";s:16:"English (Canada)";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.8/en_CA.zip";s:3:"iso";a:3:{i:1;s:2:"en";i:2;s:3:"eng";i:3;s:3:"eng";}s:7:"strings";a:1:{s:8:"continue";s:8:"Continue";}}s:5:"en_ZA";a:8:{s:8:"language";s:5:"en_ZA";s:7:"version";s:5:"4.7.5";s:7:"updated";s:19:"2017-01-26 15:53:43";s:12:"english_name";s:22:"English (South Africa)";s:11:"native_name";s:22:"English (South Africa)";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.7.5/en_ZA.zip";s:3:"iso";a:3:{i:1;s:2:"en";i:2;s:3:"eng";i:3;s:3:"eng";}s:7:"strings";a:1:{s:8:"continue";s:8:"Continue";}}s:5:"en_GB";a:8:{s:8:"language";s:5:"en_GB";s:7:"version";s:3:"4.8";s:7:"updated";s:19:"2017-06-15 07:18:00";s:12:"english_name";s:12:"English (UK)";s:11:"native_name";s:12:"English (UK)";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.8/en_GB.zip";s:3:"iso";a:3:{i:1;s:2:"en";i:2;s:3:"eng";i:3;s:3:"eng";}s:7:"strings";a:1:{s:8:"continue";s:8:"Continue";}}s:5:"en_AU";a:8:{s:8:"language";s:5:"en_AU";s:7:"version";s:3:"4.8";s:7:"updated";s:19:"2017-06-15 05:14:35";s:12:"english_name";s:19:"English (Australia)";s:11:"native_name";s:19:"English (Australia)";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.8/en_AU.zip";s:3:"iso";a:3:{i:1;s:2:"en";i:2;s:3:"eng";i:3;s:3:"eng";}s:7:"strings";a:1:{s:8:"continue";s:8:"Continue";}}s:2:"eo";a:8:{s:8:"language";s:2:"eo";s:7:"version";s:3:"4.8";s:7:"updated";s:19:"2017-06-27 10:36:23";s:12:"english_name";s:9:"Esperanto";s:11:"native_name";s:9:"Esperanto";s:7:"package";s:59:"https://downloads.wordpress.org/translation/core/4.8/eo.zip";s:3:"iso";a:2:{i:1;s:2:"eo";i:2;s:3:"epo";}s:7:"strings";a:1:{s:8:"continue";s:8:"Daŭrigi";}}s:5:"es_MX";a:8:{s:8:"language";s:5:"es_MX";s:7:"version";s:3:"4.8";s:7:"updated";s:19:"2017-06-16 17:22:41";s:12:"english_name";s:16:"Spanish (Mexico)";s:11:"native_name";s:19:"Español de México";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.8/es_MX.zip";s:3:"iso";a:2:{i:1;s:2:"es";i:2;s:3:"spa";}s:7:"strings";a:1:{s:8:"continue";s:9:"Continuar";}}s:5:"es_VE";a:8:{s:8:"language";s:5:"es_VE";s:7:"version";s:3:"4.8";s:7:"updated";s:19:"2017-07-07 00:53:01";s:12:"english_name";s:19:"Spanish (Venezuela)";s:11:"native_name";s:21:"Español de Venezuela";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.8/es_VE.zip";s:3:"iso";a:2:{i:1;s:2:"es";i:2;s:3:"spa";}s:7:"strings";a:1:{s:8:"continue";s:9:"Continuar";}}s:5:"es_GT";a:8:{s:8:"language";s:5:"es_GT";s:7:"version";s:5:"4.7.5";s:7:"updated";s:19:"2017-01-26 15:54:37";s:12:"english_name";s:19:"Spanish (Guatemala)";s:11:"native_name";s:21:"Español de Guatemala";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.7.5/es_GT.zip";s:3:"iso";a:2:{i:1;s:2:"es";i:2;s:3:"spa";}s:7:"strings";a:1:{s:8:"continue";s:9:"Continuar";}}s:5:"es_CO";a:8:{s:8:"language";s:5:"es_CO";s:7:"version";s:5:"4.7.5";s:7:"updated";s:19:"2017-01-26 15:54:37";s:12:"english_name";s:18:"Spanish (Colombia)";s:11:"native_name";s:20:"Español de Colombia";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.7.5/es_CO.zip";s:3:"iso";a:2:{i:1;s:2:"es";i:2;s:3:"spa";}s:7:"strings";a:1:{s:8:"continue";s:9:"Continuar";}}s:5:"es_PE";a:8:{s:8:"language";s:5:"es_PE";s:7:"version";s:5:"4.7.2";s:7:"updated";s:19:"2016-09-09 09:36:22";s:12:"english_name";s:14:"Spanish (Peru)";s:11:"native_name";s:17:"Español de Perú";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.7.2/es_PE.zip";s:3:"iso";a:2:{i:1;s:2:"es";i:2;s:3:"spa";}s:7:"strings";a:1:{s:8:"continue";s:9:"Continuar";}}s:5:"es_CL";a:8:{s:8:"language";s:5:"es_CL";s:7:"version";s:5:"4.7.2";s:7:"updated";s:19:"2016-11-28 20:09:49";s:12:"english_name";s:15:"Spanish (Chile)";s:11:"native_name";s:17:"Español de Chile";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.7.2/es_CL.zip";s:3:"iso";a:2:{i:1;s:2:"es";i:2;s:3:"spa";}s:7:"strings";a:1:{s:8:"continue";s:9:"Continuar";}}s:5:"es_AR";a:8:{s:8:"language";s:5:"es_AR";s:7:"version";s:3:"4.8";s:7:"updated";s:19:"2017-06-20 00:55:30";s:12:"english_name";s:19:"Spanish (Argentina)";s:11:"native_name";s:21:"Español de Argentina";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.8/es_AR.zip";s:3:"iso";a:2:{i:1;s:2:"es";i:2;s:3:"spa";}s:7:"strings";a:1:{s:8:"continue";s:9:"Continuar";}}s:5:"es_ES";a:8:{s:8:"language";s:5:"es_ES";s:7:"version";s:3:"4.8";s:7:"updated";s:19:"2017-07-18 10:53:33";s:12:"english_name";s:15:"Spanish (Spain)";s:11:"native_name";s:8:"Español";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.8/es_ES.zip";s:3:"iso";a:1:{i:1;s:2:"es";}s:7:"strings";a:1:{s:8:"continue";s:9:"Continuar";}}s:2:"et";a:8:{s:8:"language";s:2:"et";s:7:"version";s:5:"4.7.2";s:7:"updated";s:19:"2017-01-27 16:37:11";s:12:"english_name";s:8:"Estonian";s:11:"native_name";s:5:"Eesti";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/4.7.2/et.zip";s:3:"iso";a:2:{i:1;s:2:"et";i:2;s:3:"est";}s:7:"strings";a:1:{s:8:"continue";s:6:"Jätka";}}s:2:"eu";a:8:{s:8:"language";s:2:"eu";s:7:"version";s:3:"4.8";s:7:"updated";s:19:"2017-06-21 08:00:44";s:12:"english_name";s:6:"Basque";s:11:"native_name";s:7:"Euskara";s:7:"package";s:59:"https://downloads.wordpress.org/translation/core/4.8/eu.zip";s:3:"iso";a:2:{i:1;s:2:"eu";i:2;s:3:"eus";}s:7:"strings";a:1:{s:8:"continue";s:8:"Jarraitu";}}s:5:"fa_IR";a:8:{s:8:"language";s:5:"fa_IR";s:7:"version";s:3:"4.8";s:7:"updated";s:19:"2017-06-09 15:50:45";s:12:"english_name";s:7:"Persian";s:11:"native_name";s:10:"فارسی";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.8/fa_IR.zip";s:3:"iso";a:2:{i:1;s:2:"fa";i:2;s:3:"fas";}s:7:"strings";a:1:{s:8:"continue";s:10:"ادامه";}}s:2:"fi";a:8:{s:8:"language";s:2:"fi";s:7:"version";s:3:"4.8";s:7:"updated";s:19:"2017-06-08 18:25:22";s:12:"english_name";s:7:"Finnish";s:11:"native_name";s:5:"Suomi";s:7:"package";s:59:"https://downloads.wordpress.org/translation/core/4.8/fi.zip";s:3:"iso";a:2:{i:1;s:2:"fi";i:2;s:3:"fin";}s:7:"strings";a:1:{s:8:"continue";s:5:"Jatka";}}s:5:"fr_BE";a:8:{s:8:"language";s:5:"fr_BE";s:7:"version";s:3:"4.8";s:7:"updated";s:19:"2017-06-23 06:47:57";s:12:"english_name";s:16:"French (Belgium)";s:11:"native_name";s:21:"Français de Belgique";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.8/fr_BE.zip";s:3:"iso";a:2:{i:1;s:2:"fr";i:2;s:3:"fra";}s:7:"strings";a:1:{s:8:"continue";s:9:"Continuer";}}s:5:"fr_FR";a:8:{s:8:"language";s:5:"fr_FR";s:7:"version";s:3:"4.8";s:7:"updated";s:19:"2017-07-07 13:48:37";s:12:"english_name";s:15:"French (France)";s:11:"native_name";s:9:"Français";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.8/fr_FR.zip";s:3:"iso";a:1:{i:1;s:2:"fr";}s:7:"strings";a:1:{s:8:"continue";s:9:"Continuer";}}s:5:"fr_CA";a:8:{s:8:"language";s:5:"fr_CA";s:7:"version";s:3:"4.8";s:7:"updated";s:19:"2017-07-05 17:58:06";s:12:"english_name";s:15:"French (Canada)";s:11:"native_name";s:19:"Français du Canada";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.8/fr_CA.zip";s:3:"iso";a:2:{i:1;s:2:"fr";i:2;s:3:"fra";}s:7:"strings";a:1:{s:8:"continue";s:9:"Continuer";}}s:2:"gd";a:8:{s:8:"language";s:2:"gd";s:7:"version";s:5:"4.7.2";s:7:"updated";s:19:"2016-08-23 17:41:37";s:12:"english_name";s:15:"Scottish Gaelic";s:11:"native_name";s:9:"Gàidhlig";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/4.7.2/gd.zip";s:3:"iso";a:3:{i:1;s:2:"gd";i:2;s:3:"gla";i:3;s:3:"gla";}s:7:"strings";a:1:{s:8:"continue";s:15:"Lean air adhart";}}s:5:"gl_ES";a:8:{s:8:"language";s:5:"gl_ES";s:7:"version";s:3:"4.8";s:7:"updated";s:19:"2017-06-17 20:40:15";s:12:"english_name";s:8:"Galician";s:11:"native_name";s:6:"Galego";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.8/gl_ES.zip";s:3:"iso";a:2:{i:1;s:2:"gl";i:2;s:3:"glg";}s:7:"strings";a:1:{s:8:"continue";s:9:"Continuar";}}s:2:"gu";a:8:{s:8:"language";s:2:"gu";s:7:"version";s:3:"4.8";s:7:"updated";s:19:"2017-06-07 12:07:46";s:12:"english_name";s:8:"Gujarati";s:11:"native_name";s:21:"ગુજરાતી";s:7:"package";s:59:"https://downloads.wordpress.org/translation/core/4.8/gu.zip";s:3:"iso";a:2:{i:1;s:2:"gu";i:2;s:3:"guj";}s:7:"strings";a:1:{s:8:"continue";s:31:"ચાલુ રાખવું";}}s:3:"haz";a:8:{s:8:"language";s:3:"haz";s:7:"version";s:5:"4.4.2";s:7:"updated";s:19:"2015-12-05 00:59:09";s:12:"english_name";s:8:"Hazaragi";s:11:"native_name";s:15:"هزاره گی";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.4.2/haz.zip";s:3:"iso";a:1:{i:3;s:3:"haz";}s:7:"strings";a:1:{s:8:"continue";s:10:"ادامه";}}s:5:"he_IL";a:8:{s:8:"language";s:5:"he_IL";s:7:"version";s:3:"4.8";s:7:"updated";s:19:"2017-06-15 13:33:29";s:12:"english_name";s:6:"Hebrew";s:11:"native_name";s:16:"עִבְרִית";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.8/he_IL.zip";s:3:"iso";a:1:{i:1;s:2:"he";}s:7:"strings";a:1:{s:8:"continue";s:8:"המשך";}}s:5:"hi_IN";a:8:{s:8:"language";s:5:"hi_IN";s:7:"version";s:3:"4.8";s:7:"updated";s:19:"2017-07-16 17:29:16";s:12:"english_name";s:5:"Hindi";s:11:"native_name";s:18:"हिन्दी";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.8/hi_IN.zip";s:3:"iso";a:2:{i:1;s:2:"hi";i:2;s:3:"hin";}s:7:"strings";a:1:{s:8:"continue";s:12:"जारी";}}s:2:"hr";a:8:{s:8:"language";s:2:"hr";s:7:"version";s:3:"4.8";s:7:"updated";s:19:"2017-07-19 08:19:39";s:12:"english_name";s:8:"Croatian";s:11:"native_name";s:8:"Hrvatski";s:7:"package";s:59:"https://downloads.wordpress.org/translation/core/4.8/hr.zip";s:3:"iso";a:2:{i:1;s:2:"hr";i:2;s:3:"hrv";}s:7:"strings";a:1:{s:8:"continue";s:7:"Nastavi";}}s:5:"hu_HU";a:8:{s:8:"language";s:5:"hu_HU";s:7:"version";s:5:"4.7.2";s:7:"updated";s:19:"2017-01-26 15:48:39";s:12:"english_name";s:9:"Hungarian";s:11:"native_name";s:6:"Magyar";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.7.2/hu_HU.zip";s:3:"iso";a:2:{i:1;s:2:"hu";i:2;s:3:"hun";}s:7:"strings";a:1:{s:8:"continue";s:10:"Folytatás";}}s:2:"hy";a:8:{s:8:"language";s:2:"hy";s:7:"version";s:5:"4.7.2";s:7:"updated";s:19:"2016-12-03 16:21:10";s:12:"english_name";s:8:"Armenian";s:11:"native_name";s:14:"Հայերեն";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/4.7.2/hy.zip";s:3:"iso";a:2:{i:1;s:2:"hy";i:2;s:3:"hye";}s:7:"strings";a:1:{s:8:"continue";s:20:"Շարունակել";}}s:5:"id_ID";a:8:{s:8:"language";s:5:"id_ID";s:7:"version";s:3:"4.8";s:7:"updated";s:19:"2017-07-12 12:20:50";s:12:"english_name";s:10:"Indonesian";s:11:"native_name";s:16:"Bahasa Indonesia";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.8/id_ID.zip";s:3:"iso";a:2:{i:1;s:2:"id";i:2;s:3:"ind";}s:7:"strings";a:1:{s:8:"continue";s:9:"Lanjutkan";}}s:5:"is_IS";a:8:{s:8:"language";s:5:"is_IS";s:7:"version";s:5:"4.7.5";s:7:"updated";s:19:"2017-04-13 13:55:54";s:12:"english_name";s:9:"Icelandic";s:11:"native_name";s:9:"Íslenska";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.7.5/is_IS.zip";s:3:"iso";a:2:{i:1;s:2:"is";i:2;s:3:"isl";}s:7:"strings";a:1:{s:8:"continue";s:6:"Áfram";}}s:5:"it_IT";a:8:{s:8:"language";s:5:"it_IT";s:7:"version";s:3:"4.8";s:7:"updated";s:19:"2017-07-04 13:01:37";s:12:"english_name";s:7:"Italian";s:11:"native_name";s:8:"Italiano";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.8/it_IT.zip";s:3:"iso";a:2:{i:1;s:2:"it";i:2;s:3:"ita";}s:7:"strings";a:1:{s:8:"continue";s:8:"Continua";}}s:2:"ja";a:8:{s:8:"language";s:2:"ja";s:7:"version";s:3:"4.8";s:7:"updated";s:19:"2017-06-25 11:16:15";s:12:"english_name";s:8:"Japanese";s:11:"native_name";s:9:"日本語";s:7:"package";s:59:"https://downloads.wordpress.org/translation/core/4.8/ja.zip";s:3:"iso";a:1:{i:1;s:2:"ja";}s:7:"strings";a:1:{s:8:"continue";s:9:"続ける";}}s:5:"ka_GE";a:8:{s:8:"language";s:5:"ka_GE";s:7:"version";s:3:"4.8";s:7:"updated";s:19:"2017-06-12 09:20:11";s:12:"english_name";s:8:"Georgian";s:11:"native_name";s:21:"ქართული";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.8/ka_GE.zip";s:3:"iso";a:2:{i:1;s:2:"ka";i:2;s:3:"kat";}s:7:"strings";a:1:{s:8:"continue";s:30:"გაგრძელება";}}s:3:"kab";a:8:{s:8:"language";s:3:"kab";s:7:"version";s:3:"4.8";s:7:"updated";s:19:"2017-07-16 18:44:50";s:12:"english_name";s:6:"Kabyle";s:11:"native_name";s:9:"Taqbaylit";s:7:"package";s:60:"https://downloads.wordpress.org/translation/core/4.8/kab.zip";s:3:"iso";a:2:{i:2;s:3:"kab";i:3;s:3:"kab";}s:7:"strings";a:1:{s:8:"continue";s:6:"Kemmel";}}s:2:"km";a:8:{s:8:"language";s:2:"km";s:7:"version";s:5:"4.7.2";s:7:"updated";s:19:"2016-12-07 02:07:59";s:12:"english_name";s:5:"Khmer";s:11:"native_name";s:27:"ភាសាខ្មែរ";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/4.7.2/km.zip";s:3:"iso";a:2:{i:1;s:2:"km";i:2;s:3:"khm";}s:7:"strings";a:1:{s:8:"continue";s:12:"បន្ត";}}s:5:"ko_KR";a:8:{s:8:"language";s:5:"ko_KR";s:7:"version";s:3:"4.8";s:7:"updated";s:19:"2017-06-19 07:08:35";s:12:"english_name";s:6:"Korean";s:11:"native_name";s:9:"한국어";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.8/ko_KR.zip";s:3:"iso";a:2:{i:1;s:2:"ko";i:2;s:3:"kor";}s:7:"strings";a:1:{s:8:"continue";s:6:"계속";}}s:3:"ckb";a:8:{s:8:"language";s:3:"ckb";s:7:"version";s:5:"4.7.2";s:7:"updated";s:19:"2017-01-26 15:48:25";s:12:"english_name";s:16:"Kurdish (Sorani)";s:11:"native_name";s:13:"كوردی‎";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.7.2/ckb.zip";s:3:"iso";a:2:{i:1;s:2:"ku";i:3;s:3:"ckb";}s:7:"strings";a:1:{s:8:"continue";s:30:"به‌رده‌وام به‌";}}s:2:"lo";a:8:{s:8:"language";s:2:"lo";s:7:"version";s:5:"4.7.2";s:7:"updated";s:19:"2016-11-12 09:59:23";s:12:"english_name";s:3:"Lao";s:11:"native_name";s:21:"ພາສາລາວ";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/4.7.2/lo.zip";s:3:"iso";a:2:{i:1;s:2:"lo";i:2;s:3:"lao";}s:7:"strings";a:1:{s:8:"continue";s:18:"ຕໍ່​ໄປ";}}s:5:"lt_LT";a:8:{s:8:"language";s:5:"lt_LT";s:7:"version";s:3:"4.8";s:7:"updated";s:19:"2017-07-05 11:43:04";s:12:"english_name";s:10:"Lithuanian";s:11:"native_name";s:15:"Lietuvių kalba";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.8/lt_LT.zip";s:3:"iso";a:2:{i:1;s:2:"lt";i:2;s:3:"lit";}s:7:"strings";a:1:{s:8:"continue";s:6:"Tęsti";}}s:2:"lv";a:8:{s:8:"language";s:2:"lv";s:7:"version";s:5:"4.7.5";s:7:"updated";s:19:"2017-03-17 20:40:40";s:12:"english_name";s:7:"Latvian";s:11:"native_name";s:16:"Latviešu valoda";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/4.7.5/lv.zip";s:3:"iso";a:2:{i:1;s:2:"lv";i:2;s:3:"lav";}s:7:"strings";a:1:{s:8:"continue";s:9:"Turpināt";}}s:5:"mk_MK";a:8:{s:8:"language";s:5:"mk_MK";s:7:"version";s:5:"4.7.5";s:7:"updated";s:19:"2017-01-26 15:54:41";s:12:"english_name";s:10:"Macedonian";s:11:"native_name";s:31:"Македонски јазик";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.7.5/mk_MK.zip";s:3:"iso";a:2:{i:1;s:2:"mk";i:2;s:3:"mkd";}s:7:"strings";a:1:{s:8:"continue";s:16:"Продолжи";}}s:5:"ml_IN";a:8:{s:8:"language";s:5:"ml_IN";s:7:"version";s:5:"4.7.2";s:7:"updated";s:19:"2017-01-27 03:43:32";s:12:"english_name";s:9:"Malayalam";s:11:"native_name";s:18:"മലയാളം";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.7.2/ml_IN.zip";s:3:"iso";a:2:{i:1;s:2:"ml";i:2;s:3:"mal";}s:7:"strings";a:1:{s:8:"continue";s:18:"തുടരുക";}}s:2:"mn";a:8:{s:8:"language";s:2:"mn";s:7:"version";s:5:"4.7.2";s:7:"updated";s:19:"2017-01-12 07:29:35";s:12:"english_name";s:9:"Mongolian";s:11:"native_name";s:12:"Монгол";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/4.7.2/mn.zip";s:3:"iso";a:2:{i:1;s:2:"mn";i:2;s:3:"mon";}s:7:"strings";a:1:{s:8:"continue";s:24:"Үргэлжлүүлэх";}}s:2:"mr";a:8:{s:8:"language";s:2:"mr";s:7:"version";s:3:"4.8";s:7:"updated";s:19:"2017-07-05 19:40:47";s:12:"english_name";s:7:"Marathi";s:11:"native_name";s:15:"मराठी";s:7:"package";s:59:"https://downloads.wordpress.org/translation/core/4.8/mr.zip";s:3:"iso";a:2:{i:1;s:2:"mr";i:2;s:3:"mar";}s:7:"strings";a:1:{s:8:"continue";s:25:"सुरु ठेवा";}}s:5:"ms_MY";a:8:{s:8:"language";s:5:"ms_MY";s:7:"version";s:5:"4.7.5";s:7:"updated";s:19:"2017-03-05 09:45:10";s:12:"english_name";s:5:"Malay";s:11:"native_name";s:13:"Bahasa Melayu";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.7.5/ms_MY.zip";s:3:"iso";a:2:{i:1;s:2:"ms";i:2;s:3:"msa";}s:7:"strings";a:1:{s:8:"continue";s:8:"Teruskan";}}s:5:"my_MM";a:8:{s:8:"language";s:5:"my_MM";s:7:"version";s:6:"4.1.18";s:7:"updated";s:19:"2015-03-26 15:57:42";s:12:"english_name";s:17:"Myanmar (Burmese)";s:11:"native_name";s:15:"ဗမာစာ";s:7:"package";s:65:"https://downloads.wordpress.org/translation/core/4.1.18/my_MM.zip";s:3:"iso";a:2:{i:1;s:2:"my";i:2;s:3:"mya";}s:7:"strings";a:1:{s:8:"continue";s:54:"ဆက်လက်လုပ်ဆောင်ပါ။";}}s:5:"nb_NO";a:8:{s:8:"language";s:5:"nb_NO";s:7:"version";s:3:"4.8";s:7:"updated";s:19:"2017-06-26 11:11:30";s:12:"english_name";s:19:"Norwegian (Bokmål)";s:11:"native_name";s:13:"Norsk bokmål";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.8/nb_NO.zip";s:3:"iso";a:2:{i:1;s:2:"nb";i:2;s:3:"nob";}s:7:"strings";a:1:{s:8:"continue";s:8:"Fortsett";}}s:5:"ne_NP";a:8:{s:8:"language";s:5:"ne_NP";s:7:"version";s:3:"4.8";s:7:"updated";s:19:"2017-06-23 11:30:58";s:12:"english_name";s:6:"Nepali";s:11:"native_name";s:18:"नेपाली";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.8/ne_NP.zip";s:3:"iso";a:2:{i:1;s:2:"ne";i:2;s:3:"nep";}s:7:"strings";a:1:{s:8:"continue";s:43:"जारी राख्नुहोस्";}}s:5:"nl_BE";a:8:{s:8:"language";s:5:"nl_BE";s:7:"version";s:3:"4.8";s:7:"updated";s:19:"2017-06-20 17:04:00";s:12:"english_name";s:15:"Dutch (Belgium)";s:11:"native_name";s:20:"Nederlands (België)";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.8/nl_BE.zip";s:3:"iso";a:2:{i:1;s:2:"nl";i:2;s:3:"nld";}s:7:"strings";a:1:{s:8:"continue";s:8:"Doorgaan";}}s:12:"nl_NL_formal";a:8:{s:8:"language";s:12:"nl_NL_formal";s:7:"version";s:5:"4.7.5";s:7:"updated";s:19:"2017-02-16 13:24:21";s:12:"english_name";s:14:"Dutch (Formal)";s:11:"native_name";s:20:"Nederlands (Formeel)";s:7:"package";s:71:"https://downloads.wordpress.org/translation/core/4.7.5/nl_NL_formal.zip";s:3:"iso";a:2:{i:1;s:2:"nl";i:2;s:3:"nld";}s:7:"strings";a:1:{s:8:"continue";s:8:"Doorgaan";}}s:5:"nl_NL";a:8:{s:8:"language";s:5:"nl_NL";s:7:"version";s:3:"4.8";s:7:"updated";s:19:"2017-07-18 18:26:58";s:12:"english_name";s:5:"Dutch";s:11:"native_name";s:10:"Nederlands";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.8/nl_NL.zip";s:3:"iso";a:2:{i:1;s:2:"nl";i:2;s:3:"nld";}s:7:"strings";a:1:{s:8:"continue";s:8:"Doorgaan";}}s:5:"nn_NO";a:8:{s:8:"language";s:5:"nn_NO";s:7:"version";s:3:"4.8";s:7:"updated";s:19:"2017-06-08 13:05:53";s:12:"english_name";s:19:"Norwegian (Nynorsk)";s:11:"native_name";s:13:"Norsk nynorsk";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.8/nn_NO.zip";s:3:"iso";a:2:{i:1;s:2:"nn";i:2;s:3:"nno";}s:7:"strings";a:1:{s:8:"continue";s:9:"Hald fram";}}s:3:"oci";a:8:{s:8:"language";s:3:"oci";s:7:"version";s:5:"4.7.2";s:7:"updated";s:19:"2017-01-02 13:47:38";s:12:"english_name";s:7:"Occitan";s:11:"native_name";s:7:"Occitan";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.7.2/oci.zip";s:3:"iso";a:2:{i:1;s:2:"oc";i:2;s:3:"oci";}s:7:"strings";a:1:{s:8:"continue";s:9:"Contunhar";}}s:5:"pa_IN";a:8:{s:8:"language";s:5:"pa_IN";s:7:"version";s:5:"4.7.2";s:7:"updated";s:19:"2017-01-16 05:19:43";s:12:"english_name";s:7:"Punjabi";s:11:"native_name";s:18:"ਪੰਜਾਬੀ";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.7.2/pa_IN.zip";s:3:"iso";a:2:{i:1;s:2:"pa";i:2;s:3:"pan";}s:7:"strings";a:1:{s:8:"continue";s:25:"ਜਾਰੀ ਰੱਖੋ";}}s:5:"pl_PL";a:8:{s:8:"language";s:5:"pl_PL";s:7:"version";s:3:"4.8";s:7:"updated";s:19:"2017-07-19 13:38:04";s:12:"english_name";s:6:"Polish";s:11:"native_name";s:6:"Polski";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.8/pl_PL.zip";s:3:"iso";a:2:{i:1;s:2:"pl";i:2;s:3:"pol";}s:7:"strings";a:1:{s:8:"continue";s:9:"Kontynuuj";}}s:2:"ps";a:8:{s:8:"language";s:2:"ps";s:7:"version";s:6:"4.1.18";s:7:"updated";s:19:"2015-03-29 22:19:48";s:12:"english_name";s:6:"Pashto";s:11:"native_name";s:8:"پښتو";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.1.18/ps.zip";s:3:"iso";a:2:{i:1;s:2:"ps";i:2;s:3:"pus";}s:7:"strings";a:1:{s:8:"continue";s:19:"دوام ورکړه";}}s:5:"pt_PT";a:8:{s:8:"language";s:5:"pt_PT";s:7:"version";s:3:"4.8";s:7:"updated";s:19:"2017-06-23 10:24:37";s:12:"english_name";s:21:"Portuguese (Portugal)";s:11:"native_name";s:10:"Português";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.8/pt_PT.zip";s:3:"iso";a:1:{i:1;s:2:"pt";}s:7:"strings";a:1:{s:8:"continue";s:9:"Continuar";}}s:5:"pt_BR";a:8:{s:8:"language";s:5:"pt_BR";s:7:"version";s:3:"4.8";s:7:"updated";s:19:"2017-07-13 23:57:05";s:12:"english_name";s:19:"Portuguese (Brazil)";s:11:"native_name";s:20:"Português do Brasil";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.8/pt_BR.zip";s:3:"iso";a:2:{i:1;s:2:"pt";i:2;s:3:"por";}s:7:"strings";a:1:{s:8:"continue";s:9:"Continuar";}}s:3:"rhg";a:8:{s:8:"language";s:3:"rhg";s:7:"version";s:5:"4.7.2";s:7:"updated";s:19:"2016-03-16 13:03:18";s:12:"english_name";s:8:"Rohingya";s:11:"native_name";s:8:"Ruáinga";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.7.2/rhg.zip";s:3:"iso";a:1:{i:3;s:3:"rhg";}s:7:"strings";a:1:{s:8:"continue";s:0:"";}}s:5:"ro_RO";a:8:{s:8:"language";s:5:"ro_RO";s:7:"version";s:3:"4.8";s:7:"updated";s:19:"2017-07-15 10:32:19";s:12:"english_name";s:8:"Romanian";s:11:"native_name";s:8:"Română";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.8/ro_RO.zip";s:3:"iso";a:2:{i:1;s:2:"ro";i:2;s:3:"ron";}s:7:"strings";a:1:{s:8:"continue";s:9:"Continuă";}}s:5:"ru_RU";a:8:{s:8:"language";s:5:"ru_RU";s:7:"version";s:3:"4.8";s:7:"updated";s:19:"2017-06-15 13:54:09";s:12:"english_name";s:7:"Russian";s:11:"native_name";s:14:"Русский";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.8/ru_RU.zip";s:3:"iso";a:2:{i:1;s:2:"ru";i:2;s:3:"rus";}s:7:"strings";a:1:{s:8:"continue";s:20:"Продолжить";}}s:3:"sah";a:8:{s:8:"language";s:3:"sah";s:7:"version";s:5:"4.7.2";s:7:"updated";s:19:"2017-01-21 02:06:41";s:12:"english_name";s:5:"Sakha";s:11:"native_name";s:14:"Сахалыы";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.7.2/sah.zip";s:3:"iso";a:2:{i:2;s:3:"sah";i:3;s:3:"sah";}s:7:"strings";a:1:{s:8:"continue";s:12:"Салҕаа";}}s:5:"si_LK";a:8:{s:8:"language";s:5:"si_LK";s:7:"version";s:5:"4.7.2";s:7:"updated";s:19:"2016-11-12 06:00:52";s:12:"english_name";s:7:"Sinhala";s:11:"native_name";s:15:"සිංහල";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.7.2/si_LK.zip";s:3:"iso";a:2:{i:1;s:2:"si";i:2;s:3:"sin";}s:7:"strings";a:1:{s:8:"continue";s:44:"දිගටම කරගෙන යන්න";}}s:5:"sk_SK";a:8:{s:8:"language";s:5:"sk_SK";s:7:"version";s:3:"4.8";s:7:"updated";s:19:"2017-06-15 09:02:13";s:12:"english_name";s:6:"Slovak";s:11:"native_name";s:11:"Slovenčina";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.8/sk_SK.zip";s:3:"iso";a:2:{i:1;s:2:"sk";i:2;s:3:"slk";}s:7:"strings";a:1:{s:8:"continue";s:12:"Pokračovať";}}s:5:"sl_SI";a:8:{s:8:"language";s:5:"sl_SI";s:7:"version";s:3:"4.8";s:7:"updated";s:19:"2017-06-08 15:29:14";s:12:"english_name";s:9:"Slovenian";s:11:"native_name";s:13:"Slovenščina";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.8/sl_SI.zip";s:3:"iso";a:2:{i:1;s:2:"sl";i:2;s:3:"slv";}s:7:"strings";a:1:{s:8:"continue";s:8:"Nadaljuj";}}s:2:"sq";a:8:{s:8:"language";s:2:"sq";s:7:"version";s:5:"4.7.5";s:7:"updated";s:19:"2017-04-24 08:35:30";s:12:"english_name";s:8:"Albanian";s:11:"native_name";s:5:"Shqip";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/4.7.5/sq.zip";s:3:"iso";a:2:{i:1;s:2:"sq";i:2;s:3:"sqi";}s:7:"strings";a:1:{s:8:"continue";s:6:"Vazhdo";}}s:5:"sr_RS";a:8:{s:8:"language";s:5:"sr_RS";s:7:"version";s:3:"4.8";s:7:"updated";s:19:"2017-06-08 11:06:53";s:12:"english_name";s:7:"Serbian";s:11:"native_name";s:23:"Српски језик";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.8/sr_RS.zip";s:3:"iso";a:2:{i:1;s:2:"sr";i:2;s:3:"srp";}s:7:"strings";a:1:{s:8:"continue";s:14:"Настави";}}s:5:"sv_SE";a:8:{s:8:"language";s:5:"sv_SE";s:7:"version";s:3:"4.8";s:7:"updated";s:19:"2017-07-18 17:49:44";s:12:"english_name";s:7:"Swedish";s:11:"native_name";s:7:"Svenska";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.8/sv_SE.zip";s:3:"iso";a:2:{i:1;s:2:"sv";i:2;s:3:"swe";}s:7:"strings";a:1:{s:8:"continue";s:9:"Fortsätt";}}s:3:"szl";a:8:{s:8:"language";s:3:"szl";s:7:"version";s:5:"4.7.2";s:7:"updated";s:19:"2016-09-24 19:58:14";s:12:"english_name";s:8:"Silesian";s:11:"native_name";s:17:"Ślōnskŏ gŏdka";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.7.2/szl.zip";s:3:"iso";a:1:{i:3;s:3:"szl";}s:7:"strings";a:1:{s:8:"continue";s:13:"Kōntynuować";}}s:5:"ta_IN";a:8:{s:8:"language";s:5:"ta_IN";s:7:"version";s:5:"4.7.2";s:7:"updated";s:19:"2017-01-27 03:22:47";s:12:"english_name";s:5:"Tamil";s:11:"native_name";s:15:"தமிழ்";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.7.2/ta_IN.zip";s:3:"iso";a:2:{i:1;s:2:"ta";i:2;s:3:"tam";}s:7:"strings";a:1:{s:8:"continue";s:24:"தொடரவும்";}}s:2:"te";a:8:{s:8:"language";s:2:"te";s:7:"version";s:5:"4.7.2";s:7:"updated";s:19:"2017-01-26 15:47:39";s:12:"english_name";s:6:"Telugu";s:11:"native_name";s:18:"తెలుగు";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/4.7.2/te.zip";s:3:"iso";a:2:{i:1;s:2:"te";i:2;s:3:"tel";}s:7:"strings";a:1:{s:8:"continue";s:30:"కొనసాగించు";}}s:2:"th";a:8:{s:8:"language";s:2:"th";s:7:"version";s:5:"4.7.2";s:7:"updated";s:19:"2017-01-26 15:48:43";s:12:"english_name";s:4:"Thai";s:11:"native_name";s:9:"ไทย";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/4.7.2/th.zip";s:3:"iso";a:2:{i:1;s:2:"th";i:2;s:3:"tha";}s:7:"strings";a:1:{s:8:"continue";s:15:"ต่อไป";}}s:2:"tl";a:8:{s:8:"language";s:2:"tl";s:7:"version";s:5:"4.7.2";s:7:"updated";s:19:"2016-12-30 02:38:08";s:12:"english_name";s:7:"Tagalog";s:11:"native_name";s:7:"Tagalog";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/4.7.2/tl.zip";s:3:"iso";a:2:{i:1;s:2:"tl";i:2;s:3:"tgl";}s:7:"strings";a:1:{s:8:"continue";s:10:"Magpatuloy";}}s:5:"tr_TR";a:8:{s:8:"language";s:5:"tr_TR";s:7:"version";s:3:"4.8";s:7:"updated";s:19:"2017-06-19 13:54:12";s:12:"english_name";s:7:"Turkish";s:11:"native_name";s:8:"Türkçe";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.8/tr_TR.zip";s:3:"iso";a:2:{i:1;s:2:"tr";i:2;s:3:"tur";}s:7:"strings";a:1:{s:8:"continue";s:5:"Devam";}}s:5:"tt_RU";a:8:{s:8:"language";s:5:"tt_RU";s:7:"version";s:5:"4.7.2";s:7:"updated";s:19:"2016-11-20 20:20:50";s:12:"english_name";s:5:"Tatar";s:11:"native_name";s:19:"Татар теле";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.7.2/tt_RU.zip";s:3:"iso";a:2:{i:1;s:2:"tt";i:2;s:3:"tat";}s:7:"strings";a:1:{s:8:"continue";s:17:"дәвам итү";}}s:3:"tah";a:8:{s:8:"language";s:3:"tah";s:7:"version";s:5:"4.7.2";s:7:"updated";s:19:"2016-03-06 18:39:39";s:12:"english_name";s:8:"Tahitian";s:11:"native_name";s:10:"Reo Tahiti";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.7.2/tah.zip";s:3:"iso";a:3:{i:1;s:2:"ty";i:2;s:3:"tah";i:3;s:3:"tah";}s:7:"strings";a:1:{s:8:"continue";s:0:"";}}s:5:"ug_CN";a:8:{s:8:"language";s:5:"ug_CN";s:7:"version";s:5:"4.7.2";s:7:"updated";s:19:"2016-12-05 09:23:39";s:12:"english_name";s:6:"Uighur";s:11:"native_name";s:9:"Uyƣurqə";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.7.2/ug_CN.zip";s:3:"iso";a:2:{i:1;s:2:"ug";i:2;s:3:"uig";}s:7:"strings";a:1:{s:8:"continue";s:26:"داۋاملاشتۇرۇش";}}s:2:"uk";a:8:{s:8:"language";s:2:"uk";s:7:"version";s:3:"4.8";s:7:"updated";s:19:"2017-07-01 22:52:09";s:12:"english_name";s:9:"Ukrainian";s:11:"native_name";s:20:"Українська";s:7:"package";s:59:"https://downloads.wordpress.org/translation/core/4.8/uk.zip";s:3:"iso";a:2:{i:1;s:2:"uk";i:2;s:3:"ukr";}s:7:"strings";a:1:{s:8:"continue";s:20:"Продовжити";}}s:2:"ur";a:8:{s:8:"language";s:2:"ur";s:7:"version";s:3:"4.8";s:7:"updated";s:19:"2017-07-02 09:17:00";s:12:"english_name";s:4:"Urdu";s:11:"native_name";s:8:"اردو";s:7:"package";s:59:"https://downloads.wordpress.org/translation/core/4.8/ur.zip";s:3:"iso";a:2:{i:1;s:2:"ur";i:2;s:3:"urd";}s:7:"strings";a:1:{s:8:"continue";s:19:"جاری رکھیں";}}s:5:"uz_UZ";a:8:{s:8:"language";s:5:"uz_UZ";s:7:"version";s:5:"4.7.5";s:7:"updated";s:19:"2017-05-13 09:55:38";s:12:"english_name";s:5:"Uzbek";s:11:"native_name";s:11:"O‘zbekcha";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.7.5/uz_UZ.zip";s:3:"iso";a:2:{i:1;s:2:"uz";i:2;s:3:"uzb";}s:7:"strings";a:1:{s:8:"continue";s:11:"Davom etish";}}s:2:"vi";a:8:{s:8:"language";s:2:"vi";s:7:"version";s:3:"4.8";s:7:"updated";s:19:"2017-06-15 11:24:18";s:12:"english_name";s:10:"Vietnamese";s:11:"native_name";s:14:"Tiếng Việt";s:7:"package";s:59:"https://downloads.wordpress.org/translation/core/4.8/vi.zip";s:3:"iso";a:2:{i:1;s:2:"vi";i:2;s:3:"vie";}s:7:"strings";a:1:{s:8:"continue";s:12:"Tiếp tục";}}s:5:"zh_HK";a:8:{s:8:"language";s:5:"zh_HK";s:7:"version";s:3:"4.8";s:7:"updated";s:19:"2017-07-16 05:48:05";s:12:"english_name";s:19:"Chinese (Hong Kong)";s:11:"native_name";s:16:"香港中文版	";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.8/zh_HK.zip";s:3:"iso";a:2:{i:1;s:2:"zh";i:2;s:3:"zho";}s:7:"strings";a:1:{s:8:"continue";s:6:"繼續";}}s:5:"zh_TW";a:8:{s:8:"language";s:5:"zh_TW";s:7:"version";s:3:"4.8";s:7:"updated";s:19:"2017-07-05 10:14:12";s:12:"english_name";s:16:"Chinese (Taiwan)";s:11:"native_name";s:12:"繁體中文";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.8/zh_TW.zip";s:3:"iso";a:2:{i:1;s:2:"zh";i:2;s:3:"zho";}s:7:"strings";a:1:{s:8:"continue";s:6:"繼續";}}s:5:"zh_CN";a:8:{s:8:"language";s:5:"zh_CN";s:7:"version";s:5:"4.7.5";s:7:"updated";s:19:"2017-01-26 15:54:45";s:12:"english_name";s:15:"Chinese (China)";s:11:"native_name";s:12:"简体中文";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.7.5/zh_CN.zip";s:3:"iso";a:2:{i:1;s:2:"zh";i:2;s:3:"zho";}s:7:"strings";a:1:{s:8:"continue";s:6:"继续";}}}', 'no'),
(488, 'redirection_version', '2.3.3', 'yes'),
(489, 'redirection_options', 'a:9:{s:7:"support";b:0;s:5:"token";s:32:"109d04ec3c2a668b0d30303e0ac7f133";s:12:"monitor_post";i:0;s:11:"auto_target";s:0:"";s:15:"expire_redirect";i:7;s:10:"expire_404";i:7;s:7:"modules";a:0:{}s:10:"newsletter";b:0;s:6:"lookup";s:32:"http://urbangiraffe.com/map/?ip=";}', 'yes'),
(491, 'kcseo_wp_1_2_data_fix', '1', 'yes'),
(492, 'kcseo_wp_installed_version', '2.0', 'yes'),
(493, 'kcseo_wp_schema', 'a:19:{s:7:"web_url";s:16:"http://localhost";s:9:"site_type";s:12:"Organization";s:9:"type_name";s:5:"Essor";s:10:"site_image";s:1:"0";s:16:"site_price_range";s:0:"";s:14:"site_telephone";s:0:"";s:14:"additionalType";s:0:"";s:13:"business_info";a:4:{s:11:"description";s:0:"";s:12:"openingHours";s:0:"";s:9:"longitude";s:0:"";s:8:"latitude";s:0:"";}s:6:"person";a:6:{s:4:"name";s:0:"";s:8:"worksFor";s:0:"";s:8:"jobTitle";s:0:"";s:5:"image";s:0:"";s:11:"description";s:0:"";s:9:"birthDate";s:0:"";}s:7:"address";a:5:{s:7:"country";s:6:"France";s:8:"locality";s:0:"";s:6:"region";s:0:"";s:10:"postalcode";s:0:"";s:6:"street";s:0:"";}s:17:"organization_logo";s:0:"";s:19:"social_company_name";s:0:"";s:7:"contact";a:4:{s:11:"contactType";s:16:"Customer Service";s:9:"telephone";s:0:"";s:5:"email";s:0:"";s:13:"contactOption";s:0:"";}s:8:"homeonly";s:1:"1";s:8:"sitename";s:5:"Essor";s:9:"siteaname";s:0:"";s:7:"siteurl";s:16:"http://localhost";s:12:"_kcseo_nonce";s:10:"eeeccb31f1";s:16:"_wp_http_referer";s:38:"/wp-admin/admin.php?page=wp-seo-schema";}', 'yes'),
(496, '_site_transient_update_core', 'O:8:"stdClass":4:{s:7:"updates";a:1:{i:0;O:8:"stdClass":10:{s:8:"response";s:6:"latest";s:8:"download";s:63:"https://downloads.wordpress.org/release/fr_FR/wordpress-4.8.zip";s:6:"locale";s:5:"fr_FR";s:8:"packages";O:8:"stdClass":5:{s:4:"full";s:63:"https://downloads.wordpress.org/release/fr_FR/wordpress-4.8.zip";s:10:"no_content";b:0;s:11:"new_bundled";b:0;s:7:"partial";b:0;s:8:"rollback";b:0;}s:7:"current";s:3:"4.8";s:7:"version";s:3:"4.8";s:11:"php_version";s:5:"5.2.4";s:13:"mysql_version";s:3:"5.0";s:11:"new_bundled";s:3:"4.7";s:15:"partial_version";s:0:"";}}s:12:"last_checked";i:1501656711;s:15:"version_checked";s:3:"4.8";s:12:"translations";a:0:{}}', 'no'),
(500, '_site_transient_update_themes', 'O:8:"stdClass":4:{s:12:"last_checked";i:1501656711;s:7:"checked";a:1:{s:5:"essor";s:3:"1.0";}s:8:"response";a:0:{}s:12:"translations";a:0:{}}', 'no'),
(504, 'options_offersTitle', 'Nous rejoindre', 'no'),
(505, '_options_offersTitle', 'field_5975e1b2324f4', 'no'),
(506, 'options_offersSubtitle', 'Nos dernières offres d''emploi:', 'no'),
(507, '_options_offersSubtitle', 'field_5975e1c2324f5', 'no'),
(508, 'options_offersPage', '60', 'no'),
(509, '_options_offersPage', 'field_5975e1cf324f6', 'no'),
(510, 'options_offersBtn', 'Nos offres d''emploi', 'no'),
(511, '_options_offersBtn', 'field_5975e1e7324f7', 'no'),
(512, 'options_newsTitle', 'Nous suivre', 'no'),
(513, '_options_newsTitle', 'field_5975e28f324f9', 'no'),
(514, 'options_newsSubtitle', 'L''actualité du groupe Essor:', 'no'),
(515, '_options_newsSubtitle', 'field_5975e2ab324fa', 'no'),
(516, 'options_newsLinks_0_link', '19', 'no'),
(517, '_options_newsLinks_0_link', 'field_5975e2fbc212a', 'no'),
(518, 'options_newsLinks_0_text', 'Actualité', 'no'),
(519, '_options_newsLinks_0_text', 'field_5975e30fc212b', 'no'),
(520, 'options_newsLinks', '1', 'no'),
(521, '_options_newsLinks', 'field_5975e2b5324fb', 'no'),
(522, 'options_socialNetworks_0_link', 'http://test.fr', 'no'),
(523, '_options_socialNetworks_0_link', 'field_5975e37dc212d', 'no'),
(524, 'options_socialNetworks_0_name', 'Facebook', 'no'),
(525, '_options_socialNetworks_0_name', 'field_5975e38ac212e', 'no'),
(526, 'options_socialNetworks_1_link', 'http://test.fr', 'no'),
(527, '_options_socialNetworks_1_link', 'field_5975e37dc212d', 'no'),
(528, 'options_socialNetworks_1_name', 'LinkedIn', 'no'),
(529, '_options_socialNetworks_1_name', 'field_5975e38ac212e', 'no'),
(530, 'options_socialNetworks_2_link', 'http://test.fr', 'no'),
(531, '_options_socialNetworks_2_link', 'field_5975e37dc212d', 'no'),
(532, 'options_socialNetworks_2_name', 'Instagram', 'no'),
(533, '_options_socialNetworks_2_name', 'field_5975e38ac212e', 'no'),
(534, 'options_socialNetworks', '3', 'no'),
(535, '_options_socialNetworks', 'field_5975e31bc212c', 'no'),
(536, 'options_officesTitle', 'Nous trouver', 'no'),
(537, '_options_officesTitle', 'field_5975e4686910a', 'no'),
(538, 'options_officesSubtitle', 'Dans toute la France:', 'no'),
(539, '_options_officesSubtitle', 'field_5975e4716910b', 'no'),
(540, 'options_officesPage', '21', 'no'),
(541, '_options_officesPage', 'field_5975e4826910c', 'no'),
(542, 'options_officesBtn', 'Nos implantations', 'no'),
(543, '_options_officesBtn', 'field_5975e4eb6910d', 'no'),
(547, 'wpseo_sitemap_97_cache_validator', '4fsop', 'no'),
(548, 'wpseo_sitemap_98_cache_validator', '4fsor', 'no'),
(549, 'wpseo_sitemap_99_cache_validator', '4fsot', 'no'),
(550, 'wpseo_sitemap_100_cache_validator', '4fsox', 'no'),
(551, 'wpseo_sitemap_101_cache_validator', '4fsoC', 'no'),
(552, 'options_newsLinks_0_icon', '', 'no'),
(553, '_options_newsLinks_0_icon', 'field_5975e606060b8', 'no'),
(554, 'options_officesMap', '137', 'no'),
(555, '_options_officesMap', 'field_5975e5d9060b7', 'no'),
(557, 'options_socialNetworks_0_icon', 'fb', 'no'),
(558, '_options_socialNetworks_0_icon', 'field_5975e89ae9d81', 'no'),
(559, 'options_socialNetworks_1_icon', 'linkedin', 'no'),
(560, '_options_socialNetworks_1_icon', 'field_5975e89ae9d81', 'no'),
(561, 'options_socialNetworks_2_icon', 'instagram', 'no'),
(562, '_options_socialNetworks_2_icon', 'field_5975e89ae9d81', 'no'),
(602, 'wp_ewwwio_media_optimize_batch_a', '', 'no'),
(640, 'wpseo_sitemap_offre_cache_validator', '49lUH', 'no'),
(687, '_site_transient_timeout_browser_01e7f149b44b995a2fca96d2e7db6e42', '1502187812', 'no'),
(688, '_site_transient_browser_01e7f149b44b995a2fca96d2e7db6e42', 'a:9:{s:8:"platform";s:9:"Macintosh";s:4:"name";s:6:"Chrome";s:7:"version";s:13:"59.0.3071.115";s:10:"update_url";s:28:"http://www.google.com/chrome";s:7:"img_src";s:49:"http://s.wordpress.org/images/browsers/chrome.png";s:11:"img_src_ssl";s:48:"https://wordpress.org/images/browsers/chrome.png";s:15:"current_version";s:2:"18";s:7:"upgrade";b:0;s:8:"insecure";b:0;}', 'no'),
(699, 'wpseo_sitemap_post_cache_validator', '49qeU', 'no'),
(700, 'wpseo_sitemap_category_cache_validator', '49svh', 'no'),
(703, 'cbxwpslack_integrations', '', 'yes'),
(704, 'cbxwpslackout_general', '', 'yes'),
(725, '_site_transient_update_plugins', 'O:8:"stdClass":4:{s:12:"last_checked";i:1501656711;s:8:"response";a:1:{s:34:"advanced-custom-fields-pro/acf.php";O:8:"stdClass":6:{s:4:"slug";s:26:"advanced-custom-fields-pro";s:6:"plugin";s:34:"advanced-custom-fields-pro/acf.php";s:11:"new_version";s:5:"5.6.0";s:3:"url";s:37:"https://www.advancedcustomfields.com/";s:6:"tested";s:5:"4.8.0";s:7:"package";s:0:"";}}s:12:"translations";a:0:{}s:9:"no_update";a:8:{s:33:"automatic-nbsp/automatic-nbsp.php";O:8:"stdClass":6:{s:2:"id";s:28:"w.org/plugins/automatic-nbsp";s:4:"slug";s:14:"automatic-nbsp";s:6:"plugin";s:33:"automatic-nbsp/automatic-nbsp.php";s:11:"new_version";s:5:"1.5.3";s:3:"url";s:45:"https://wordpress.org/plugins/automatic-nbsp/";s:7:"package";s:63:"https://downloads.wordpress.org/plugin/automatic-nbsp.1.5.3.zip";}s:29:"bj-lazy-load/bj-lazy-load.php";O:8:"stdClass":6:{s:2:"id";s:26:"w.org/plugins/bj-lazy-load";s:4:"slug";s:12:"bj-lazy-load";s:6:"plugin";s:29:"bj-lazy-load/bj-lazy-load.php";s:11:"new_version";s:5:"1.0.8";s:3:"url";s:43:"https://wordpress.org/plugins/bj-lazy-load/";s:7:"package";s:55:"https://downloads.wordpress.org/plugin/bj-lazy-load.zip";}s:23:"email-log/email-log.php";O:8:"stdClass":6:{s:2:"id";s:23:"w.org/plugins/email-log";s:4:"slug";s:9:"email-log";s:6:"plugin";s:23:"email-log/email-log.php";s:11:"new_version";s:5:"1.9.1";s:3:"url";s:40:"https://wordpress.org/plugins/email-log/";s:7:"package";s:58:"https://downloads.wordpress.org/plugin/email-log.1.9.1.zip";}s:45:"ewww-image-optimizer/ewww-image-optimizer.php";O:8:"stdClass":6:{s:2:"id";s:34:"w.org/plugins/ewww-image-optimizer";s:4:"slug";s:20:"ewww-image-optimizer";s:6:"plugin";s:45:"ewww-image-optimizer/ewww-image-optimizer.php";s:11:"new_version";s:5:"3.5.1";s:3:"url";s:51:"https://wordpress.org/plugins/ewww-image-optimizer/";s:7:"package";s:69:"https://downloads.wordpress.org/plugin/ewww-image-optimizer.3.5.1.zip";}s:27:"redirection/redirection.php";O:8:"stdClass":6:{s:2:"id";s:25:"w.org/plugins/redirection";s:4:"slug";s:11:"redirection";s:6:"plugin";s:27:"redirection/redirection.php";s:11:"new_version";s:5:"2.6.6";s:3:"url";s:42:"https://wordpress.org/plugins/redirection/";s:7:"package";s:60:"https://downloads.wordpress.org/plugin/redirection.2.6.6.zip";}s:23:"secupress/secupress.php";O:8:"stdClass":6:{s:2:"id";s:23:"w.org/plugins/secupress";s:4:"slug";s:9:"secupress";s:6:"plugin";s:23:"secupress/secupress.php";s:11:"new_version";s:3:"1.3";s:3:"url";s:40:"https://wordpress.org/plugins/secupress/";s:7:"package";s:56:"https://downloads.wordpress.org/plugin/secupress.1.3.zip";}s:63:"wp-seo-structured-data-schema/wp-seo-structured-data-schema.php";O:8:"stdClass":6:{s:2:"id";s:43:"w.org/plugins/wp-seo-structured-data-schema";s:4:"slug";s:29:"wp-seo-structured-data-schema";s:6:"plugin";s:63:"wp-seo-structured-data-schema/wp-seo-structured-data-schema.php";s:11:"new_version";s:3:"2.0";s:3:"url";s:60:"https://wordpress.org/plugins/wp-seo-structured-data-schema/";s:7:"package";s:76:"https://downloads.wordpress.org/plugin/wp-seo-structured-data-schema.2.0.zip";}s:24:"wordpress-seo/wp-seo.php";O:8:"stdClass":6:{s:2:"id";s:27:"w.org/plugins/wordpress-seo";s:4:"slug";s:13:"wordpress-seo";s:6:"plugin";s:24:"wordpress-seo/wp-seo.php";s:11:"new_version";s:3:"5.1";s:3:"url";s:44:"https://wordpress.org/plugins/wordpress-seo/";s:7:"package";s:60:"https://downloads.wordpress.org/plugin/wordpress-seo.5.1.zip";}}}', 'no'),
(730, '_transient_timeout_ewww_image_optimizer_images_reoptimized', '1501678912', 'no');
INSERT INTO `essor_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(731, '_transient_ewww_image_optimizer_images_reoptimized', 'zero', 'no'),
(732, '_site_transient_timeout_secupress-detect-bad-plugins', '1501696913', 'no'),
(733, '_site_transient_secupress-detect-bad-plugins', '1', 'no'),
(734, '_site_transient_timeout_secupress-detect-bad-themes', '1501696914', 'no'),
(735, '_site_transient_secupress-detect-bad-themes', '1', 'no'),
(736, '_site_transient_timeout_theme_roots', '1501677114', 'no'),
(737, '_site_transient_theme_roots', 'a:1:{s:5:"essor";s:7:"/themes";}', 'no'),
(738, 'wpseo_sitemap_149_cache_validator', '49svg', 'no'),
(739, 'wpseo_sitemap_144_cache_validator', '49svj', 'no');

-- --------------------------------------------------------

--
-- Structure de la table `essor_postmeta`
--

CREATE TABLE `essor_postmeta` (
`meta_id` bigint(20) unsigned NOT NULL,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=616 ;

--
-- Contenu de la table `essor_postmeta`
--

INSERT INTO `essor_postmeta` (`meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1, 2, '_wp_page_template', 'default'),
(6, 2, '_edit_lock', '1500889549:1'),
(7, 2, '_edit_last', '1'),
(8, 7, '_edit_last', '1'),
(9, 7, '_edit_lock', '1500639664:1'),
(10, 7, '_wp_page_template', 'default'),
(11, 7, '_bj_lazy_load_skip_post', 'false'),
(12, 7, '_yoast_wpseo_content_score', '30'),
(13, 9, '_edit_last', '1'),
(14, 9, '_edit_lock', '1500629224:1'),
(15, 9, '_wp_page_template', 'default'),
(16, 9, '_bj_lazy_load_skip_post', 'false'),
(17, 9, '_yoast_wpseo_content_score', '30'),
(18, 11, '_edit_last', '1'),
(19, 11, '_edit_lock', '1500629248:1'),
(20, 11, '_wp_page_template', 'default'),
(21, 11, '_bj_lazy_load_skip_post', 'false'),
(22, 11, '_yoast_wpseo_content_score', '30'),
(23, 13, '_edit_last', '1'),
(24, 13, '_edit_lock', '1500629262:1'),
(25, 13, '_wp_page_template', 'default'),
(26, 13, '_bj_lazy_load_skip_post', 'false'),
(27, 13, '_yoast_wpseo_content_score', '30'),
(28, 15, '_edit_last', '1'),
(29, 15, '_edit_lock', '1500629280:1'),
(30, 15, '_wp_page_template', 'default'),
(31, 15, '_bj_lazy_load_skip_post', 'false'),
(32, 15, '_yoast_wpseo_content_score', '30'),
(33, 17, '_edit_last', '1'),
(34, 17, '_edit_lock', '1500899167:1'),
(35, 17, '_wp_page_template', 'default'),
(36, 17, '_bj_lazy_load_skip_post', 'false'),
(37, 17, '_yoast_wpseo_content_score', '30'),
(38, 19, '_edit_last', '1'),
(39, 19, '_edit_lock', '1500977046:1'),
(40, 19, '_wp_page_template', 'default'),
(41, 19, '_bj_lazy_load_skip_post', 'false'),
(42, 19, '_yoast_wpseo_content_score', '30'),
(43, 21, '_edit_last', '1'),
(44, 21, '_edit_lock', '1500899235:1'),
(45, 21, '_wp_page_template', 'default'),
(46, 21, '_bj_lazy_load_skip_post', 'false'),
(47, 21, '_yoast_wpseo_content_score', '30'),
(48, 23, '_edit_last', '1'),
(49, 23, '_edit_lock', '1500651228:1'),
(50, 23, '_wp_page_template', 'default'),
(51, 23, '_bj_lazy_load_skip_post', 'false'),
(52, 23, '_yoast_wpseo_content_score', '30'),
(53, 25, '_edit_last', '1'),
(54, 25, '_edit_lock', '1500938437:1'),
(55, 25, '_wp_page_template', 'default'),
(56, 25, '_bj_lazy_load_skip_post', 'false'),
(57, 25, '_yoast_wpseo_content_score', '30'),
(58, 27, '_menu_item_type', 'post_type'),
(59, 27, '_menu_item_menu_item_parent', '0'),
(60, 27, '_menu_item_object_id', '2'),
(61, 27, '_menu_item_object', 'page'),
(62, 27, '_menu_item_target', ''),
(63, 27, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(64, 27, '_menu_item_xfn', ''),
(65, 27, '_menu_item_url', ''),
(66, 27, '_menu_item_orphaned', '1500629594'),
(67, 28, '_menu_item_type', 'post_type'),
(68, 28, '_menu_item_menu_item_parent', '0'),
(69, 28, '_menu_item_object_id', '2'),
(70, 28, '_menu_item_object', 'page'),
(71, 28, '_menu_item_target', ''),
(72, 28, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(73, 28, '_menu_item_xfn', ''),
(74, 28, '_menu_item_url', ''),
(75, 28, '_menu_item_orphaned', '1500629594'),
(76, 29, '_menu_item_type', 'post_type'),
(77, 29, '_menu_item_menu_item_parent', '0'),
(78, 29, '_menu_item_object_id', '7'),
(79, 29, '_menu_item_object', 'page'),
(80, 29, '_menu_item_target', ''),
(81, 29, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(82, 29, '_menu_item_xfn', ''),
(83, 29, '_menu_item_url', ''),
(85, 30, '_menu_item_type', 'post_type'),
(86, 30, '_menu_item_menu_item_parent', '0'),
(87, 30, '_menu_item_object_id', '9'),
(88, 30, '_menu_item_object', 'page'),
(89, 30, '_menu_item_target', ''),
(90, 30, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(91, 30, '_menu_item_xfn', ''),
(92, 30, '_menu_item_url', ''),
(94, 31, '_menu_item_type', 'post_type'),
(95, 31, '_menu_item_menu_item_parent', '0'),
(96, 31, '_menu_item_object_id', '11'),
(97, 31, '_menu_item_object', 'page'),
(98, 31, '_menu_item_target', ''),
(99, 31, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(100, 31, '_menu_item_xfn', ''),
(101, 31, '_menu_item_url', ''),
(103, 32, '_menu_item_type', 'post_type'),
(104, 32, '_menu_item_menu_item_parent', '0'),
(105, 32, '_menu_item_object_id', '13'),
(106, 32, '_menu_item_object', 'page'),
(107, 32, '_menu_item_target', ''),
(108, 32, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(109, 32, '_menu_item_xfn', ''),
(110, 32, '_menu_item_url', ''),
(112, 33, '_menu_item_type', 'post_type'),
(113, 33, '_menu_item_menu_item_parent', '0'),
(114, 33, '_menu_item_object_id', '15'),
(115, 33, '_menu_item_object', 'page'),
(116, 33, '_menu_item_target', ''),
(117, 33, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(118, 33, '_menu_item_xfn', ''),
(119, 33, '_menu_item_url', ''),
(121, 34, '_menu_item_type', 'post_type'),
(122, 34, '_menu_item_menu_item_parent', '0'),
(123, 34, '_menu_item_object_id', '17'),
(124, 34, '_menu_item_object', 'page'),
(125, 34, '_menu_item_target', ''),
(126, 34, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(127, 34, '_menu_item_xfn', ''),
(128, 34, '_menu_item_url', ''),
(129, 34, '_menu_item_orphaned', '1500629594'),
(130, 35, '_menu_item_type', 'post_type'),
(131, 35, '_menu_item_menu_item_parent', '0'),
(132, 35, '_menu_item_object_id', '19'),
(133, 35, '_menu_item_object', 'page'),
(134, 35, '_menu_item_target', ''),
(135, 35, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(136, 35, '_menu_item_xfn', ''),
(137, 35, '_menu_item_url', ''),
(138, 35, '_menu_item_orphaned', '1500629594'),
(139, 36, '_menu_item_type', 'post_type'),
(140, 36, '_menu_item_menu_item_parent', '0'),
(141, 36, '_menu_item_object_id', '21'),
(142, 36, '_menu_item_object', 'page'),
(143, 36, '_menu_item_target', ''),
(144, 36, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(145, 36, '_menu_item_xfn', ''),
(146, 36, '_menu_item_url', ''),
(147, 36, '_menu_item_orphaned', '1500629594'),
(148, 37, '_menu_item_type', 'post_type'),
(149, 37, '_menu_item_menu_item_parent', '0'),
(150, 37, '_menu_item_object_id', '23'),
(151, 37, '_menu_item_object', 'page'),
(152, 37, '_menu_item_target', ''),
(153, 37, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(154, 37, '_menu_item_xfn', ''),
(155, 37, '_menu_item_url', ''),
(156, 37, '_menu_item_orphaned', '1500629594'),
(157, 38, '_menu_item_type', 'post_type'),
(158, 38, '_menu_item_menu_item_parent', '0'),
(159, 38, '_menu_item_object_id', '25'),
(160, 38, '_menu_item_object', 'page'),
(161, 38, '_menu_item_target', ''),
(162, 38, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(163, 38, '_menu_item_xfn', ''),
(164, 38, '_menu_item_url', ''),
(165, 38, '_menu_item_orphaned', '1500629594'),
(202, 43, '_edit_last', '1'),
(203, 43, '_edit_lock', '1500897527:1'),
(204, 45, '_edit_last', '1'),
(205, 45, '_edit_lock', '1500632029:1'),
(206, 45, '_wp_page_template', 'default'),
(207, 45, '_bj_lazy_load_skip_post', 'false'),
(208, 45, '_yoast_wpseo_content_score', '30'),
(209, 47, '_edit_last', '1'),
(210, 47, '_edit_lock', '1500632044:1'),
(211, 47, '_wp_page_template', 'default'),
(212, 47, '_bj_lazy_load_skip_post', 'false'),
(213, 47, '_yoast_wpseo_content_score', '30'),
(214, 49, '_edit_last', '1'),
(215, 49, '_edit_lock', '1500632060:1'),
(216, 49, '_wp_page_template', 'default'),
(217, 49, '_bj_lazy_load_skip_post', 'false'),
(218, 49, '_yoast_wpseo_content_score', '30'),
(219, 51, '_edit_last', '1'),
(220, 51, '_edit_lock', '1500632075:1'),
(221, 51, '_wp_page_template', 'default'),
(222, 51, '_bj_lazy_load_skip_post', 'false'),
(223, 51, '_yoast_wpseo_content_score', '30'),
(224, 53, '_edit_last', '1'),
(225, 53, '_edit_lock', '1500632099:1'),
(226, 53, '_wp_page_template', 'default'),
(227, 53, '_bj_lazy_load_skip_post', 'false'),
(228, 53, '_yoast_wpseo_content_score', '30'),
(229, 55, '_menu_item_type', 'post_type'),
(230, 55, '_menu_item_menu_item_parent', '33'),
(231, 55, '_menu_item_object_id', '53'),
(232, 55, '_menu_item_object', 'page'),
(233, 55, '_menu_item_target', ''),
(234, 55, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(235, 55, '_menu_item_xfn', ''),
(236, 55, '_menu_item_url', ''),
(238, 56, '_menu_item_type', 'post_type'),
(239, 56, '_menu_item_menu_item_parent', '32'),
(240, 56, '_menu_item_object_id', '51'),
(241, 56, '_menu_item_object', 'page'),
(242, 56, '_menu_item_target', ''),
(243, 56, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(244, 56, '_menu_item_xfn', ''),
(245, 56, '_menu_item_url', ''),
(247, 57, '_menu_item_type', 'post_type'),
(248, 57, '_menu_item_menu_item_parent', '31'),
(249, 57, '_menu_item_object_id', '49'),
(250, 57, '_menu_item_object', 'page'),
(251, 57, '_menu_item_target', ''),
(252, 57, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(253, 57, '_menu_item_xfn', ''),
(254, 57, '_menu_item_url', ''),
(256, 58, '_menu_item_type', 'post_type'),
(257, 58, '_menu_item_menu_item_parent', '30'),
(258, 58, '_menu_item_object_id', '47'),
(259, 58, '_menu_item_object', 'page'),
(260, 58, '_menu_item_target', ''),
(261, 58, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(262, 58, '_menu_item_xfn', ''),
(263, 58, '_menu_item_url', ''),
(265, 59, '_menu_item_type', 'post_type'),
(266, 59, '_menu_item_menu_item_parent', '29'),
(267, 59, '_menu_item_object_id', '45'),
(268, 59, '_menu_item_object', 'page'),
(269, 59, '_menu_item_target', ''),
(270, 59, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(271, 59, '_menu_item_xfn', ''),
(272, 59, '_menu_item_url', ''),
(274, 60, '_edit_last', '1'),
(275, 60, '_edit_lock', '1500647790:1'),
(276, 60, '_wp_page_template', 'default'),
(277, 60, '_bj_lazy_load_skip_post', 'false'),
(278, 60, '_yoast_wpseo_content_score', '30'),
(279, 62, '_edit_last', '1'),
(280, 62, '_edit_lock', '1500647688:1'),
(281, 62, '_wp_page_template', 'default'),
(282, 62, '_bj_lazy_load_skip_post', 'false'),
(283, 62, '_yoast_wpseo_content_score', '30'),
(300, 68, '_edit_last', '1'),
(301, 68, '_edit_lock', '1500647813:1'),
(302, 68, '_wp_page_template', 'default'),
(303, 68, '_bj_lazy_load_skip_post', 'false'),
(304, 68, '_yoast_wpseo_content_score', '30'),
(305, 70, '_edit_last', '1'),
(306, 70, '_edit_lock', '1501088034:1'),
(307, 70, '_wp_page_template', 'default'),
(308, 70, '_bj_lazy_load_skip_post', 'false'),
(309, 70, '_yoast_wpseo_content_score', '60'),
(310, 72, '_edit_last', '1'),
(311, 72, '_edit_lock', '1500650489:1'),
(312, 72, '_wp_page_template', 'sitemap.php'),
(313, 72, '_bj_lazy_load_skip_post', 'false'),
(314, 72, '_yoast_wpseo_content_score', '30'),
(315, 2, '_bj_lazy_load_skip_post', 'false'),
(316, 2, '_yoast_wpseo_content_score', '30'),
(317, 75, '_menu_item_type', 'post_type'),
(318, 75, '_menu_item_menu_item_parent', '0'),
(319, 75, '_menu_item_object_id', '2'),
(320, 75, '_menu_item_object', 'page'),
(321, 75, '_menu_item_target', ''),
(322, 75, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(323, 75, '_menu_item_xfn', ''),
(324, 75, '_menu_item_url', ''),
(325, 75, '_menu_item_orphaned', '1500650832'),
(326, 76, '_menu_item_type', 'post_type'),
(327, 76, '_menu_item_menu_item_parent', '0'),
(328, 76, '_menu_item_object_id', '23'),
(329, 76, '_menu_item_object', 'page'),
(330, 76, '_menu_item_target', ''),
(331, 76, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(332, 76, '_menu_item_xfn', ''),
(333, 76, '_menu_item_url', ''),
(334, 76, '_menu_item_orphaned', '1500650845'),
(335, 77, '_menu_item_type', 'post_type'),
(336, 77, '_menu_item_menu_item_parent', '0'),
(337, 77, '_menu_item_object_id', '17'),
(338, 77, '_menu_item_object', 'page'),
(339, 77, '_menu_item_target', ''),
(340, 77, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(341, 77, '_menu_item_xfn', ''),
(342, 77, '_menu_item_url', ''),
(343, 77, '_menu_item_orphaned', '1500650858'),
(344, 78, '_menu_item_type', 'post_type'),
(345, 78, '_menu_item_menu_item_parent', '0'),
(346, 78, '_menu_item_object_id', '19'),
(347, 78, '_menu_item_object', 'page'),
(348, 78, '_menu_item_target', ''),
(349, 78, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(350, 78, '_menu_item_xfn', ''),
(351, 78, '_menu_item_url', ''),
(352, 78, '_menu_item_orphaned', '1500650868'),
(353, 79, '_menu_item_type', 'post_type'),
(354, 79, '_menu_item_menu_item_parent', '0'),
(355, 79, '_menu_item_object_id', '21'),
(356, 79, '_menu_item_object', 'page'),
(357, 79, '_menu_item_target', ''),
(358, 79, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(359, 79, '_menu_item_xfn', ''),
(360, 79, '_menu_item_url', ''),
(361, 79, '_menu_item_orphaned', '1500650868'),
(362, 80, '_menu_item_type', 'post_type'),
(363, 80, '_menu_item_menu_item_parent', '0'),
(364, 80, '_menu_item_object_id', '72'),
(365, 80, '_menu_item_object', 'page'),
(366, 80, '_menu_item_target', ''),
(367, 80, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(368, 80, '_menu_item_xfn', ''),
(369, 80, '_menu_item_url', ''),
(371, 81, '_menu_item_type', 'post_type'),
(372, 81, '_menu_item_menu_item_parent', '0'),
(373, 81, '_menu_item_object_id', '70'),
(374, 81, '_menu_item_object', 'page'),
(375, 81, '_menu_item_target', ''),
(376, 81, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(377, 81, '_menu_item_xfn', ''),
(378, 81, '_menu_item_url', ''),
(380, 82, '_menu_item_type', 'post_type'),
(381, 82, '_menu_item_menu_item_parent', '0'),
(382, 82, '_menu_item_object_id', '68'),
(383, 82, '_menu_item_object', 'page'),
(384, 82, '_menu_item_target', ''),
(385, 82, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(386, 82, '_menu_item_xfn', ''),
(387, 82, '_menu_item_url', ''),
(389, 83, '_menu_item_type', 'post_type'),
(390, 83, '_menu_item_menu_item_parent', '0'),
(391, 83, '_menu_item_object_id', '2'),
(392, 83, '_menu_item_object', 'page'),
(393, 83, '_menu_item_target', ''),
(394, 83, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(395, 83, '_menu_item_xfn', ''),
(396, 83, '_menu_item_url', ''),
(398, 84, '_menu_item_type', 'post_type'),
(399, 84, '_menu_item_menu_item_parent', '83'),
(400, 84, '_menu_item_object_id', '23'),
(401, 84, '_menu_item_object', 'page'),
(402, 84, '_menu_item_target', ''),
(403, 84, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(404, 84, '_menu_item_xfn', ''),
(405, 84, '_menu_item_url', ''),
(407, 85, '_menu_item_type', 'post_type'),
(408, 85, '_menu_item_menu_item_parent', '83'),
(409, 85, '_menu_item_object_id', '17'),
(410, 85, '_menu_item_object', 'page'),
(411, 85, '_menu_item_target', ''),
(412, 85, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(413, 85, '_menu_item_xfn', ''),
(414, 85, '_menu_item_url', ''),
(416, 86, '_menu_item_type', 'post_type'),
(417, 86, '_menu_item_menu_item_parent', '83'),
(418, 86, '_menu_item_object_id', '19'),
(419, 86, '_menu_item_object', 'page'),
(420, 86, '_menu_item_target', ''),
(421, 86, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(422, 86, '_menu_item_xfn', ''),
(423, 86, '_menu_item_url', ''),
(425, 87, '_menu_item_type', 'post_type'),
(426, 87, '_menu_item_menu_item_parent', '83'),
(427, 87, '_menu_item_object_id', '21'),
(428, 87, '_menu_item_object', 'page'),
(429, 87, '_menu_item_target', ''),
(430, 87, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(431, 87, '_menu_item_xfn', ''),
(432, 87, '_menu_item_url', ''),
(434, 88, '_edit_last', '1'),
(435, 88, '_edit_lock', '1500651142:1'),
(436, 88, '_wp_page_template', 'default'),
(437, 88, '_bj_lazy_load_skip_post', 'false'),
(438, 88, '_yoast_wpseo_content_score', '30'),
(439, 91, '_edit_last', '1'),
(440, 91, '_edit_lock', '1500651259:1'),
(441, 91, '_wp_page_template', 'default'),
(442, 91, '_bj_lazy_load_skip_post', 'false'),
(443, 91, '_yoast_wpseo_content_score', '30'),
(444, 93, '_edit_last', '1'),
(445, 93, '_edit_lock', '1500651324:1'),
(446, 93, '_wp_page_template', 'default'),
(447, 93, '_bj_lazy_load_skip_post', 'false'),
(448, 93, '_yoast_wpseo_content_score', '30'),
(449, 95, '_edit_last', '1'),
(450, 95, '_edit_lock', '1500651485:1'),
(451, 95, '_wp_page_template', 'default'),
(452, 95, '_bj_lazy_load_skip_post', 'false'),
(453, 95, '_yoast_wpseo_content_score', '30'),
(499, 102, '_edit_last', '1'),
(500, 102, '_edit_lock', '1501071597:1'),
(501, 17, '_schema_article', 'a:12:{s:6:"active";N;s:8:"headline";N;s:16:"mainEntityOfPage";N;s:6:"author";N;s:5:"image";N;s:13:"datePublished";N;s:12:"dateModified";N;s:9:"publisher";N;s:14:"publisherImage";N;s:11:"description";N;s:11:"articleBody";N;s:19:"alternativeHeadline";N;}'),
(502, 17, '_schema_blog_posting', 'a:11:{s:6:"active";N;s:8:"headline";N;s:16:"mainEntityOfPage";N;s:6:"author";N;s:5:"image";N;s:13:"datePublished";N;s:12:"dateModified";N;s:9:"publisher";N;s:14:"publisherImage";N;s:11:"description";N;s:11:"articleBody";N;}'),
(503, 17, '_schema_news_article', 'a:11:{s:6:"active";N;s:8:"headline";N;s:16:"mainEntityOfPage";N;s:6:"author";N;s:5:"image";N;s:13:"datePublished";N;s:12:"dateModified";N;s:9:"publisher";N;s:14:"publisherImage";N;s:11:"description";N;s:11:"articleBody";N;}'),
(504, 17, '_schema_event', 'a:12:{s:6:"active";N;s:4:"name";N;s:12:"locationName";N;s:15:"locationAddress";N;s:9:"startDate";N;s:7:"endDate";N;s:11:"description";N;s:13:"performerName";N;s:5:"image";N;s:5:"price";N;s:13:"priceCurrency";N;s:3:"url";N;}'),
(505, 17, '_schema_product', 'a:12:{s:6:"active";N;s:4:"name";N;s:5:"image";N;s:11:"description";N;s:5:"brand";N;s:11:"ratingValue";N;s:11:"reviewCount";N;s:5:"price";N;s:13:"priceCurrency";N;s:12:"availability";N;s:13:"itemCondition";N;s:3:"url";N;}'),
(506, 17, '_schema_video', 'a:10:{s:6:"active";N;s:4:"name";N;s:11:"description";N;s:12:"thumbnailUrl";N;s:10:"uploadDate";N;s:8:"duration";N;s:10:"contentUrl";N;s:8:"embedUrl";N;s:16:"interactionCount";N;s:7:"expires";N;}'),
(507, 17, '_schema_service', 'a:13:{s:6:"active";N;s:4:"name";N;s:11:"serviceType";N;s:14:"additionalType";N;s:5:"award";N;s:8:"category";N;s:16:"providerMobility";N;s:11:"description";N;s:5:"image";N;s:16:"mainEntityOfPage";N;s:6:"sameAs";N;s:3:"url";N;s:13:"alternateName";N;}'),
(508, 17, '_schema_review', 'a:10:{s:6:"active";N;s:8:"itemName";N;s:10:"reviewBody";N;s:4:"name";N;s:6:"author";N;s:13:"datePublished";N;s:11:"ratingValue";N;s:10:"bestRating";N;s:11:"worstRating";N;s:9:"publisher";N;}'),
(509, 17, '_schema_aggregate_rating', 'a:13:{s:6:"active";N;s:11:"schema_type";N;s:4:"name";N;s:5:"image";N;s:10:"priceRange";N;s:9:"telephone";N;s:7:"address";N;s:11:"description";N;s:11:"ratingCount";N;s:11:"reviewCount";N;s:11:"ratingValue";N;s:10:"bestRating";N;s:11:"worstRating";N;}'),
(510, 19, '_schema_article', 'a:12:{s:6:"active";N;s:8:"headline";N;s:16:"mainEntityOfPage";N;s:6:"author";N;s:5:"image";N;s:13:"datePublished";N;s:12:"dateModified";N;s:9:"publisher";N;s:14:"publisherImage";N;s:11:"description";N;s:11:"articleBody";N;s:19:"alternativeHeadline";N;}'),
(511, 19, '_schema_blog_posting', 'a:11:{s:6:"active";N;s:8:"headline";N;s:16:"mainEntityOfPage";N;s:6:"author";N;s:5:"image";N;s:13:"datePublished";N;s:12:"dateModified";N;s:9:"publisher";N;s:14:"publisherImage";N;s:11:"description";N;s:11:"articleBody";N;}'),
(512, 19, '_schema_news_article', 'a:11:{s:6:"active";N;s:8:"headline";N;s:16:"mainEntityOfPage";N;s:6:"author";N;s:5:"image";N;s:13:"datePublished";N;s:12:"dateModified";N;s:9:"publisher";N;s:14:"publisherImage";N;s:11:"description";N;s:11:"articleBody";N;}'),
(513, 19, '_schema_event', 'a:12:{s:6:"active";N;s:4:"name";N;s:12:"locationName";N;s:15:"locationAddress";N;s:9:"startDate";N;s:7:"endDate";N;s:11:"description";N;s:13:"performerName";N;s:5:"image";N;s:5:"price";N;s:13:"priceCurrency";N;s:3:"url";N;}'),
(514, 19, '_schema_product', 'a:12:{s:6:"active";N;s:4:"name";N;s:5:"image";N;s:11:"description";N;s:5:"brand";N;s:11:"ratingValue";N;s:11:"reviewCount";N;s:5:"price";N;s:13:"priceCurrency";N;s:12:"availability";N;s:13:"itemCondition";N;s:3:"url";N;}'),
(515, 19, '_schema_video', 'a:10:{s:6:"active";N;s:4:"name";N;s:11:"description";N;s:12:"thumbnailUrl";N;s:10:"uploadDate";N;s:8:"duration";N;s:10:"contentUrl";N;s:8:"embedUrl";N;s:16:"interactionCount";N;s:7:"expires";N;}'),
(516, 19, '_schema_service', 'a:13:{s:6:"active";N;s:4:"name";N;s:11:"serviceType";N;s:14:"additionalType";N;s:5:"award";N;s:8:"category";N;s:16:"providerMobility";N;s:11:"description";N;s:5:"image";N;s:16:"mainEntityOfPage";N;s:6:"sameAs";N;s:3:"url";N;s:13:"alternateName";N;}'),
(517, 19, '_schema_review', 'a:10:{s:6:"active";N;s:8:"itemName";N;s:10:"reviewBody";N;s:4:"name";N;s:6:"author";N;s:13:"datePublished";N;s:11:"ratingValue";N;s:10:"bestRating";N;s:11:"worstRating";N;s:9:"publisher";N;}'),
(518, 19, '_schema_aggregate_rating', 'a:13:{s:6:"active";N;s:11:"schema_type";N;s:4:"name";N;s:5:"image";N;s:10:"priceRange";N;s:9:"telephone";N;s:7:"address";N;s:11:"description";N;s:11:"ratingCount";N;s:11:"reviewCount";N;s:11:"ratingValue";N;s:10:"bestRating";N;s:11:"worstRating";N;}'),
(519, 21, '_schema_article', 'a:12:{s:6:"active";N;s:8:"headline";N;s:16:"mainEntityOfPage";N;s:6:"author";N;s:5:"image";N;s:13:"datePublished";N;s:12:"dateModified";N;s:9:"publisher";N;s:14:"publisherImage";N;s:11:"description";N;s:11:"articleBody";N;s:19:"alternativeHeadline";N;}'),
(520, 21, '_schema_blog_posting', 'a:11:{s:6:"active";N;s:8:"headline";N;s:16:"mainEntityOfPage";N;s:6:"author";N;s:5:"image";N;s:13:"datePublished";N;s:12:"dateModified";N;s:9:"publisher";N;s:14:"publisherImage";N;s:11:"description";N;s:11:"articleBody";N;}'),
(521, 21, '_schema_news_article', 'a:11:{s:6:"active";N;s:8:"headline";N;s:16:"mainEntityOfPage";N;s:6:"author";N;s:5:"image";N;s:13:"datePublished";N;s:12:"dateModified";N;s:9:"publisher";N;s:14:"publisherImage";N;s:11:"description";N;s:11:"articleBody";N;}'),
(522, 21, '_schema_event', 'a:12:{s:6:"active";N;s:4:"name";N;s:12:"locationName";N;s:15:"locationAddress";N;s:9:"startDate";N;s:7:"endDate";N;s:11:"description";N;s:13:"performerName";N;s:5:"image";N;s:5:"price";N;s:13:"priceCurrency";N;s:3:"url";N;}'),
(523, 21, '_schema_product', 'a:12:{s:6:"active";N;s:4:"name";N;s:5:"image";N;s:11:"description";N;s:5:"brand";N;s:11:"ratingValue";N;s:11:"reviewCount";N;s:5:"price";N;s:13:"priceCurrency";N;s:12:"availability";N;s:13:"itemCondition";N;s:3:"url";N;}'),
(524, 21, '_schema_video', 'a:10:{s:6:"active";N;s:4:"name";N;s:11:"description";N;s:12:"thumbnailUrl";N;s:10:"uploadDate";N;s:8:"duration";N;s:10:"contentUrl";N;s:8:"embedUrl";N;s:16:"interactionCount";N;s:7:"expires";N;}'),
(525, 21, '_schema_service', 'a:13:{s:6:"active";N;s:4:"name";N;s:11:"serviceType";N;s:14:"additionalType";N;s:5:"award";N;s:8:"category";N;s:16:"providerMobility";N;s:11:"description";N;s:5:"image";N;s:16:"mainEntityOfPage";N;s:6:"sameAs";N;s:3:"url";N;s:13:"alternateName";N;}'),
(526, 21, '_schema_review', 'a:10:{s:6:"active";N;s:8:"itemName";N;s:10:"reviewBody";N;s:4:"name";N;s:6:"author";N;s:13:"datePublished";N;s:11:"ratingValue";N;s:10:"bestRating";N;s:11:"worstRating";N;s:9:"publisher";N;}'),
(527, 21, '_schema_aggregate_rating', 'a:13:{s:6:"active";N;s:11:"schema_type";N;s:4:"name";N;s:5:"image";N;s:10:"priceRange";N;s:9:"telephone";N;s:7:"address";N;s:11:"description";N;s:11:"ratingCount";N;s:11:"reviewCount";N;s:11:"ratingValue";N;s:10:"bestRating";N;s:11:"worstRating";N;}'),
(528, 70, '_schema_article', 'a:12:{s:6:"active";N;s:8:"headline";N;s:16:"mainEntityOfPage";N;s:6:"author";N;s:5:"image";N;s:13:"datePublished";N;s:12:"dateModified";N;s:9:"publisher";N;s:14:"publisherImage";N;s:11:"description";N;s:11:"articleBody";N;s:19:"alternativeHeadline";N;}'),
(529, 70, '_schema_blog_posting', 'a:11:{s:6:"active";N;s:8:"headline";N;s:16:"mainEntityOfPage";N;s:6:"author";N;s:5:"image";N;s:13:"datePublished";N;s:12:"dateModified";N;s:9:"publisher";N;s:14:"publisherImage";N;s:11:"description";N;s:11:"articleBody";N;}'),
(530, 70, '_schema_news_article', 'a:11:{s:6:"active";N;s:8:"headline";N;s:16:"mainEntityOfPage";N;s:6:"author";N;s:5:"image";N;s:13:"datePublished";N;s:12:"dateModified";N;s:9:"publisher";N;s:14:"publisherImage";N;s:11:"description";N;s:11:"articleBody";N;}'),
(531, 70, '_schema_event', 'a:12:{s:6:"active";N;s:4:"name";N;s:12:"locationName";N;s:15:"locationAddress";N;s:9:"startDate";N;s:7:"endDate";N;s:11:"description";N;s:13:"performerName";N;s:5:"image";N;s:5:"price";N;s:13:"priceCurrency";N;s:3:"url";N;}'),
(532, 70, '_schema_product', 'a:12:{s:6:"active";N;s:4:"name";N;s:5:"image";N;s:11:"description";N;s:5:"brand";N;s:11:"ratingValue";N;s:11:"reviewCount";N;s:5:"price";N;s:13:"priceCurrency";N;s:12:"availability";N;s:13:"itemCondition";N;s:3:"url";N;}'),
(533, 70, '_schema_video', 'a:10:{s:6:"active";N;s:4:"name";N;s:11:"description";N;s:12:"thumbnailUrl";N;s:10:"uploadDate";N;s:8:"duration";N;s:10:"contentUrl";N;s:8:"embedUrl";N;s:16:"interactionCount";N;s:7:"expires";N;}'),
(534, 70, '_schema_service', 'a:13:{s:6:"active";N;s:4:"name";N;s:11:"serviceType";N;s:14:"additionalType";N;s:5:"award";N;s:8:"category";N;s:16:"providerMobility";N;s:11:"description";N;s:5:"image";N;s:16:"mainEntityOfPage";N;s:6:"sameAs";N;s:3:"url";N;s:13:"alternateName";N;}'),
(535, 70, '_schema_review', 'a:10:{s:6:"active";N;s:8:"itemName";N;s:10:"reviewBody";N;s:4:"name";N;s:6:"author";N;s:13:"datePublished";N;s:11:"ratingValue";N;s:10:"bestRating";N;s:11:"worstRating";N;s:9:"publisher";N;}'),
(536, 70, '_schema_aggregate_rating', 'a:13:{s:6:"active";N;s:11:"schema_type";N;s:4:"name";N;s:5:"image";N;s:10:"priceRange";N;s:9:"telephone";N;s:7:"address";N;s:11:"description";N;s:11:"ratingCount";N;s:11:"reviewCount";N;s:11:"ratingValue";N;s:10:"bestRating";N;s:11:"worstRating";N;}'),
(537, 129, '_wp_attached_file', '2017/07/img.png'),
(538, 129, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:595;s:6:"height";i:360;s:4:"file";s:15:"2017/07/img.png";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:15:"img-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:15:"img-300x182.png";s:5:"width";i:300;s:6:"height";i:182;s:9:"mime-type";s:9:"image/png";}s:9:"tiny-lazy";a:4:{s:4:"file";s:13:"img-30x18.png";s:5:"width";i:30;s:6:"height";i:18;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(539, 130, '_wp_attached_file', '2017/07/img2.png'),
(540, 130, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1200;s:6:"height";i:364;s:4:"file";s:16:"2017/07/img2.png";s:5:"sizes";a:5:{s:9:"thumbnail";a:4:{s:4:"file";s:16:"img2-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:15:"img2-300x91.png";s:5:"width";i:300;s:6:"height";i:91;s:9:"mime-type";s:9:"image/png";}s:12:"medium_large";a:4:{s:4:"file";s:16:"img2-768x233.png";s:5:"width";i:768;s:6:"height";i:233;s:9:"mime-type";s:9:"image/png";}s:5:"large";a:4:{s:4:"file";s:17:"img2-1024x311.png";s:5:"width";i:1024;s:6:"height";i:311;s:9:"mime-type";s:9:"image/png";}s:9:"tiny-lazy";a:4:{s:4:"file";s:13:"img2-30x9.png";s:5:"width";i:30;s:6:"height";i:9;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(555, 137, '_wp_attached_file', '2017/07/implantations.png'),
(556, 137, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:100;s:6:"height";i:101;s:4:"file";s:25:"2017/07/implantations.png";s:5:"sizes";a:1:{s:9:"tiny-lazy";a:4:{s:4:"file";s:23:"implantations-30x30.png";s:5:"width";i:30;s:6:"height";i:30;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(557, 138, '_wp_attached_file', '2017/07/visuel.jpg'),
(558, 138, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1542;s:6:"height";i:525;s:4:"file";s:18:"2017/07/visuel.jpg";s:5:"sizes";a:5:{s:9:"thumbnail";a:4:{s:4:"file";s:18:"visuel-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:18:"visuel-300x102.jpg";s:5:"width";i:300;s:6:"height";i:102;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:18:"visuel-768x261.jpg";s:5:"width";i:768;s:6:"height";i:261;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:19:"visuel-1024x349.jpg";s:5:"width";i:1024;s:6:"height";i:349;s:9:"mime-type";s:10:"image/jpeg";}s:9:"tiny-lazy";a:4:{s:4:"file";s:16:"visuel-30x10.jpg";s:5:"width";i:30;s:6:"height";i:10;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(559, 70, '_thumbnail_id', '138'),
(560, 141, '_edit_last', '1'),
(561, 141, 'slack_integration_setting', 'a:6:{s:11:"service_url";s:77:"https://hooks.slack.com/services/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";s:7:"channel";s:6:"#essor";s:8:"username";s:4:"test";s:10:"icon_emoji";s:0:"";s:6:"active";b:1;s:6:"events";a:3:{s:14:"post_published";i:1;s:19:"post_pending_review";i:0;s:11:"new_comment";i:0;}}'),
(562, 141, '_edit_lock', '1501583051:1'),
(582, 146, '_edit_last', '1'),
(583, 146, '_edit_lock', '1501583747:1'),
(584, 146, '_cbxwpslack', 'a:6:{s:10:"serviceurl";s:77:"https://hooks.slack.com/services/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";s:7:"channel";s:6:"#essor";s:8:"username";s:4:"test";s:9:"iconemoji";s:0:"";s:6:"enable";i:1;s:5:"event";a:1:{s:14:"post_published";s:2:"on";}}');

-- --------------------------------------------------------

--
-- Structure de la table `essor_posts`
--

CREATE TABLE `essor_posts` (
`ID` bigint(20) unsigned NOT NULL,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0'
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=151 ;

--
-- Contenu de la table `essor_posts`
--

INSERT INTO `essor_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(2, 1, '2017-07-20 17:48:54', '2017-07-20 15:48:54', '', 'Le Groupe Essor', '', 'publish', 'closed', 'open', '', 'le-groupe-essor', '', '', '2017-07-21 17:35:43', '2017-07-21 15:35:43', '', 0, 'http://localhost/?page_id=2', 0, 'page', '', 0),
(5, 1, '2017-07-20 17:52:15', '2017-07-20 15:52:15', 'Voici un exemple de page. Elle est différente d’un article de blog, en cela qu’elle restera à la même place, et s’affichera dans le menu de navigation de votre site (en fonction de votre thème). La plupart des gens commencent par écrire une page « À Propos » qui les présente aux visiteurs potentiels du site. Vous pourriez y écrire quelque chose de ce tenant :\n<blockquote>Bonjour ! Je suis un mécanicien qui aspire à devenir un acteur, et ceci est mon blog. J’habite à Bordeaux, j’ai un super chien qui s’appelle Russell, et j’aime la vodka-ananas (ainsi que perdre mon temps à regarder la pluie tomber).</blockquote>\n...ou bien quelque chose comme cela :\n<blockquote>La société 123 Machin Truc a été créée en 1971, et n’a cessé de proposer au public des machins-trucs de qualité depuis cette année. Située à Saint-Remy-en-Bouzemont-Saint-Genest-et-Isson, 123 Machin Truc emploie 2 000 personnes, et fabrique toutes sortes de bidules super pour la communauté bouzemontoise.</blockquote>\nÉtant donné que vous êtes un nouvel utilisateur ou une nouvelle utilisatrice de WordPress, vous devriez vous rendre sur votre <a href="//localhost:3000/wp-admin/">tableau de bord</a> pour effacer la présente page, et créer de nouvelles pages avec votre propre contenu. Amusez-vous bien !', 'Accueil', '', 'inherit', 'closed', 'closed', '', '2-autosave-v1', '', '', '2017-07-20 17:52:15', '2017-07-20 15:52:15', '', 2, 'http://localhost/2017/07/20/2-autosave-v1/', 0, 'revision', '', 0),
(6, 1, '2017-07-20 17:52:23', '2017-07-20 15:52:23', '', 'Accueil', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2017-07-20 17:52:23', '2017-07-20 15:52:23', '', 2, 'http://localhost/2017/07/20/2-revision-v1/', 0, 'revision', '', 0),
(7, 1, '2017-07-21 11:28:48', '2017-07-21 09:28:48', '', 'Développement', '', 'publish', 'closed', 'closed', '', 'developpement', '', '', '2017-07-21 11:28:48', '2017-07-21 09:28:48', '', 0, 'http://localhost/?page_id=7', 10, 'page', '', 0),
(8, 1, '2017-07-21 11:28:48', '2017-07-21 09:28:48', '', 'Développement', '', 'inherit', 'closed', 'closed', '', '7-revision-v1', '', '', '2017-07-21 11:28:48', '2017-07-21 09:28:48', '', 7, 'http://localhost/2017/07/21/7-revision-v1/', 0, 'revision', '', 0),
(9, 1, '2017-07-21 11:29:23', '2017-07-21 09:29:23', '', 'Ingénierie', '', 'publish', 'closed', 'closed', '', 'ingenierie', '', '', '2017-07-21 11:29:23', '2017-07-21 09:29:23', '', 0, 'http://localhost/?page_id=9', 20, 'page', '', 0),
(10, 1, '2017-07-21 11:29:23', '2017-07-21 09:29:23', '', 'Ingénierie', '', 'inherit', 'closed', 'closed', '', '9-revision-v1', '', '', '2017-07-21 11:29:23', '2017-07-21 09:29:23', '', 9, 'http://localhost/2017/07/21/9-revision-v1/', 0, 'revision', '', 0),
(11, 1, '2017-07-21 11:29:47', '2017-07-21 09:29:47', '', 'Clé en Main', '', 'publish', 'closed', 'closed', '', 'cle-en-main', '', '', '2017-07-21 11:29:47', '2017-07-21 09:29:47', '', 0, 'http://localhost/?page_id=11', 30, 'page', '', 0),
(12, 1, '2017-07-21 11:29:47', '2017-07-21 09:29:47', '', 'Clé en Main', '', 'inherit', 'closed', 'closed', '', '11-revision-v1', '', '', '2017-07-21 11:29:47', '2017-07-21 09:29:47', '', 11, 'http://localhost/2017/07/21/11-revision-v1/', 0, 'revision', '', 0),
(13, 1, '2017-07-21 11:30:02', '2017-07-21 09:30:02', '', 'Agro', '', 'publish', 'closed', 'closed', '', 'agro', '', '', '2017-07-21 11:30:02', '2017-07-21 09:30:02', '', 0, 'http://localhost/?page_id=13', 40, 'page', '', 0),
(14, 1, '2017-07-21 11:30:02', '2017-07-21 09:30:02', '', 'Agro', '', 'inherit', 'closed', 'closed', '', '13-revision-v1', '', '', '2017-07-21 11:30:02', '2017-07-21 09:30:02', '', 13, 'http://localhost/2017/07/21/13-revision-v1/', 0, 'revision', '', 0),
(15, 1, '2017-07-21 11:30:19', '2017-07-21 09:30:19', '', 'Investissement', '', 'publish', 'closed', 'closed', '', 'investissement', '', '', '2017-07-21 11:30:19', '2017-07-21 09:30:19', '', 0, 'http://localhost/?page_id=15', 50, 'page', '', 0),
(16, 1, '2017-07-21 11:30:19', '2017-07-21 09:30:19', '', 'Investissement', '', 'inherit', 'closed', 'closed', '', '15-revision-v1', '', '', '2017-07-21 11:30:19', '2017-07-21 09:30:19', '', 15, 'http://localhost/2017/07/21/15-revision-v1/', 0, 'revision', '', 0),
(17, 1, '2017-07-21 11:31:06', '2017-07-21 09:31:06', '', 'Références', '', 'publish', 'closed', 'closed', '', 'references', '', '', '2017-07-24 14:28:26', '2017-07-24 12:28:26', '', 2, 'http://localhost/?page_id=17', 60, 'page', '', 0),
(18, 1, '2017-07-21 11:31:06', '2017-07-21 09:31:06', '', 'Références', '', 'inherit', 'closed', 'closed', '', '17-revision-v1', '', '', '2017-07-21 11:31:06', '2017-07-21 09:31:06', '', 17, 'http://localhost/2017/07/21/17-revision-v1/', 0, 'revision', '', 0),
(19, 1, '2017-07-21 11:31:27', '2017-07-21 09:31:27', '', 'Actualités', '', 'publish', 'closed', 'closed', '', 'actualites', '', '', '2017-07-25 01:23:12', '2017-07-24 23:23:12', '', 0, 'http://localhost/?page_id=19', 70, 'page', '', 0),
(20, 1, '2017-07-21 11:31:27', '2017-07-21 09:31:27', '', 'Actualités', '', 'inherit', 'closed', 'closed', '', '19-revision-v1', '', '', '2017-07-21 11:31:27', '2017-07-21 09:31:27', '', 19, 'http://localhost/2017/07/21/19-revision-v1/', 0, 'revision', '', 0),
(21, 1, '2017-07-21 11:31:46', '2017-07-21 09:31:46', '', 'Implantations', '', 'publish', 'closed', 'closed', '', 'implantations', '', '', '2017-07-24 14:29:25', '2017-07-24 12:29:25', '', 2, 'http://localhost/?page_id=21', 80, 'page', '', 0),
(22, 1, '2017-07-21 11:31:46', '2017-07-21 09:31:46', '', 'Implantations', '', 'inherit', 'closed', 'closed', '', '21-revision-v1', '', '', '2017-07-21 11:31:46', '2017-07-21 09:31:46', '', 21, 'http://localhost/2017/07/21/21-revision-v1/', 0, 'revision', '', 0),
(23, 1, '2017-07-21 11:31:58', '2017-07-21 09:31:58', '', 'A propos', '', 'publish', 'closed', 'closed', '', 'a-propos', '', '', '2017-07-21 17:26:21', '2017-07-21 15:26:21', '', 2, 'http://localhost/?page_id=23', 90, 'page', '', 0),
(24, 1, '2017-07-21 11:31:58', '2017-07-21 09:31:58', '', 'A propos', '', 'inherit', 'closed', 'closed', '', '23-revision-v1', '', '', '2017-07-21 11:31:58', '2017-07-21 09:31:58', '', 23, 'http://localhost/2017/07/21/23-revision-v1/', 0, 'revision', '', 0),
(25, 1, '2017-07-21 11:32:12', '2017-07-21 09:32:12', '', 'Contact', '', 'publish', 'closed', 'closed', '', 'contact', '', '', '2017-07-21 11:32:12', '2017-07-21 09:32:12', '', 0, 'http://localhost/?page_id=25', 100, 'page', '', 0),
(26, 1, '2017-07-21 11:32:12', '2017-07-21 09:32:12', '', 'Contact', '', 'inherit', 'closed', 'closed', '', '25-revision-v1', '', '', '2017-07-21 11:32:12', '2017-07-21 09:32:12', '', 25, 'http://localhost/2017/07/21/25-revision-v1/', 0, 'revision', '', 0),
(27, 1, '2017-07-21 11:33:14', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2017-07-21 11:33:14', '0000-00-00 00:00:00', '', 0, 'http://localhost/?p=27', 1, 'nav_menu_item', '', 0),
(28, 1, '2017-07-21 11:33:14', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2017-07-21 11:33:14', '0000-00-00 00:00:00', '', 0, 'http://localhost/?p=28', 1, 'nav_menu_item', '', 0),
(29, 1, '2017-07-21 11:40:15', '2017-07-21 09:40:15', 'Développer un projet immobilier dans sa globalité', '', '', 'publish', 'closed', 'closed', '', '29', '', '', '2017-07-24 15:44:57', '2017-07-24 13:44:57', '', 0, 'http://localhost/?p=29', 6, 'nav_menu_item', '', 0),
(30, 1, '2017-07-21 11:40:15', '2017-07-21 09:40:15', 'Mener des missions de maîtrise d''oeuvre', '', '', 'publish', 'closed', 'closed', '', '30', '', '', '2017-07-24 15:44:57', '2017-07-24 13:44:57', '', 0, 'http://localhost/?p=30', 8, 'nav_menu_item', '', 0),
(31, 1, '2017-07-21 11:40:15', '2017-07-21 09:40:15', 'Construire un bâtiment professionnel ou commercial', '', '', 'publish', 'closed', 'closed', '', '31', '', '', '2017-07-24 15:44:57', '2017-07-24 13:44:57', '', 0, 'http://localhost/?p=31', 10, 'nav_menu_item', '', 0),
(32, 1, '2017-07-21 11:40:15', '2017-07-21 09:40:15', 'Accompagner les professionnels de l''industrie agroalimentaire', '', '', 'publish', 'closed', 'closed', '', '32', '', '', '2017-07-24 15:44:57', '2017-07-24 13:44:57', '', 0, 'http://localhost/?p=32', 12, 'nav_menu_item', '', 0),
(33, 1, '2017-07-21 11:40:15', '2017-07-21 09:40:15', 'Solutions d''investissement et de financement immobilier innovantes', '', '', 'publish', 'closed', 'closed', '', '33', '', '', '2017-07-24 15:44:57', '2017-07-24 13:44:57', '', 0, 'http://localhost/?p=33', 14, 'nav_menu_item', '', 0),
(34, 1, '2017-07-21 11:33:14', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2017-07-21 11:33:14', '0000-00-00 00:00:00', '', 0, 'http://localhost/?p=34', 1, 'nav_menu_item', '', 0),
(35, 1, '2017-07-21 11:33:14', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2017-07-21 11:33:14', '0000-00-00 00:00:00', '', 0, 'http://localhost/?p=35', 1, 'nav_menu_item', '', 0),
(36, 1, '2017-07-21 11:33:14', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2017-07-21 11:33:14', '0000-00-00 00:00:00', '', 0, 'http://localhost/?p=36', 1, 'nav_menu_item', '', 0),
(37, 1, '2017-07-21 11:33:14', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2017-07-21 11:33:14', '0000-00-00 00:00:00', '', 0, 'http://localhost/?p=37', 1, 'nav_menu_item', '', 0),
(38, 1, '2017-07-21 11:33:14', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2017-07-21 11:33:14', '0000-00-00 00:00:00', '', 0, 'http://localhost/?p=38', 1, 'nav_menu_item', '', 0),
(43, 1, '2017-07-21 12:05:13', '2017-07-21 10:05:13', 'a:7:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:12:"options_page";s:8:"operator";s:2:"==";s:5:"value";s:22:"acf-options-parametres";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";}', '[options] Général', 'options-general', 'publish', 'closed', 'closed', '', 'group_5971d0f508f99', '', '', '2017-07-21 12:07:36', '2017-07-21 10:07:36', '', 0, 'http://localhost/?post_type=acf-field-group&#038;p=43', 0, 'acf-field-group', '', 0),
(44, 1, '2017-07-21 12:05:13', '2017-07-21 10:05:13', 'a:10:{s:4:"type";s:9:"page_link";s:12:"instructions";s:72:"Remplir ce champ pour faire apparaitre le lien de contact dans le header";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"post_type";a:1:{i:0;s:4:"page";}s:8:"taxonomy";a:0:{}s:10:"allow_null";i:0;s:14:"allow_archives";i:0;s:8:"multiple";i:0;}', 'Page contact', 'contactLink', 'publish', 'closed', 'closed', '', 'field_5971d1943ca06', '', '', '2017-07-21 12:05:13', '2017-07-21 10:05:13', '', 43, 'http://localhost/?post_type=acf-field&p=44', 0, 'acf-field', '', 0),
(45, 1, '2017-07-21 12:16:07', '2017-07-21 10:16:07', '', 'A propos', '', 'publish', 'closed', 'closed', '', 'a-propos', '', '', '2017-07-21 12:16:07', '2017-07-21 10:16:07', '', 7, 'http://localhost/?page_id=45', 0, 'page', '', 0),
(46, 1, '2017-07-21 12:16:07', '2017-07-21 10:16:07', '', 'A propos', '', 'inherit', 'closed', 'closed', '', '45-revision-v1', '', '', '2017-07-21 12:16:07', '2017-07-21 10:16:07', '', 45, 'http://localhost/2017/07/21/45-revision-v1/', 0, 'revision', '', 0),
(47, 1, '2017-07-21 12:16:23', '2017-07-21 10:16:23', '', 'A propos', '', 'publish', 'closed', 'closed', '', 'a-propos', '', '', '2017-07-21 12:16:23', '2017-07-21 10:16:23', '', 9, 'http://localhost/?page_id=47', 0, 'page', '', 0),
(48, 1, '2017-07-21 12:16:23', '2017-07-21 10:16:23', '', 'A propos', '', 'inherit', 'closed', 'closed', '', '47-revision-v1', '', '', '2017-07-21 12:16:23', '2017-07-21 10:16:23', '', 47, 'http://localhost/2017/07/21/47-revision-v1/', 0, 'revision', '', 0),
(49, 1, '2017-07-21 12:16:40', '2017-07-21 10:16:40', '', 'A propos', '', 'publish', 'closed', 'closed', '', 'a-propos', '', '', '2017-07-21 12:16:40', '2017-07-21 10:16:40', '', 11, 'http://localhost/?page_id=49', 0, 'page', '', 0),
(50, 1, '2017-07-21 12:16:40', '2017-07-21 10:16:40', '', 'A propos', '', 'inherit', 'closed', 'closed', '', '49-revision-v1', '', '', '2017-07-21 12:16:40', '2017-07-21 10:16:40', '', 49, 'http://localhost/2017/07/21/49-revision-v1/', 0, 'revision', '', 0),
(51, 1, '2017-07-21 12:16:54', '2017-07-21 10:16:54', '', 'A propos', '', 'publish', 'closed', 'closed', '', 'a-propos', '', '', '2017-07-21 12:16:54', '2017-07-21 10:16:54', '', 13, 'http://localhost/?page_id=51', 0, 'page', '', 0),
(52, 1, '2017-07-21 12:16:54', '2017-07-21 10:16:54', '', 'A propos', '', 'inherit', 'closed', 'closed', '', '51-revision-v1', '', '', '2017-07-21 12:16:54', '2017-07-21 10:16:54', '', 51, 'http://localhost/2017/07/21/51-revision-v1/', 0, 'revision', '', 0),
(53, 1, '2017-07-21 12:17:17', '2017-07-21 10:17:17', '', 'A propos', '', 'publish', 'closed', 'closed', '', 'a-propos', '', '', '2017-07-21 12:17:17', '2017-07-21 10:17:17', '', 15, 'http://localhost/?page_id=53', 0, 'page', '', 0),
(54, 1, '2017-07-21 12:17:17', '2017-07-21 10:17:17', '', 'A propos', '', 'inherit', 'closed', 'closed', '', '53-revision-v1', '', '', '2017-07-21 12:17:17', '2017-07-21 10:17:17', '', 53, 'http://localhost/2017/07/21/53-revision-v1/', 0, 'revision', '', 0),
(55, 1, '2017-07-21 12:18:02', '2017-07-21 10:18:02', ' ', '', '', 'publish', 'closed', 'closed', '', '55', '', '', '2017-07-24 15:44:57', '2017-07-24 13:44:57', '', 15, 'http://localhost/?p=55', 15, 'nav_menu_item', '', 0),
(56, 1, '2017-07-21 12:18:02', '2017-07-21 10:18:02', ' ', '', '', 'publish', 'closed', 'closed', '', '56', '', '', '2017-07-24 15:44:57', '2017-07-24 13:44:57', '', 13, 'http://localhost/?p=56', 13, 'nav_menu_item', '', 0),
(57, 1, '2017-07-21 12:18:02', '2017-07-21 10:18:02', ' ', '', '', 'publish', 'closed', 'closed', '', '57', '', '', '2017-07-24 15:44:57', '2017-07-24 13:44:57', '', 11, 'http://localhost/?p=57', 11, 'nav_menu_item', '', 0),
(58, 1, '2017-07-21 12:18:02', '2017-07-21 10:18:02', ' ', '', '', 'publish', 'closed', 'closed', '', '58', '', '', '2017-07-24 15:44:57', '2017-07-24 13:44:57', '', 9, 'http://localhost/?p=58', 9, 'nav_menu_item', '', 0),
(59, 1, '2017-07-21 12:18:02', '2017-07-21 10:18:02', ' ', '', '', 'publish', 'closed', 'closed', '', '59', '', '', '2017-07-24 15:44:57', '2017-07-24 13:44:57', '', 7, 'http://localhost/?p=59', 7, 'nav_menu_item', '', 0),
(60, 1, '2017-07-21 16:36:49', '2017-07-21 14:36:49', '', 'Recrutement', '', 'publish', 'closed', 'closed', '', 'recrutement', '', '', '2017-07-21 16:36:49', '2017-07-21 14:36:49', '', 0, 'http://localhost/?page_id=60', 110, 'page', '', 0),
(61, 1, '2017-07-21 16:36:49', '2017-07-21 14:36:49', '', 'Recrutement', '', 'inherit', 'closed', 'closed', '', '60-revision-v1', '', '', '2017-07-21 16:36:49', '2017-07-21 14:36:49', '', 60, 'http://localhost/60-revision-v1/', 0, 'revision', '', 0),
(62, 1, '2017-07-21 16:37:06', '2017-07-21 14:37:06', '', 'Postuler', '', 'publish', 'closed', 'closed', '', 'postuler', '', '', '2017-07-21 16:37:06', '2017-07-21 14:37:06', '', 60, 'http://localhost/?page_id=62', 0, 'page', '', 0),
(63, 1, '2017-07-21 16:37:06', '2017-07-21 14:37:06', '', 'Postuler', '', 'inherit', 'closed', 'closed', '', '62-revision-v1', '', '', '2017-07-21 16:37:06', '2017-07-21 14:37:06', '', 62, 'http://localhost/62-revision-v1/', 0, 'revision', '', 0),
(68, 1, '2017-07-21 16:39:11', '2017-07-21 14:39:11', '', 'Presse', '', 'publish', 'closed', 'closed', '', 'presse', '', '', '2017-07-21 16:39:11', '2017-07-21 14:39:11', '', 0, 'http://localhost/?page_id=68', 120, 'page', '', 0),
(69, 1, '2017-07-21 16:39:11', '2017-07-21 14:39:11', '', 'Presse', '', 'inherit', 'closed', 'closed', '', '68-revision-v1', '', '', '2017-07-21 16:39:11', '2017-07-21 14:39:11', '', 68, 'http://localhost/68-revision-v1/', 0, 'revision', '', 0),
(70, 1, '2017-07-21 16:39:26', '2017-07-21 14:39:26', '<h2>Titre principal, niveau 2</h2>\r\nAenean eu leo quam. Pellentesque ornare sem lacinia quam venenatis vestibulum. Donec sed odio dui. Maecenas sed diam eget risus varius blandit sit amet non magna ainsi qu’un <a href="#">exemple de lien</a>. Vivamus sagittis lacus vel augue laoreet rutrum faucibus dolor auctor. Aenean eu leo quam. Pellentesque ornare sem lacinia quam venenatis vestibulum. Vivamus sagittis lacus vel augue laoreet rutrum faucibus dolor auctor. Donec sed odio dui.\r\n\r\n<img class="aligncenter size-full wp-image-129" src="3000/wp-content/uploads/2017/07/img.png" alt="" width="595" height="360" />\r\n<h3>Sous titre de niveau 3</h3>\r\n<strong>Nulla vitae elit libero, a pharetra augue. Curabitur blandit tempus porttitor. Maecenas faucibus mollis interdum. Cras mattis consectetur purus sit amet fermentum.</strong>\r\n<blockquote>Une citation Morbi leo risus, porta ac consectetur ac, vestibulum at eros. Donec sed odio dui. Nullam quis risus eget urna mollis ornare vel eu leo. Integer posuere erat a ante venenatis dapibus posuere velit aliquet. Duis mollis, est non commodo luctus, nisi erat porttitor ligula, eget lacinia odio sem nec elit. Aenean lacinia bibendum nulla sed consectetur. Maecenas faucibus mollis interdum.</blockquote>\r\n<strong><img class="alignleft size-full wp-image-129" src="3000/wp-content/uploads/2017/07/img.png" alt="" width="595" height="360" />Un exemple de visuel à gauche.</strong> Etiam porta sem malesuada magna mollis euismod. Donec sed odio dui. Nullam id dolor id nibh ultricies vehicula ut id elit. Sed posuere consectetur est at lobortis. Donec sed odio dui. Aenean lacinia bibendum nulla sed consectetur. Vivamus sagittis lacus vel augue laoreet rutrum faucibus dolor auctor.\r\n\r\nEtiam porta sem malesuada magna mollis euismod. Nullam quis risus eget urna mollis ornare vel eu leo. <strong>Maecenas sed diam eget risus varius blandit sit amet non magna.</strong> Aenean lacinia bibendum nulla sed consectetur.\r\n<h3>Sous titre de niveau 3</h3>\r\nCum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Aenean eu leo quam. <strong>Un exemple de liste à puces :</strong>\r\n<ul>\r\n 	<li>Nullam quis risus eget urna mollis ornare vel eu leo.</li>\r\n 	<li>Nulla vitae elit libero, a pharetra augue.</li>\r\n 	<li>Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus.</li>\r\n 	<li>Donec sed odio dui.</li>\r\n</ul>\r\nSed posuere consectetur est at lobortis. Cras mattis consectetur purus sit amet fermentum. Vivamus sagittis lacus vel augue laoreet rutrum faucibus dolor auctor. Nulla vitae elit libero, a pharetra augue. Aenean lacinia bibendum nulla sed consectetur.\r\n<h4><img class="alignright size-full wp-image-129" src="3000/wp-content/uploads/2017/07/img.png" alt="" width="595" height="360" />Sous-titre de niveau 4</h4>\r\nMorbi leo risus, porta ac consectetur ac, vestibulum at eros. Maecenas sed diam eget risus varius blandit sit amet non magna. Donec sed odio dui. Nullam quis risus eget urna mollis ornare vel eu leo.\r\n<h4>Sous-titre de niveau 4</h4>\r\n<strong>Nulla vitae elit libero, a pharetra augue. Integer posuere erat a dapibus posuere velit aliquet.</strong> Praesent commodo magna, vel scelerisque et.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus sagittis lacus vel augue laoreet rutrum faucibus dolor auctor. Vestibulum id ligula porta felis euismod semper. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus. Etiam porta sem malesuada magna mollis euismod. Donec id elit non mi porta gravida at eget metus. Vestibulum id ligula porta felis euismod semper.\r\n\r\n<img class="alignnone size-full wp-image-130" src="3000/wp-content/uploads/2017/07/img2.png" alt="" width="1200" height="364" />\r\n\r\nDonec sed odio dui. Aenean lacinia bibendum nulla sed consectetur. Maecenas sed diam eget risus varius blandit sit amet non magna. Sed posuere consectetur est at lobortis.', 'Mentions légales', '', 'publish', 'closed', 'closed', '', 'mentions-legales', '', '', '2017-07-26 17:30:47', '2017-07-26 15:30:47', '', 0, 'http://localhost/?page_id=70', 140, 'page', '', 0),
(72, 1, '2017-07-21 16:39:41', '2017-07-21 14:39:41', '', 'Sitemap', '', 'publish', 'closed', 'closed', '', 'sitemap', '', '', '2017-07-21 16:39:41', '2017-07-21 14:39:41', '', 0, 'http://localhost/?page_id=72', 150, 'page', '', 0),
(73, 1, '2017-07-21 16:39:41', '2017-07-21 14:39:41', '', 'Sitemap', '', 'inherit', 'closed', 'closed', '', '72-revision-v1', '', '', '2017-07-21 16:39:41', '2017-07-21 14:39:41', '', 72, 'http://localhost/72-revision-v1/', 0, 'revision', '', 0),
(74, 1, '2017-07-21 17:25:43', '2017-07-21 15:25:43', '', 'Le Groupe Essor', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2017-07-21 17:25:43', '2017-07-21 15:25:43', '', 2, 'http://localhost/2-revision-v1/', 0, 'revision', '', 0),
(75, 1, '2017-07-21 17:27:12', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2017-07-21 17:27:12', '0000-00-00 00:00:00', '', 0, 'http://localhost/?p=75', 1, 'nav_menu_item', '', 0),
(76, 1, '2017-07-21 17:27:25', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2017-07-21 17:27:25', '0000-00-00 00:00:00', '', 2, 'http://localhost/?p=76', 1, 'nav_menu_item', '', 0),
(77, 1, '2017-07-21 17:27:38', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2017-07-21 17:27:38', '0000-00-00 00:00:00', '', 0, 'http://localhost/?p=77', 1, 'nav_menu_item', '', 0),
(78, 1, '2017-07-21 17:27:48', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2017-07-21 17:27:48', '0000-00-00 00:00:00', '', 0, 'http://localhost/?p=78', 1, 'nav_menu_item', '', 0),
(79, 1, '2017-07-21 17:27:48', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2017-07-21 17:27:48', '0000-00-00 00:00:00', '', 0, 'http://localhost/?p=79', 1, 'nav_menu_item', '', 0),
(80, 1, '2017-07-21 17:30:41', '2017-07-21 15:30:41', ' ', '', '', 'publish', 'closed', 'closed', '', '80', '', '', '2017-07-25 13:06:42', '2017-07-25 11:06:42', '', 0, 'http://localhost/?p=80', 3, 'nav_menu_item', '', 0),
(81, 1, '2017-07-21 17:30:41', '2017-07-21 15:30:41', ' ', '', '', 'publish', 'closed', 'closed', '', '81', '', '', '2017-07-25 13:06:42', '2017-07-25 11:06:42', '', 0, 'http://localhost/?p=81', 2, 'nav_menu_item', '', 0),
(82, 1, '2017-07-21 17:30:41', '2017-07-21 15:30:41', ' ', '', '', 'publish', 'closed', 'closed', '', '82', '', '', '2017-07-25 13:06:42', '2017-07-25 11:06:42', '', 0, 'http://localhost/?p=82', 1, 'nav_menu_item', '', 0),
(83, 1, '2017-07-21 17:32:29', '2017-07-21 15:32:29', 'Construction de bâtiments à usage professionnel', '', '', 'publish', 'closed', 'closed', '', '83', '', '', '2017-07-24 15:44:57', '2017-07-24 13:44:57', '', 0, 'http://localhost/?p=83', 1, 'nav_menu_item', '', 0),
(84, 1, '2017-07-21 17:32:29', '2017-07-21 15:32:29', ' ', '', '', 'publish', 'closed', 'closed', '', '84', '', '', '2017-07-24 15:44:57', '2017-07-24 13:44:57', '', 2, 'http://localhost/?p=84', 5, 'nav_menu_item', '', 0),
(85, 1, '2017-07-21 17:32:29', '2017-07-21 15:32:29', ' ', '', '', 'publish', 'closed', 'closed', '', '85', '', '', '2017-07-24 15:44:57', '2017-07-24 13:44:57', '', 2, 'http://localhost/?p=85', 2, 'nav_menu_item', '', 0),
(86, 1, '2017-07-21 17:32:29', '2017-07-21 15:32:29', ' ', '', '', 'publish', 'closed', 'closed', '', '86', '', '', '2017-07-24 15:44:57', '2017-07-24 13:44:57', '', 0, 'http://localhost/?p=86', 3, 'nav_menu_item', '', 0),
(87, 1, '2017-07-21 17:32:29', '2017-07-21 15:32:29', ' ', '', '', 'publish', 'closed', 'closed', '', '87', '', '', '2017-07-24 15:44:57', '2017-07-24 13:44:57', '', 2, 'http://localhost/?p=87', 4, 'nav_menu_item', '', 0),
(88, 1, '2017-07-21 17:34:35', '2017-07-21 15:34:35', '', 'Histoire', '', 'publish', 'closed', 'closed', '', 'histoire', '', '', '2017-07-21 17:34:35', '2017-07-21 15:34:35', '', 23, 'http://localhost/?page_id=88', 0, 'page', '', 0),
(89, 1, '2017-07-21 17:34:35', '2017-07-21 15:34:35', '', 'Histoire', '', 'inherit', 'closed', 'closed', '', '88-revision-v1', '', '', '2017-07-21 17:34:35', '2017-07-21 15:34:35', '', 88, 'http://localhost/88-revision-v1/', 0, 'revision', '', 0),
(91, 1, '2017-07-21 17:36:36', '2017-07-21 15:36:36', '', 'Organisation et filiales', '', 'publish', 'closed', 'closed', '', 'organisation-et-filiales', '', '', '2017-07-21 17:36:36', '2017-07-21 15:36:36', '', 23, 'http://localhost/?page_id=91', 10, 'page', '', 0),
(92, 1, '2017-07-21 17:36:36', '2017-07-21 15:36:36', '', 'Organisation et filiales', '', 'inherit', 'closed', 'closed', '', '91-revision-v1', '', '', '2017-07-21 17:36:36', '2017-07-21 15:36:36', '', 91, 'http://localhost/91-revision-v1/', 0, 'revision', '', 0),
(93, 1, '2017-07-21 17:37:09', '2017-07-21 15:37:09', '', 'Valeurs et projets', '', 'publish', 'closed', 'closed', '', 'valeurs-et-projets', '', '', '2017-07-21 17:37:09', '2017-07-21 15:37:09', '', 23, 'http://localhost/?page_id=93', 20, 'page', '', 0),
(94, 1, '2017-07-21 17:37:09', '2017-07-21 15:37:09', '', 'Valeurs et projets', '', 'inherit', 'closed', 'closed', '', '93-revision-v1', '', '', '2017-07-21 17:37:09', '2017-07-21 15:37:09', '', 93, 'http://localhost/93-revision-v1/', 0, 'revision', '', 0),
(95, 1, '2017-07-21 17:38:03', '2017-07-21 15:38:03', '', 'Organigramme', '', 'publish', 'closed', 'closed', '', 'organigramme', '', '', '2017-07-21 17:38:03', '2017-07-21 15:38:03', '', 23, 'http://localhost/?page_id=95', 30, 'page', '', 0),
(96, 1, '2017-07-21 17:38:03', '2017-07-21 15:38:03', '', 'Organigramme', '', 'inherit', 'closed', 'closed', '', '95-revision-v1', '', '', '2017-07-21 17:38:03', '2017-07-21 15:38:03', '', 95, 'http://localhost/95-revision-v1/', 0, 'revision', '', 0),
(102, 1, '2017-07-24 14:06:32', '2017-07-24 12:06:32', 'a:7:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:12:"options_page";s:8:"operator";s:2:"==";s:5:"value";s:22:"acf-options-parametres";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";}', '[options] Footer', 'options-footer', 'publish', 'closed', 'closed', '', 'group_5975e1896c833', '', '', '2017-07-24 14:31:45', '2017-07-24 12:31:45', '', 0, 'http://localhost/?post_type=acf-field-group&#038;p=102', 10, 'acf-field-group', '', 0),
(103, 1, '2017-07-24 14:06:33', '2017-07-24 12:06:33', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'Offres d''emploi', '', 'publish', 'closed', 'closed', '', 'field_5975e199324f3', '', '', '2017-07-24 14:06:33', '2017-07-24 12:06:33', '', 102, 'http://localhost/?post_type=acf-field&p=103', 0, 'acf-field', '', 0),
(104, 1, '2017-07-24 14:06:33', '2017-07-24 12:06:33', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:2:"50";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Titre', 'offersTitle', 'publish', 'closed', 'closed', '', 'field_5975e1b2324f4', '', '', '2017-07-24 14:06:33', '2017-07-24 12:06:33', '', 102, 'http://localhost/?post_type=acf-field&p=104', 1, 'acf-field', '', 0),
(105, 1, '2017-07-24 14:06:33', '2017-07-24 12:06:33', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:2:"50";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Sous-titre', 'offersSubtitle', 'publish', 'closed', 'closed', '', 'field_5975e1c2324f5', '', '', '2017-07-24 14:06:33', '2017-07-24 12:06:33', '', 102, 'http://localhost/?post_type=acf-field&p=105', 2, 'acf-field', '', 0),
(106, 1, '2017-07-24 14:06:33', '2017-07-24 12:06:33', 'a:10:{s:4:"type";s:9:"page_link";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:2:"50";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"post_type";a:1:{i:0;s:4:"page";}s:8:"taxonomy";a:0:{}s:10:"allow_null";i:0;s:14:"allow_archives";i:0;s:8:"multiple";i:0;}', 'Page offres d''emploi', 'offersPage', 'publish', 'closed', 'closed', '', 'field_5975e1cf324f6', '', '', '2017-07-24 14:06:33', '2017-07-24 12:06:33', '', 102, 'http://localhost/?post_type=acf-field&p=106', 3, 'acf-field', '', 0),
(107, 1, '2017-07-24 14:06:33', '2017-07-24 12:06:33', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:2:"50";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Bouton', 'offersBtn', 'publish', 'closed', 'closed', '', 'field_5975e1e7324f7', '', '', '2017-07-24 14:06:33', '2017-07-24 12:06:33', '', 102, 'http://localhost/?post_type=acf-field&p=107', 4, 'acf-field', '', 0),
(108, 1, '2017-07-24 14:06:33', '2017-07-24 12:06:33', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'Actualité', '', 'publish', 'closed', 'closed', '', 'field_5975e27a324f8', '', '', '2017-07-24 14:06:33', '2017-07-24 12:06:33', '', 102, 'http://localhost/?post_type=acf-field&p=108', 5, 'acf-field', '', 0),
(109, 1, '2017-07-24 14:06:33', '2017-07-24 12:06:33', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:2:"50";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Titre', 'newsTitle', 'publish', 'closed', 'closed', '', 'field_5975e28f324f9', '', '', '2017-07-24 14:06:33', '2017-07-24 12:06:33', '', 102, 'http://localhost/?post_type=acf-field&p=109', 6, 'acf-field', '', 0),
(110, 1, '2017-07-24 14:06:33', '2017-07-24 12:06:33', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:2:"50";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Sous-titre', 'newsSubtitle', 'publish', 'closed', 'closed', '', 'field_5975e2ab324fa', '', '', '2017-07-24 14:06:33', '2017-07-24 12:06:33', '', 102, 'http://localhost/?post_type=acf-field&p=110', 7, 'acf-field', '', 0),
(111, 1, '2017-07-24 14:06:33', '2017-07-24 12:06:33', 'a:10:{s:4:"type";s:8:"repeater";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"collapsed";s:0:"";s:3:"min";s:0:"";s:3:"max";i:4;s:6:"layout";s:5:"block";s:12:"button_label";s:15:"Ajouter un lien";}', 'Liens', 'newsLinks', 'publish', 'closed', 'closed', '', 'field_5975e2b5324fb', '', '', '2017-07-24 14:10:02', '2017-07-24 12:10:02', '', 102, 'http://localhost/?post_type=acf-field&#038;p=111', 8, 'acf-field', '', 0),
(112, 1, '2017-07-24 14:10:02', '2017-07-24 12:10:02', 'a:10:{s:4:"type";s:9:"page_link";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:2:"50";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"post_type";a:0:{}s:8:"taxonomy";a:0:{}s:10:"allow_null";i:0;s:14:"allow_archives";i:0;s:8:"multiple";i:0;}', 'Lien', 'link', 'publish', 'closed', 'closed', '', 'field_5975e2fbc212a', '', '', '2017-07-24 14:31:45', '2017-07-24 12:31:45', '', 111, 'http://localhost/?post_type=acf-field&#038;p=112', 0, 'acf-field', '', 0),
(113, 1, '2017-07-24 14:10:02', '2017-07-24 12:10:02', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:2:"50";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Texte', 'text', 'publish', 'closed', 'closed', '', 'field_5975e30fc212b', '', '', '2017-07-24 14:31:45', '2017-07-24 12:31:45', '', 111, 'http://localhost/?post_type=acf-field&#038;p=113', 1, 'acf-field', '', 0),
(114, 1, '2017-07-24 14:10:02', '2017-07-24 12:10:02', 'a:10:{s:4:"type";s:8:"repeater";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"collapsed";s:0:"";s:3:"min";s:0:"";s:3:"max";i:3;s:6:"layout";s:5:"block";s:12:"button_label";s:25:"Ajouter un réseau social";}', 'Réseaux sociaux', 'socialNetworks', 'publish', 'closed', 'closed', '', 'field_5975e31bc212c', '', '', '2017-07-24 14:10:02', '2017-07-24 12:10:02', '', 102, 'http://localhost/?post_type=acf-field&p=114', 9, 'acf-field', '', 0),
(115, 1, '2017-07-24 14:10:02', '2017-07-24 12:10:02', 'a:7:{s:4:"type";s:3:"url";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:2:"33";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";}', 'Lien', 'link', 'publish', 'closed', 'closed', '', 'field_5975e37dc212d', '', '', '2017-07-24 14:31:45', '2017-07-24 12:31:45', '', 114, 'http://localhost/?post_type=acf-field&#038;p=115', 0, 'acf-field', '', 0),
(116, 1, '2017-07-24 14:10:02', '2017-07-24 12:10:02', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:2:"33";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Nom du réseau', 'name', 'publish', 'closed', 'closed', '', 'field_5975e38ac212e', '', '', '2017-07-24 14:31:45', '2017-07-24 12:31:45', '', 114, 'http://localhost/?post_type=acf-field&#038;p=116', 1, 'acf-field', '', 0),
(117, 1, '2017-07-24 14:15:50', '2017-07-24 12:15:50', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'Implantations', 'implantations', 'publish', 'closed', 'closed', '', 'field_5975e45769109', '', '', '2017-07-24 14:15:50', '2017-07-24 12:15:50', '', 102, 'http://localhost/?post_type=acf-field&p=117', 10, 'acf-field', '', 0),
(118, 1, '2017-07-24 14:15:50', '2017-07-24 12:15:50', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:2:"50";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Titre', 'officesTitle', 'publish', 'closed', 'closed', '', 'field_5975e4686910a', '', '', '2017-07-24 14:15:50', '2017-07-24 12:15:50', '', 102, 'http://localhost/?post_type=acf-field&p=118', 11, 'acf-field', '', 0),
(119, 1, '2017-07-24 14:15:50', '2017-07-24 12:15:50', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:2:"50";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Sous-titre', 'officesSubtitle', 'publish', 'closed', 'closed', '', 'field_5975e4716910b', '', '', '2017-07-24 14:15:50', '2017-07-24 12:15:50', '', 102, 'http://localhost/?post_type=acf-field&p=119', 12, 'acf-field', '', 0),
(120, 1, '2017-07-24 14:15:50', '2017-07-24 12:15:50', 'a:10:{s:4:"type";s:9:"page_link";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:2:"50";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"post_type";a:1:{i:0;s:4:"page";}s:8:"taxonomy";a:0:{}s:10:"allow_null";i:0;s:14:"allow_archives";i:0;s:8:"multiple";i:0;}', 'Page Implantations', 'officesPage', 'publish', 'closed', 'closed', '', 'field_5975e4826910c', '', '', '2017-07-24 14:20:34', '2017-07-24 12:20:34', '', 102, 'http://localhost/?post_type=acf-field&#038;p=120', 14, 'acf-field', '', 0),
(121, 1, '2017-07-24 14:15:50', '2017-07-24 12:15:50', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:2:"50";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Bouton', 'officesBtn', 'publish', 'closed', 'closed', '', 'field_5975e4eb6910d', '', '', '2017-07-24 14:20:34', '2017-07-24 12:20:34', '', 102, 'http://localhost/?post_type=acf-field&#038;p=121', 15, 'acf-field', '', 0),
(123, 1, '2017-07-24 14:20:34', '2017-07-24 12:20:34', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:2:"id";s:12:"preview_size";s:9:"thumbnail";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Carte', 'officesMap', 'publish', 'closed', 'closed', '', 'field_5975e5d9060b7', '', '', '2017-07-24 14:20:34', '2017-07-24 12:20:34', '', 102, 'http://localhost/?post_type=acf-field&p=123', 13, 'acf-field', '', 0),
(124, 1, '2017-07-24 14:31:45', '2017-07-24 12:31:45', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:2:"33";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Icone', 'icon', 'publish', 'closed', 'closed', '', 'field_5975e89ae9d81', '', '', '2017-07-24 14:31:45', '2017-07-24 12:31:45', '', 114, 'http://localhost/?post_type=acf-field&p=124', 2, 'acf-field', '', 0),
(125, 1, '2017-07-25 12:07:39', '2017-07-25 10:07:39', '<h2>Titre principal, niveau 2</h2>\nAenean eu leo quam. Pellentesque ornare sem lacinia quam venenatis vestibulum. Donec sed odio dui. Maecenas sed diam eget risus varius blandit sit amet non magna ainsi qu’un exemple de lien. Vivamus sagittis lacus vel augue laoreet rutrum faucibus dolor auctor. Aenean eu leo quam. Pellentesque ornare sem lacinia quam venenatis vestibulum. Vivamus sagittis lacus vel augue laoreet rutrum faucibus dolor auctor. Donec sed odio dui.\n<h3>Sous titre de niveau 3</h3>\n<strong>Nulla vitae elit libero, a pharetra augue. Curabitur blandit tempus porttitor. Maecenas faucibus mollis interdum. Cras mattis consectetur purus sit amet fermentum.</strong>\n<blockquote>Une citation Morbi leo risus, porta ac consectetur ac, vestibulum at eros. Donec sed odio dui. Nullam quis risus eget urna mollis ornare vel eu leo. Integer posuere erat a ante venenatis dapibus posuere velit aliquet. Duis mollis, est non commodo luctus, nisi erat porttitor ligula, eget lacinia odio sem nec elit. Aenean lacinia bibendum nulla sed consectetur. Maecenas faucibus mollis interdum.</blockquote>\n<strong><img class="alignleft size-full wp-image-129" src="http://localhost/wp-content/uploads/2017/07/img.png" alt="" width="595" height="360" />Un exemple de visuel à gauche.</strong> Etiam porta sem malesuada magna mollis euismod. Donec sed odio dui. Nullam id dolor id nibh ultricies vehicula ut id elit. Sed posuere consectetur est at lobortis. Donec sed odio dui. Aenean lacinia bibendum nulla sed consectetur. Vivamus sagittis lacus vel augue laoreet rutrum faucibus dolor auctor.\n\nEtiam porta sem malesuada magna mollis euismod. Nullam quis risus eget urna mollis ornare vel eu leo. <strong>Maecenas sed diam eget risus varius blandit sit amet non magna.</strong> Aenean lacinia bibendum nulla sed consectetur.\n<h3>Sous titre de niveau 3</h3>\nCum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Aenean eu leo quam. <strong>Un exemple de liste à puces :</strong>\n<ul>\n 	<li>Nullam quis risus eget urna mollis ornare vel eu leo.</li>\n 	<li>Nulla vitae elit libero, a pharetra augue.</li>\n 	<li>Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus.</li>\n 	<li>Donec sed odio dui.</li>\n</ul>\nSed posuere consectetur est at lobortis. Cras mattis consectetur purus sit amet fermentum. Vivamus sagittis lacus vel augue laoreet rutrum faucibus dolor auctor. Nulla vitae elit libero, a pharetra augue. Aenean lacinia bibendum nulla sed consectetur.\n<h4><img class="alignright size-full wp-image-129" src="http://localhost/wp-content/uploads/2017/07/img.png" alt="" width="595" height="360" />Sous-titre de niveau 4</h4>\nMorbi leo risus, porta ac consectetur ac, vestibulum at eros. Maecenas sed diam eget risus varius blandit sit amet non magna. Donec sed odio dui. Nullam quis risus eget urna mollis ornare vel eu leo.\n<h4>Sous-titre de niveau 4</h4>\n<strong>Nulla vitae elit libero, a pharetra augue. Integer posuere erat a dapibus posuere velit aliquet.</strong> Praesent commodo magna, vel scelerisque et.\n\nLorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus sagittis lacus vel augue laoreet rutrum faucibus dolor auctor. Vestibulum id ligula porta felis euismod semper. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus. Etiam porta sem malesuada magna mollis euismod. Donec id elit non mi porta gravida at eget metus. Vestibulum id ligula porta felis euismod semper.\n\n&nbsp;', 'Mentions légales', '', 'inherit', 'closed', 'closed', '', '70-autosave-v1', '', '', '2017-07-25 12:07:39', '2017-07-25 10:07:39', '', 70, 'http://localhost/70-autosave-v1/', 0, 'revision', '', 0),
(128, 1, '2017-07-24 17:43:02', '2017-07-24 15:43:02', '<h2>Titre principal, niveau 2</h2>\r\nAenean eu leo quam. Pellentesque ornare sem lacinia quam venenatis vestibulum. Donec sed odio dui. Maecenas sed diam eget risus varius blandit sit amet non magna ainsi qu’un exemple de lien. Vivamus sagittis lacus vel augue laoreet rutrum faucibus dolor auctor. Aenean eu leo quam. Pellentesque ornare sem lacinia quam venenatis vestibulum. Vivamus sagittis lacus vel augue laoreet rutrum faucibus dolor auctor. Donec sed odio dui.\r\n<h3>Sous titre de niveau 3</h3>\r\n<strong>Nulla vitae elit libero, a pharetra augue. Curabitur blandit tempus porttitor. Maecenas faucibus mollis interdum. Cras mattis consectetur purus sit amet fermentum.</strong>\r\n<blockquote>Une citation Morbi leo risus, porta ac consectetur ac, vestibulum at eros. Donec sed odio dui. Nullam quis risus eget urna mollis ornare vel eu leo. Integer posuere erat a ante venenatis dapibus posuere velit aliquet. Duis mollis, est non commodo luctus, nisi erat porttitor ligula, eget lacinia odio sem nec elit. Aenean lacinia bibendum nulla sed consectetur. Maecenas faucibus mollis interdum.</blockquote>\r\n<strong>Un exemple de visuel à gauche.</strong> Etiam porta sem malesuada magna mollis euismod. Donec sed odio dui. Nullam id dolor id nibh ultricies vehicula ut id elit. Sed posuere consectetur est at lobortis. Donec sed odio dui. Aenean lacinia bibendum nulla sed consectetur. Vivamus sagittis lacus vel augue laoreet rutrum faucibus dolor auctor.\r\n\r\nEtiam porta sem malesuada magna mollis euismod. Nullam quis risus eget urna mollis ornare vel eu leo. <strong>Maecenas sed diam eget risus varius blandit sit amet non magna.</strong> Aenean lacinia bibendum nulla sed consectetur.\r\n<h3>Sous titre de niveau 3</h3>\r\nCum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Aenean eu leo quam. <strong>Un exemple de liste à puces :</strong>\r\n<ul>\r\n 	<li>Nullam quis risus eget urna mollis ornare vel eu leo.</li>\r\n 	<li>Nulla vitae elit libero, a pharetra augue.</li>\r\n 	<li>Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus.</li>\r\n 	<li>Donec sed odio dui.</li>\r\n</ul>\r\nSed posuere consectetur est at lobortis. Cras mattis consectetur purus sit amet fermentum. Vivamus sagittis lacus vel augue laoreet rutrum faucibus dolor auctor. Nulla vitae elit libero, a pharetra augue. Aenean lacinia bibendum nulla sed consectetur.\r\n<h4>Sous-titre de niveau 4</h4>\r\nMorbi leo risus, porta ac consectetur ac, vestibulum at eros. Maecenas sed diam eget risus varius blandit sit amet non magna. Donec sed odio dui. Nullam quis risus eget urna mollis ornare vel eu leo.\r\n<h4>Sous-titre de niveau 4</h4>\r\n<strong>Nulla vitae elit libero, a pharetra augue. Integer posuere erat a dapibus posuere velit aliquet.</strong> Praesent commodo magna, vel scelerisque et.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus sagittis lacus vel augue laoreet rutrum faucibus dolor auctor. Vestibulum id ligula porta felis euismod semper. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus. Etiam porta sem malesuada magna mollis euismod. Donec id elit non mi porta gravida at eget metus. Vestibulum id ligula porta felis euismod semper.', 'Mentions légales', '', 'inherit', 'closed', 'closed', '', '70-revision-v1', '', '', '2017-07-24 17:43:02', '2017-07-24 15:43:02', '', 70, 'http://localhost/70-revision-v1/', 0, 'revision', '', 0),
(129, 1, '2017-07-25 12:06:58', '2017-07-25 10:06:58', '', 'img', '', 'inherit', 'closed', 'closed', '', 'img', '', '', '2017-07-25 12:06:58', '2017-07-25 10:06:58', '', 70, 'http://localhost/wp-content/uploads/2017/07/img.png', 0, 'attachment', 'image/png', 0),
(130, 1, '2017-07-25 12:07:44', '2017-07-25 10:07:44', '', 'img2', '', 'inherit', 'closed', 'closed', '', 'img2', '', '', '2017-07-25 12:07:44', '2017-07-25 10:07:44', '', 70, 'http://localhost/wp-content/uploads/2017/07/img2.png', 0, 'attachment', 'image/png', 0);
INSERT INTO `essor_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(131, 1, '2017-07-25 12:08:31', '2017-07-25 10:08:31', '<h2>Titre principal, niveau 2</h2>\r\nAenean eu leo quam. Pellentesque ornare sem lacinia quam venenatis vestibulum. Donec sed odio dui. Maecenas sed diam eget risus varius blandit sit amet non magna ainsi qu’un exemple de lien. Vivamus sagittis lacus vel augue laoreet rutrum faucibus dolor auctor. Aenean eu leo quam. Pellentesque ornare sem lacinia quam venenatis vestibulum. Vivamus sagittis lacus vel augue laoreet rutrum faucibus dolor auctor. Donec sed odio dui.\r\n\r\n<img class="aligncenter size-full wp-image-129" src="http://localhost/wp-content/uploads/2017/07/img.png" alt="" width="595" height="360" />\r\n<h3>Sous titre de niveau 3</h3>\r\n<strong>Nulla vitae elit libero, a pharetra augue. Curabitur blandit tempus porttitor. Maecenas faucibus mollis interdum. Cras mattis consectetur purus sit amet fermentum.</strong>\r\n<blockquote>Une citation Morbi leo risus, porta ac consectetur ac, vestibulum at eros. Donec sed odio dui. Nullam quis risus eget urna mollis ornare vel eu leo. Integer posuere erat a ante venenatis dapibus posuere velit aliquet. Duis mollis, est non commodo luctus, nisi erat porttitor ligula, eget lacinia odio sem nec elit. Aenean lacinia bibendum nulla sed consectetur. Maecenas faucibus mollis interdum.</blockquote>\r\n<strong><img class="alignleft size-full wp-image-129" src="http://localhost/wp-content/uploads/2017/07/img.png" alt="" width="595" height="360" />Un exemple de visuel à gauche.</strong> Etiam porta sem malesuada magna mollis euismod. Donec sed odio dui. Nullam id dolor id nibh ultricies vehicula ut id elit. Sed posuere consectetur est at lobortis. Donec sed odio dui. Aenean lacinia bibendum nulla sed consectetur. Vivamus sagittis lacus vel augue laoreet rutrum faucibus dolor auctor.\r\n\r\nEtiam porta sem malesuada magna mollis euismod. Nullam quis risus eget urna mollis ornare vel eu leo. <strong>Maecenas sed diam eget risus varius blandit sit amet non magna.</strong> Aenean lacinia bibendum nulla sed consectetur.\r\n<h3>Sous titre de niveau 3</h3>\r\nCum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Aenean eu leo quam. <strong>Un exemple de liste à puces :</strong>\r\n<ul>\r\n 	<li>Nullam quis risus eget urna mollis ornare vel eu leo.</li>\r\n 	<li>Nulla vitae elit libero, a pharetra augue.</li>\r\n 	<li>Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus.</li>\r\n 	<li>Donec sed odio dui.</li>\r\n</ul>\r\nSed posuere consectetur est at lobortis. Cras mattis consectetur purus sit amet fermentum. Vivamus sagittis lacus vel augue laoreet rutrum faucibus dolor auctor. Nulla vitae elit libero, a pharetra augue. Aenean lacinia bibendum nulla sed consectetur.\r\n<h4><img class="alignright size-full wp-image-129" src="http://localhost/wp-content/uploads/2017/07/img.png" alt="" width="595" height="360" />Sous-titre de niveau 4</h4>\r\nMorbi leo risus, porta ac consectetur ac, vestibulum at eros. Maecenas sed diam eget risus varius blandit sit amet non magna. Donec sed odio dui. Nullam quis risus eget urna mollis ornare vel eu leo.\r\n<h4>Sous-titre de niveau 4</h4>\r\n<strong>Nulla vitae elit libero, a pharetra augue. Integer posuere erat a dapibus posuere velit aliquet.</strong> Praesent commodo magna, vel scelerisque et.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus sagittis lacus vel augue laoreet rutrum faucibus dolor auctor. Vestibulum id ligula porta felis euismod semper. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus. Etiam porta sem malesuada magna mollis euismod. Donec id elit non mi porta gravida at eget metus. Vestibulum id ligula porta felis euismod semper.\r\n\r\n<img class="alignnone size-full wp-image-130" src="http://localhost/wp-content/uploads/2017/07/img2.png" alt="" width="1200" height="364" />\r\n\r\nDonec sed odio dui. Aenean lacinia bibendum nulla sed consectetur. Maecenas sed diam eget risus varius blandit sit amet non magna. Sed posuere consectetur est at lobortis.', 'Mentions légales', '', 'inherit', 'closed', 'closed', '', '70-revision-v1', '', '', '2017-07-25 12:08:31', '2017-07-25 10:08:31', '', 70, 'http://localhost/70-revision-v1/', 0, 'revision', '', 0),
(132, 1, '2017-07-25 12:27:31', '2017-07-25 10:27:31', '<h2>Titre principal, niveau 2</h2>\r\nAenean eu leo quam. Pellentesque ornare sem lacinia quam venenatis vestibulum. Donec sed odio dui. Maecenas sed diam eget risus varius blandit sit amet non magna ainsi qu’un <a href="#">exemple de lien</a>. Vivamus sagittis lacus vel augue laoreet rutrum faucibus dolor auctor. Aenean eu leo quam. Pellentesque ornare sem lacinia quam venenatis vestibulum. Vivamus sagittis lacus vel augue laoreet rutrum faucibus dolor auctor. Donec sed odio dui.\r\n\r\n<img class="aligncenter size-full wp-image-129" src="http://localhost/wp-content/uploads/2017/07/img.png" alt="" width="595" height="360" />\r\n<h3>Sous titre de niveau 3</h3>\r\n<strong>Nulla vitae elit libero, a pharetra augue. Curabitur blandit tempus porttitor. Maecenas faucibus mollis interdum. Cras mattis consectetur purus sit amet fermentum.</strong>\r\n<blockquote>Une citation Morbi leo risus, porta ac consectetur ac, vestibulum at eros. Donec sed odio dui. Nullam quis risus eget urna mollis ornare vel eu leo. Integer posuere erat a ante venenatis dapibus posuere velit aliquet. Duis mollis, est non commodo luctus, nisi erat porttitor ligula, eget lacinia odio sem nec elit. Aenean lacinia bibendum nulla sed consectetur. Maecenas faucibus mollis interdum.</blockquote>\r\n<strong><img class="alignleft size-full wp-image-129" src="http://localhost/wp-content/uploads/2017/07/img.png" alt="" width="595" height="360" />Un exemple de visuel à gauche.</strong> Etiam porta sem malesuada magna mollis euismod. Donec sed odio dui. Nullam id dolor id nibh ultricies vehicula ut id elit. Sed posuere consectetur est at lobortis. Donec sed odio dui. Aenean lacinia bibendum nulla sed consectetur. Vivamus sagittis lacus vel augue laoreet rutrum faucibus dolor auctor.\r\n\r\nEtiam porta sem malesuada magna mollis euismod. Nullam quis risus eget urna mollis ornare vel eu leo. <strong>Maecenas sed diam eget risus varius blandit sit amet non magna.</strong> Aenean lacinia bibendum nulla sed consectetur.\r\n<h3>Sous titre de niveau 3</h3>\r\nCum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Aenean eu leo quam. <strong>Un exemple de liste à puces :</strong>\r\n<ul>\r\n 	<li>Nullam quis risus eget urna mollis ornare vel eu leo.</li>\r\n 	<li>Nulla vitae elit libero, a pharetra augue.</li>\r\n 	<li>Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus.</li>\r\n 	<li>Donec sed odio dui.</li>\r\n</ul>\r\nSed posuere consectetur est at lobortis. Cras mattis consectetur purus sit amet fermentum. Vivamus sagittis lacus vel augue laoreet rutrum faucibus dolor auctor. Nulla vitae elit libero, a pharetra augue. Aenean lacinia bibendum nulla sed consectetur.\r\n<h4><img class="alignright size-full wp-image-129" src="http://localhost/wp-content/uploads/2017/07/img.png" alt="" width="595" height="360" />Sous-titre de niveau 4</h4>\r\nMorbi leo risus, porta ac consectetur ac, vestibulum at eros. Maecenas sed diam eget risus varius blandit sit amet non magna. Donec sed odio dui. Nullam quis risus eget urna mollis ornare vel eu leo.\r\n<h4>Sous-titre de niveau 4</h4>\r\n<strong>Nulla vitae elit libero, a pharetra augue. Integer posuere erat a dapibus posuere velit aliquet.</strong> Praesent commodo magna, vel scelerisque et.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus sagittis lacus vel augue laoreet rutrum faucibus dolor auctor. Vestibulum id ligula porta felis euismod semper. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus. Etiam porta sem malesuada magna mollis euismod. Donec id elit non mi porta gravida at eget metus. Vestibulum id ligula porta felis euismod semper.\r\n\r\n<img class="alignnone size-full wp-image-130" src="http://localhost/wp-content/uploads/2017/07/img2.png" alt="" width="1200" height="364" />\r\n\r\nDonec sed odio dui. Aenean lacinia bibendum nulla sed consectetur. Maecenas sed diam eget risus varius blandit sit amet non magna. Sed posuere consectetur est at lobortis.', 'Mentions légales', '', 'inherit', 'closed', 'closed', '', '70-revision-v1', '', '', '2017-07-25 12:27:31', '2017-07-25 10:27:31', '', 70, 'http://localhost/70-revision-v1/', 0, 'revision', '', 0),
(137, 1, '2017-07-26 12:12:29', '2017-07-26 10:12:29', '', 'implantations', '', 'inherit', 'closed', 'closed', '', 'implantations-2', '', '', '2017-07-26 12:12:29', '2017-07-26 10:12:29', '', 0, 'http://localhost/wp-content/uploads/2017/07/implantations.png', 0, 'attachment', 'image/png', 0),
(138, 1, '2017-07-26 17:30:38', '2017-07-26 15:30:38', '', 'visuel', '', 'inherit', 'closed', 'closed', '', 'visuel', '', '', '2017-07-26 17:30:38', '2017-07-26 15:30:38', '', 70, 'http://localhost/wp-content/uploads/2017/07/visuel.jpg', 0, 'attachment', 'image/jpeg', 0),
(139, 1, '2017-07-26 17:30:47', '2017-07-26 15:30:47', '<h2>Titre principal, niveau 2</h2>\r\nAenean eu leo quam. Pellentesque ornare sem lacinia quam venenatis vestibulum. Donec sed odio dui. Maecenas sed diam eget risus varius blandit sit amet non magna ainsi qu’un <a href="#">exemple de lien</a>. Vivamus sagittis lacus vel augue laoreet rutrum faucibus dolor auctor. Aenean eu leo quam. Pellentesque ornare sem lacinia quam venenatis vestibulum. Vivamus sagittis lacus vel augue laoreet rutrum faucibus dolor auctor. Donec sed odio dui.\r\n\r\n<img class="aligncenter size-full wp-image-129" src="3000/wp-content/uploads/2017/07/img.png" alt="" width="595" height="360" />\r\n<h3>Sous titre de niveau 3</h3>\r\n<strong>Nulla vitae elit libero, a pharetra augue. Curabitur blandit tempus porttitor. Maecenas faucibus mollis interdum. Cras mattis consectetur purus sit amet fermentum.</strong>\r\n<blockquote>Une citation Morbi leo risus, porta ac consectetur ac, vestibulum at eros. Donec sed odio dui. Nullam quis risus eget urna mollis ornare vel eu leo. Integer posuere erat a ante venenatis dapibus posuere velit aliquet. Duis mollis, est non commodo luctus, nisi erat porttitor ligula, eget lacinia odio sem nec elit. Aenean lacinia bibendum nulla sed consectetur. Maecenas faucibus mollis interdum.</blockquote>\r\n<strong><img class="alignleft size-full wp-image-129" src="3000/wp-content/uploads/2017/07/img.png" alt="" width="595" height="360" />Un exemple de visuel à gauche.</strong> Etiam porta sem malesuada magna mollis euismod. Donec sed odio dui. Nullam id dolor id nibh ultricies vehicula ut id elit. Sed posuere consectetur est at lobortis. Donec sed odio dui. Aenean lacinia bibendum nulla sed consectetur. Vivamus sagittis lacus vel augue laoreet rutrum faucibus dolor auctor.\r\n\r\nEtiam porta sem malesuada magna mollis euismod. Nullam quis risus eget urna mollis ornare vel eu leo. <strong>Maecenas sed diam eget risus varius blandit sit amet non magna.</strong> Aenean lacinia bibendum nulla sed consectetur.\r\n<h3>Sous titre de niveau 3</h3>\r\nCum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Aenean eu leo quam. <strong>Un exemple de liste à puces :</strong>\r\n<ul>\r\n 	<li>Nullam quis risus eget urna mollis ornare vel eu leo.</li>\r\n 	<li>Nulla vitae elit libero, a pharetra augue.</li>\r\n 	<li>Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus.</li>\r\n 	<li>Donec sed odio dui.</li>\r\n</ul>\r\nSed posuere consectetur est at lobortis. Cras mattis consectetur purus sit amet fermentum. Vivamus sagittis lacus vel augue laoreet rutrum faucibus dolor auctor. Nulla vitae elit libero, a pharetra augue. Aenean lacinia bibendum nulla sed consectetur.\r\n<h4><img class="alignright size-full wp-image-129" src="3000/wp-content/uploads/2017/07/img.png" alt="" width="595" height="360" />Sous-titre de niveau 4</h4>\r\nMorbi leo risus, porta ac consectetur ac, vestibulum at eros. Maecenas sed diam eget risus varius blandit sit amet non magna. Donec sed odio dui. Nullam quis risus eget urna mollis ornare vel eu leo.\r\n<h4>Sous-titre de niveau 4</h4>\r\n<strong>Nulla vitae elit libero, a pharetra augue. Integer posuere erat a dapibus posuere velit aliquet.</strong> Praesent commodo magna, vel scelerisque et.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus sagittis lacus vel augue laoreet rutrum faucibus dolor auctor. Vestibulum id ligula porta felis euismod semper. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus. Etiam porta sem malesuada magna mollis euismod. Donec id elit non mi porta gravida at eget metus. Vestibulum id ligula porta felis euismod semper.\r\n\r\n<img class="alignnone size-full wp-image-130" src="3000/wp-content/uploads/2017/07/img2.png" alt="" width="1200" height="364" />\r\n\r\nDonec sed odio dui. Aenean lacinia bibendum nulla sed consectetur. Maecenas sed diam eget risus varius blandit sit amet non magna. Sed posuere consectetur est at lobortis.', 'Mentions légales', '', 'inherit', 'closed', 'closed', '', '70-revision-v1', '', '', '2017-07-26 17:30:47', '2017-07-26 15:30:47', '', 70, 'http://localhost/70-revision-v1/', 0, 'revision', '', 0),
(140, 1, '2017-08-01 12:23:32', '0000-00-00 00:00:00', '', 'Brouillon auto', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2017-08-01 12:23:32', '0000-00-00 00:00:00', '', 0, 'http://localhost/?p=140', 0, 'post', '', 0),
(141, 1, '2017-08-01 12:26:20', '2017-08-01 10:26:20', '', 'Test', '', 'publish', 'closed', 'closed', '', 'test', '', '', '2017-08-01 12:26:20', '2017-08-01 10:26:20', '', 0, 'http://localhost/?post_type=slack_integration&#038;p=141', 0, 'slack_integration', '', 0),
(146, 1, '2017-08-01 12:37:56', '2017-08-01 10:37:56', '', 'Test', '', 'publish', 'closed', 'closed', '', 'test', '', '', '2017-08-01 12:37:56', '2017-08-01 10:37:56', '', 0, 'http://localhost/?post_type=cbxwpslack&#038;p=146', 0, 'cbxwpslack', '', 0);

-- --------------------------------------------------------

--
-- Structure de la table `essor_redirection_404`
--

CREATE TABLE `essor_redirection_404` (
`id` int(11) unsigned NOT NULL,
  `created` datetime NOT NULL,
  `url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `agent` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `referrer` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ip` int(10) unsigned NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `essor_redirection_groups`
--

CREATE TABLE `essor_redirection_groups` (
`id` int(11) NOT NULL,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tracking` int(11) NOT NULL DEFAULT '1',
  `module_id` int(11) unsigned NOT NULL DEFAULT '0',
  `status` enum('enabled','disabled') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'enabled',
  `position` int(11) unsigned NOT NULL DEFAULT '0'
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=3 ;

--
-- Contenu de la table `essor_redirection_groups`
--

INSERT INTO `essor_redirection_groups` (`id`, `name`, `tracking`, `module_id`, `status`, `position`) VALUES
(1, 'Redirections', 1, 1, 'enabled', 0),
(2, 'Modified Posts', 1, 1, 'enabled', 1);

-- --------------------------------------------------------

--
-- Structure de la table `essor_redirection_items`
--

CREATE TABLE `essor_redirection_items` (
`id` int(11) unsigned NOT NULL,
  `url` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `regex` int(11) unsigned NOT NULL DEFAULT '0',
  `position` int(11) unsigned NOT NULL DEFAULT '0',
  `last_count` int(10) unsigned NOT NULL DEFAULT '0',
  `last_access` datetime NOT NULL,
  `group_id` int(11) NOT NULL DEFAULT '0',
  `status` enum('enabled','disabled') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'enabled',
  `action_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `action_code` int(11) unsigned NOT NULL,
  `action_data` mediumtext COLLATE utf8mb4_unicode_ci,
  `match_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `essor_redirection_logs`
--

CREATE TABLE `essor_redirection_logs` (
`id` int(11) unsigned NOT NULL,
  `created` datetime NOT NULL,
  `url` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `sent_to` mediumtext COLLATE utf8mb4_unicode_ci,
  `agent` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `referrer` mediumtext COLLATE utf8mb4_unicode_ci,
  `redirection_id` int(11) unsigned DEFAULT NULL,
  `ip` varchar(17) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `module_id` int(11) unsigned NOT NULL,
  `group_id` int(11) unsigned DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `essor_termmeta`
--

CREATE TABLE `essor_termmeta` (
`meta_id` bigint(20) unsigned NOT NULL,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `essor_terms`
--

CREATE TABLE `essor_terms` (
`term_id` bigint(20) unsigned NOT NULL,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0'
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=4 ;

--
-- Contenu de la table `essor_terms`
--

INSERT INTO `essor_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Non classé', 'non-classe', 0),
(2, 'Principal', 'principal', 0),
(3, 'Footer', 'footer', 0);

-- --------------------------------------------------------

--
-- Structure de la table `essor_term_relationships`
--

CREATE TABLE `essor_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Contenu de la table `essor_term_relationships`
--

INSERT INTO `essor_term_relationships` (`object_id`, `term_taxonomy_id`, `term_order`) VALUES
(29, 2, 0),
(30, 2, 0),
(31, 2, 0),
(32, 2, 0),
(33, 2, 0),
(55, 2, 0),
(56, 2, 0),
(57, 2, 0),
(58, 2, 0),
(59, 2, 0),
(80, 3, 0),
(81, 3, 0),
(82, 3, 0),
(83, 2, 0),
(84, 2, 0),
(85, 2, 0),
(86, 2, 0),
(87, 2, 0);

-- --------------------------------------------------------

--
-- Structure de la table `essor_term_taxonomy`
--

CREATE TABLE `essor_term_taxonomy` (
`term_taxonomy_id` bigint(20) unsigned NOT NULL,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0'
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=4 ;

--
-- Contenu de la table `essor_term_taxonomy`
--

INSERT INTO `essor_term_taxonomy` (`term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 0),
(2, 2, 'nav_menu', '', 0, 15),
(3, 3, 'nav_menu', '', 0, 3);

-- --------------------------------------------------------

--
-- Structure de la table `essor_usermeta`
--

CREATE TABLE `essor_usermeta` (
`umeta_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=33 ;

--
-- Contenu de la table `essor_usermeta`
--

INSERT INTO `essor_usermeta` (`umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'adminEssor'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'comment_shortcuts', 'false'),
(7, 1, 'admin_color', 'fresh'),
(8, 1, 'use_ssl', '0'),
(9, 1, 'show_admin_bar_front', 'true'),
(10, 1, 'locale', ''),
(11, 1, 'essor_capabilities', 'a:1:{s:13:"administrator";b:1;}'),
(12, 1, 'essor_user_level', '10'),
(13, 1, 'dismissed_wp_pointers', ''),
(14, 1, 'show_welcome_panel', '0'),
(16, 1, 'essor_user-settings', 'hidetb=1&libraryContent=browse&editor=tinymce&imgsize=full&align=center&mfold=o&advImgDetails=show'),
(17, 1, 'essor_user-settings-time', '1500565775'),
(18, 1, 'essor_dashboard_quick_press_last_post_id', '140'),
(19, 1, 'community-events-location', 'a:1:{s:2:"ip";s:2:"::";}'),
(20, 1, 'closedpostboxes_dashboard', 'a:0:{}'),
(21, 1, 'metaboxhidden_dashboard', 'a:2:{i:0;s:24:"wpseo-dashboard-overview";i:1;s:17:"dashboard_primary";}'),
(23, 1, 'wpseo-reindex-links', 'seen'),
(24, 1, 'wpseo-dismiss-gsc', 'seen'),
(25, 1, 'wpseo-remove-upsell-notice', '1'),
(26, 1, 'session_tokens', 'a:2:{s:64:"8904727bee153baf819c80e004f9c51eba2acacb82d2dc73c8511e9d4edada86";a:4:{s:10:"expiration";i:1501755810;s:2:"ip";s:3:"::1";s:2:"ua";s:121:"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36";s:5:"login";i:1501583010;}s:64:"597dbbe23f924cd6613a9af493d8bf1c9a10b5bf7ff9bf5aab8bccec3de87048";a:4:{s:10:"expiration";i:1501848110;s:2:"ip";s:3:"::1";s:2:"ua";s:121:"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36";s:5:"login";i:1501675310;}}'),
(27, 1, 'essor_yoast_notifications', 'a:2:{i:0;a:2:{s:7:"message";s:185:"Ne ratez pas vos erreurs d’exploration : <a href="http://localhost/wp-admin/admin.php?page=wpseo_search_console&tab=settings">connectez-vous avec votre Google Search Console ici</a>.";s:7:"options";a:8:{s:4:"type";s:7:"warning";s:2:"id";s:17:"wpseo-dismiss-gsc";s:5:"nonce";N;s:8:"priority";d:0.5;s:9:"data_json";a:0:{}s:13:"dismissal_key";N;s:12:"capabilities";s:14:"manage_options";s:16:"capability_check";s:3:"all";}}i:1;a:2:{s:7:"message";s:295:"<strong>Important problème SEO&nbsp;: Vous bloquez actuellement l’accès aux robots des moteurs de recherche. </strong> Vous devez vous <a href="http://localhost/wp-admin/options-reading.php">rendre dans vos Réglages de Lecture</a> et décocher la case Visibilité  des moteurs de recherche.";s:7:"options";a:8:{s:4:"type";s:5:"error";s:2:"id";s:32:"wpseo-dismiss-blog-public-notice";s:5:"nonce";N;s:8:"priority";i:1;s:9:"data_json";a:0:{}s:13:"dismissal_key";N;s:12:"capabilities";s:14:"manage_options";s:16:"capability_check";s:3:"all";}}}'),
(28, 1, 'essor_dismissed_secupress_notices', 'recovery_email'),
(29, 1, 'managenav-menuscolumnshidden', 'a:3:{i:0;s:15:"title-attribute";i:1;s:11:"css-classes";i:2;s:3:"xfn";}'),
(30, 1, 'metaboxhidden_nav-menus', 'a:1:{i:0;s:12:"add-post_tag";}'),
(31, 1, 'nav_menu_recently_edited', '3'),
(32, 1, 'acf_user_settings', 'a:0:{}');

-- --------------------------------------------------------

--
-- Structure de la table `essor_users`
--

CREATE TABLE `essor_users` (
`ID` bigint(20) unsigned NOT NULL,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=2 ;

--
-- Contenu de la table `essor_users`
--

INSERT INTO `essor_users` (`ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'adminEssor', '$P$Br.N6QhVJzTjbvWDQ9au1l179H1mod0', 'adminessor', 'elisabeth@stereosuper.fr', '', '2017-07-20 15:48:54', '', 0, 'adminEssor');

-- --------------------------------------------------------

--
-- Structure de la table `essor_yoast_seo_links`
--

CREATE TABLE `essor_yoast_seo_links` (
`id` bigint(20) unsigned NOT NULL,
  `url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_id` bigint(20) unsigned NOT NULL,
  `target_post_id` bigint(20) unsigned NOT NULL,
  `type` varchar(8) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=3 ;

--
-- Contenu de la table `essor_yoast_seo_links`
--

INSERT INTO `essor_yoast_seo_links` (`id`, `url`, `post_id`, `target_post_id`, `type`) VALUES
(2, '#', 70, 0, 'internal');

-- --------------------------------------------------------

--
-- Structure de la table `essor_yoast_seo_meta`
--

CREATE TABLE `essor_yoast_seo_meta` (
  `object_id` bigint(20) unsigned NOT NULL,
  `internal_link_count` int(10) unsigned DEFAULT NULL,
  `incoming_link_count` int(10) unsigned DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Contenu de la table `essor_yoast_seo_meta`
--

INSERT INTO `essor_yoast_seo_meta` (`object_id`, `internal_link_count`, `incoming_link_count`) VALUES
(2, 0, 0),
(7, 0, 0),
(9, 0, 0),
(11, 0, 0),
(13, 0, 0),
(15, 0, 0),
(17, 0, 0),
(19, 0, 0),
(21, 0, 0),
(23, 0, 0),
(25, 0, 0),
(45, 0, 0),
(47, 0, 0),
(49, 0, 0),
(51, 0, 0),
(53, 0, 0),
(60, 0, 0),
(62, 0, 0),
(64, 0, 0),
(66, 0, 0),
(68, 0, 0),
(70, 1, 0),
(72, 0, 0),
(88, 0, 0),
(91, 0, 0),
(93, 0, 0),
(95, 0, 0),
(133, 0, 0),
(135, 0, 0),
(142, 0, 0),
(144, 0, 0),
(147, 0, 0),
(149, 0, 0);

--
-- Index pour les tables exportées
--

--
-- Index pour la table `essor_commentmeta`
--
ALTER TABLE `essor_commentmeta`
 ADD PRIMARY KEY (`meta_id`), ADD KEY `comment_id` (`comment_id`), ADD KEY `meta_key` (`meta_key`(191));

--
-- Index pour la table `essor_comments`
--
ALTER TABLE `essor_comments`
 ADD PRIMARY KEY (`comment_ID`), ADD KEY `comment_post_ID` (`comment_post_ID`), ADD KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`), ADD KEY `comment_date_gmt` (`comment_date_gmt`), ADD KEY `comment_parent` (`comment_parent`), ADD KEY `comment_author_email` (`comment_author_email`(10));

--
-- Index pour la table `essor_email_log`
--
ALTER TABLE `essor_email_log`
 ADD PRIMARY KEY (`id`);

--
-- Index pour la table `essor_ewwwio_images`
--
ALTER TABLE `essor_ewwwio_images`
 ADD UNIQUE KEY `id` (`id`), ADD KEY `path_image_size` (`path`(191),`image_size`), ADD KEY `attachment_info` (`gallery`(3),`attachment_id`);

--
-- Index pour la table `essor_links`
--
ALTER TABLE `essor_links`
 ADD PRIMARY KEY (`link_id`), ADD KEY `link_visible` (`link_visible`);

--
-- Index pour la table `essor_options`
--
ALTER TABLE `essor_options`
 ADD PRIMARY KEY (`option_id`), ADD UNIQUE KEY `option_name` (`option_name`);

--
-- Index pour la table `essor_postmeta`
--
ALTER TABLE `essor_postmeta`
 ADD PRIMARY KEY (`meta_id`), ADD KEY `post_id` (`post_id`), ADD KEY `meta_key` (`meta_key`(191));

--
-- Index pour la table `essor_posts`
--
ALTER TABLE `essor_posts`
 ADD PRIMARY KEY (`ID`), ADD KEY `post_name` (`post_name`(191)), ADD KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`), ADD KEY `post_parent` (`post_parent`), ADD KEY `post_author` (`post_author`);

--
-- Index pour la table `essor_redirection_404`
--
ALTER TABLE `essor_redirection_404`
 ADD PRIMARY KEY (`id`), ADD KEY `created` (`created`), ADD KEY `url` (`url`(191)), ADD KEY `ip` (`ip`), ADD KEY `referrer` (`referrer`(191));

--
-- Index pour la table `essor_redirection_groups`
--
ALTER TABLE `essor_redirection_groups`
 ADD PRIMARY KEY (`id`), ADD KEY `module_id` (`module_id`), ADD KEY `status` (`status`);

--
-- Index pour la table `essor_redirection_items`
--
ALTER TABLE `essor_redirection_items`
 ADD PRIMARY KEY (`id`), ADD KEY `url` (`url`(191)), ADD KEY `status` (`status`), ADD KEY `regex` (`regex`), ADD KEY `group_idpos` (`group_id`,`position`), ADD KEY `group` (`group_id`);

--
-- Index pour la table `essor_redirection_logs`
--
ALTER TABLE `essor_redirection_logs`
 ADD PRIMARY KEY (`id`), ADD KEY `created` (`created`), ADD KEY `redirection_id` (`redirection_id`), ADD KEY `ip` (`ip`), ADD KEY `group_id` (`group_id`), ADD KEY `module_id` (`module_id`);

--
-- Index pour la table `essor_termmeta`
--
ALTER TABLE `essor_termmeta`
 ADD PRIMARY KEY (`meta_id`), ADD KEY `term_id` (`term_id`), ADD KEY `meta_key` (`meta_key`(191));

--
-- Index pour la table `essor_terms`
--
ALTER TABLE `essor_terms`
 ADD PRIMARY KEY (`term_id`), ADD KEY `slug` (`slug`(191)), ADD KEY `name` (`name`(191));

--
-- Index pour la table `essor_term_relationships`
--
ALTER TABLE `essor_term_relationships`
 ADD PRIMARY KEY (`object_id`,`term_taxonomy_id`), ADD KEY `term_taxonomy_id` (`term_taxonomy_id`);

--
-- Index pour la table `essor_term_taxonomy`
--
ALTER TABLE `essor_term_taxonomy`
 ADD PRIMARY KEY (`term_taxonomy_id`), ADD UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`), ADD KEY `taxonomy` (`taxonomy`);

--
-- Index pour la table `essor_usermeta`
--
ALTER TABLE `essor_usermeta`
 ADD PRIMARY KEY (`umeta_id`), ADD KEY `user_id` (`user_id`), ADD KEY `meta_key` (`meta_key`(191));

--
-- Index pour la table `essor_users`
--
ALTER TABLE `essor_users`
 ADD PRIMARY KEY (`ID`), ADD KEY `user_login_key` (`user_login`), ADD KEY `user_nicename` (`user_nicename`), ADD KEY `user_email` (`user_email`);

--
-- Index pour la table `essor_yoast_seo_links`
--
ALTER TABLE `essor_yoast_seo_links`
 ADD PRIMARY KEY (`id`), ADD KEY `link_direction` (`post_id`,`type`);

--
-- Index pour la table `essor_yoast_seo_meta`
--
ALTER TABLE `essor_yoast_seo_meta`
 ADD UNIQUE KEY `object_id` (`object_id`);

--
-- AUTO_INCREMENT pour les tables exportées
--

--
-- AUTO_INCREMENT pour la table `essor_commentmeta`
--
ALTER TABLE `essor_commentmeta`
MODIFY `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `essor_comments`
--
ALTER TABLE `essor_comments`
MODIFY `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `essor_email_log`
--
ALTER TABLE `essor_email_log`
MODIFY `id` mediumint(9) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `essor_ewwwio_images`
--
ALTER TABLE `essor_ewwwio_images`
MODIFY `id` int(14) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=19;
--
-- AUTO_INCREMENT pour la table `essor_links`
--
ALTER TABLE `essor_links`
MODIFY `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `essor_options`
--
ALTER TABLE `essor_options`
MODIFY `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=740;
--
-- AUTO_INCREMENT pour la table `essor_postmeta`
--
ALTER TABLE `essor_postmeta`
MODIFY `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=616;
--
-- AUTO_INCREMENT pour la table `essor_posts`
--
ALTER TABLE `essor_posts`
MODIFY `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=151;
--
-- AUTO_INCREMENT pour la table `essor_redirection_404`
--
ALTER TABLE `essor_redirection_404`
MODIFY `id` int(11) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `essor_redirection_groups`
--
ALTER TABLE `essor_redirection_groups`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT pour la table `essor_redirection_items`
--
ALTER TABLE `essor_redirection_items`
MODIFY `id` int(11) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `essor_redirection_logs`
--
ALTER TABLE `essor_redirection_logs`
MODIFY `id` int(11) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `essor_termmeta`
--
ALTER TABLE `essor_termmeta`
MODIFY `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `essor_terms`
--
ALTER TABLE `essor_terms`
MODIFY `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT pour la table `essor_term_taxonomy`
--
ALTER TABLE `essor_term_taxonomy`
MODIFY `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT pour la table `essor_usermeta`
--
ALTER TABLE `essor_usermeta`
MODIFY `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=33;
--
-- AUTO_INCREMENT pour la table `essor_users`
--
ALTER TABLE `essor_users`
MODIFY `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT pour la table `essor_yoast_seo_links`
--
ALTER TABLE `essor_yoast_seo_links`
MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
